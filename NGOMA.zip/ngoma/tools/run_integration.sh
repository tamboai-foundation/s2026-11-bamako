#!/usr/bin/env bash
# Lance un test bout en bout : serveur Django (daphne) + 2 ngoma-store + test C++ integration_sync.
# Usage : tools/run_integration.sh <dossier_build_client> [store_cmd]
#   store_cmd : commande du démon de stockage, « {sock} » est remplacé par le socket.
#               Défaut : doublure Python (tools/fake_store.py). Production : java -jar ngoma-store.jar
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="${1:?dossier de build du client}"
STORE_CMD="${2:-python3 $ROOT/tools/fake_store.py {sock}}"
WORK="$(mktemp -d)"
PORT="${PORT:-8765}"
trap 'kill $(jobs -p) 2>/dev/null || true; rm -rf "$WORK"' EXIT

rnd() { python3 -c "import secrets;print(secrets.token_urlsafe($1))"; }
export NGOMA_SECRET_KEY="$(rnd 48)" NGOMA_DEBUG=0 NGOMA_ALLOWED_HOSTS=127.0.0.1,localhost
export NGOMA_PROVISIONING_CODE="$(rnd 12)" NGOMA_THROTTLE_ANON=1000/min
export NGOMA_RELAY_SECRET="$(rnd 32)" NGOMA_FAKE_LLM_KEY="$(rnd 24)" NGOMA_MEDIA_ROOT="$WORK/media" NGOMA_BOT_ALLOW_PRIVATE_BASE_URL=1
export NGOMA_BOT_KEY="$(python3 -c 'import base64,os;print(base64.urlsafe_b64encode(os.urandom(32)).decode())')" NGOMA_BOT_POLL_SECONDS=0.3
LLM_PORT="${LLM_PORT:-8766}"
# Redis comme en production : indispensable dès que le worker des bots tourne dans un autre processus.
if command -v redis-server >/dev/null; then
    redis-server --port 6390 --save "" --appendonly no >"$WORK/redis.log" 2>&1 &
    export REDIS_URL="redis://127.0.0.1:6390/0"
    sleep 0.3
fi
export DATABASE_URL="sqlite:///$WORK/db.sqlite3"
( cd "$ROOT/server" && python3 manage.py migrate -v0 && exec daphne -b 127.0.0.1 -p "$PORT" ngoma_server.asgi:application ) \
    >"$WORK/server.log" 2>&1 &
python3 "$ROOT/tools/fake_llm.py" "$LLM_PORT" >"$WORK/llm.log" 2>&1 &
( cd "$ROOT/server" && sleep 2 && exec python3 manage.py run_bots ) >"$WORK/bots.log" 2>&1 &
for s in a b; do ${STORE_CMD//\{sock\}/$WORK/store-$s.sock} >"$WORK/store-$s.log" 2>&1 & done
for _ in $(seq 50); do curl -fs "http://127.0.0.1:$PORT/healthz" >/dev/null && break; sleep 0.2; done

NGOMA_CONFIG=/dev/null NGOMA_SERVER_URL="http://127.0.0.1:$PORT" FAKE_LLM_URL="http://127.0.0.1:$LLM_PORT" \
STORE_A="$WORK/store-a.sock" STORE_B="$WORK/store-b.sock" timeout 90 "$BUILD/integration_sync" -maxwarnings 0 || { cp "$WORK"/*.log /tmp/ 2>/dev/null; tail -30 "$WORK/server.log"; tail -30 "$WORK/bots.log"; exit 1; }
