#include "VideoItem.h"

#include <QPainter>
#include <QSet>

namespace ngoma {

namespace {
QSet<VideoItem*>& items() {
    static QSet<VideoItem*> s;
    return s;
}
}  // namespace

VideoItem::VideoItem(QQuickItem* parent) : QQuickPaintedItem(parent) {
    setOpaquePainting(true);
    setFillColor(Qt::black);
    registerItem(this);
}

VideoItem::~VideoItem() { unregisterItem(this); }

void VideoItem::setSource(Source s) {
    if (s == m_source) return;
    m_source = s;
    emit sourceChanged();
}

void VideoItem::pushFrame(const QImage& frame) {
    const bool had = hasFrame();
    m_frame = frame;
    if (had != hasFrame()) emit hasFrameChanged();
    update();
}

void VideoItem::paint(QPainter* painter) {
    if (m_frame.isNull()) return;
    const QSizeF target = m_frame.size().scaled(size().toSize(), Qt::KeepAspectRatio);
    const QRectF r((width() - target.width()) / 2, (height() - target.height()) / 2, target.width(), target.height());
    painter->drawImage(r, m_frame);
}

void VideoItem::registerItem(VideoItem* item) { items().insert(item); }
void VideoItem::unregisterItem(VideoItem* item) { items().remove(item); }

void VideoItem::dispatch(Source source, const QImage& frame) {
    for (auto* it : std::as_const(items()))
        if (it->source() == source && it->isVisible()) it->pushFrame(frame);
}

}  // namespace ngoma
