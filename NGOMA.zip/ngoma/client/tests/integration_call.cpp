// Test d'intégration des appels : ngoma-relay + deux ngoma-media (préfixes IPC a/ et b/) sur une machine.
// Vérifie : inscription au relais par jeton HMAC, H.264 + Opus chiffrés de bout en bout dans les deux sens,
// trames décodées livrées à l'UI par iceoryx2, et refus des médias chiffrés avec une autre clé d'appel.
// Lancé par tools/run_call_check.sh (variables : NGOMA_RELAY_SECRET, RELAY_PORT).
#include <QSignalSpy>
#include <QtTest>
#include <cstring>
#include <sodium.h>

#include "core/Uuid7.h"
#include "ipc/IpcBus.h"
#include "media/MediaWire.h"

using namespace ngoma;

namespace {
QString hmacToken(const QString& callId, quint64 userId, const QString& deviceId, quint64 exp) {
    wire::Uuid call{}, device{};
    wire::parseUuid(callId.toLatin1().constData(), call);
    wire::parseUuid(deviceId.toLatin1().constData(), device);
    std::uint8_t msg[48];
    std::memcpy(msg, call.data(), 16);
    wire::putBe(msg + 16, userId, 8);
    std::memcpy(msg + 24, device.data(), 16);
    wire::putBe(msg + 40, exp, 8);
    const QByteArray secret = qgetenv("NGOMA_RELAY_SECRET");
    std::uint8_t mac[32];
    crypto_auth_hmacsha256_state st;
    crypto_auth_hmacsha256_init(&st, reinterpret_cast<const unsigned char*>(secret.constData()), size_t(secret.size()));
    crypto_auth_hmacsha256_update(&st, msg, sizeof msg);
    crypto_auth_hmacsha256_final(&st, mac);
    return QString::fromLatin1(QByteArray(reinterpret_cast<const char*>(mac), 32).toHex());
}

ipc::CallControl start(const QString& callId, quint64 user, const QString& device, const QByteArray& key, bool badToken = false) {
    ipc::CallControl c;
    c.command = ipc::CallCommand::Start;
    c.call_seq = 7;
    std::strcpy(c.call_id, callId.toLatin1().constData());
    c.width = 320;
    c.height = 240;
    c.fps = 15;
    std::strcpy(c.relay_host, "127.0.0.1");
    c.relay_port = std::uint32_t(qEnvironmentVariableIntValue("RELAY_PORT"));
    c.user_id = user;
    c.exp = quint64(QDateTime::currentSecsSinceEpoch() + 600);
    std::strcpy(c.device_id, device.toLatin1().constData());
    QString token = hmacToken(callId, user, device, c.exp);
    if (badToken) token[0] = token[0] == QLatin1Char('a') ? QLatin1Char('b') : QLatin1Char('a');
    std::strcpy(c.token, token.toLatin1().constData());
    std::memcpy(c.call_key, key.constData(), 32);
    return c;
}

ipc::CallControl stop() {
    ipc::CallControl c;
    c.command = ipc::CallCommand::Stop;
    return c;
}
}  // namespace

class IntegrationCall : public QObject {
    Q_OBJECT
private slots:
    void initTestCase() { QVERIFY(sodium_init() >= 0); }

    void encryptedCallBothWays() {
        IpcBus a(nullptr, QStringLiteral("a/")), b(nullptr, QStringLiteral("b/"));
        QVERIFY(a.available() && b.available());
        a.setVideoReceiving(true);
        b.setVideoReceiving(true);
        QSignalSpy remoteA(&a, &IpcBus::remoteFrame), remoteB(&b, &IpcBus::remoteFrame);
        QSignalSpy levelA(&a, &IpcBus::audioLevel), levelB(&b, &IpcBus::audioLevel);

        QByteArray key(32, Qt::Uninitialized);
        randombytes_buf(key.data(), 32);
        const QString call = uuid7();
        a.sendCallControl(start(call, 1, uuid7(), key));
        b.sendCallControl(start(call, 2, uuid7(), key));

        QTRY_VERIFY_WITH_TIMEOUT(remoteA.count() >= 5 && remoteB.count() >= 5, 15000);
        const auto img = remoteB.last().at(0).value<QImage>();
        QCOMPARE(img.width(), 320);
        QCOMPARE(img.height(), 240);
        // Mire de test : bandes de couleur reconnaissables après encodage/décodage H.264.
        QVERIFY(qRed(img.pixel(5, 120)) > 200 && qGreen(img.pixel(5, 120)) > 200);
        // Audio : sinus 440 Hz reçu, décodé (Opus) et mesuré côté restitution.
        QTRY_VERIFY_WITH_TIMEOUT(!levelA.isEmpty() && levelA.last().at(1).toFloat() > 0.05f, 10000);
        QTRY_VERIFY_WITH_TIMEOUT(!levelB.isEmpty() && levelB.last().at(1).toFloat() > 0.05f, 10000);

        a.sendCallControl(stop());
        b.sendCallControl(stop());
        QTest::qWait(300);
    }

    void wrongCallKeyIsRejected() {
        IpcBus a(nullptr, QStringLiteral("a/")), b(nullptr, QStringLiteral("b/"));
        b.setVideoReceiving(true);
        QSignalSpy remoteB(&b, &IpcBus::remoteFrame);
        QByteArray k1(32, '\x01'), k2(32, '\x02');
        const QString call = uuid7();
        a.sendCallControl(start(call, 1, uuid7(), k1));  // clé différente : paquets indéchiffrables
        b.sendCallControl(start(call, 2, uuid7(), k2));
        QTest::qWait(2500);
        QCOMPARE(remoteB.count(), 0);
        a.sendCallControl(stop());
        b.sendCallControl(stop());
        QTest::qWait(300);
    }

    void badRelayTokenIsRefused() {
        IpcBus a(nullptr, QStringLiteral("a/")), b(nullptr, QStringLiteral("b/"));
        b.setVideoReceiving(true);
        QSignalSpy remoteB(&b, &IpcBus::remoteFrame);
        QByteArray key(32, '\x03');
        const QString call = uuid7();
        a.sendCallControl(start(call, 1, uuid7(), key, /*badToken=*/true));  // A n'est jamais admis par le relais
        b.sendCallControl(start(call, 2, uuid7(), key));
        QTest::qWait(2500);
        QCOMPARE(remoteB.count(), 0);
        a.sendCallControl(stop());
        b.sendCallControl(stop());
    }
};

QTEST_GUILESS_MAIN(IntegrationCall)
#include "integration_call.moc"
