import QtQuick
import QtQuick.Controls

// Champ de saisie NGOMA : fond sombre, bordure accent au focus, texte et indication lisibles.
TextField {
    id: control
    implicitHeight: Theme.touch
    font.pixelSize: Theme.fontBody
    color: Theme.text
    placeholderTextColor: Theme.textMuted
    selectionColor: Theme.accent
    selectedTextColor: Theme.accentText
    leftPadding: 16
    rightPadding: 16
    verticalAlignment: TextInput.AlignVCenter

    background: Rectangle {
        radius: Theme.radiusSmall
        color: control.enabled ? Theme.surfaceHigh : Theme.surface
        border.width: control.activeFocus ? 2 : 1
        border.color: control.activeFocus ? Theme.accent : Theme.outline
    }
}
