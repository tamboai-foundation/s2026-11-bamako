#!/usr/bin/env python3
"""Doublure de test de ngoma-store (même protocole JSON-lignes sur socket Unix).

À usage EXCLUSIF des tests d'intégration et du développement sur poste sans JDK :
le démon de production est store/ (Kotlin + T-Modeler). Stockage en mémoire.
Usage : fake_store.py /chemin/store.sock
"""
import asyncio
import json
import sys


class Store:
    def __init__(self):
        self.settings, self.convs, self.msgs = {}, {}, {}

    def conv(self, cid):
        return self.convs.setdefault(cid, {"id": cid, "kind": "", "title": "", "members": [], "server_seq": 0,
                                           "pulled_seq": 0, "read_seq": 0, "peer_read_seq": 0, "updated_at": "",
                                           "draft": ""})

    def op(self, op, a):
        if op == "ping":
            return "pong", None
        if op == "setting.get":
            return self.settings.get(a["key"]), None
        if op == "setting.set":
            self.settings[a["key"]] = a.get("value", "")
            return True, None
        if op == "conv.upsert":
            for it in a["items"]:
                c = self.conv(it["id"])
                c.update(kind=it.get("kind", c["kind"]), title=it.get("title", c["title"]),
                         members=it.get("members", c["members"]), updated_at=it.get("updated_at", c["updated_at"]))
                c["server_seq"] = max(c["server_seq"], it.get("last_seq", 0))
            return len(a["items"]), ("conv", None)
        if op == "conv.list":
            out = []
            for c in sorted(self.convs.values(), key=lambda c: c["updated_at"], reverse=True):
                mine = [m for m in self.msgs.values() if m["messaging_id"] == c["id"]]
                last = mine[-1] if mine else None
                out.append({**c, "unread": max(0, c["pulled_seq"] - c["read_seq"]),
                            "last_body": last["body"] if last else "", "last_at": last["created_at"] if last else ""})
            return out, None
        if op in ("conv.setServerSeq", "conv.setPulled", "conv.setRead", "conv.setPeerRead"):
            if a["id"] not in self.convs:
                return False, None
            c = self.convs[a["id"]]
            field = {"conv.setServerSeq": "server_seq", "conv.setPulled": "pulled_seq", "conv.setRead": "read_seq",
                     "conv.setPeerRead": "peer_read_seq"}[op]
            c[field] = max(c[field], a.get("seq", 0))
            if op == "conv.setPulled":
                c["server_seq"] = max(c["server_seq"], c["pulled_seq"])
            return True, ("conv", a["id"])
        if op == "conv.setDraft":
            self.conv(a["id"])["draft"] = a.get("text", "")
            return True, None
        if op == "msg.insertOutgoing":
            m = self.msgs.get(a["client_id"])
            if not m:
                m = {"client_id": a["client_id"], "remote_id": "", "messaging_id": a["messaging_id"], "seq": 0,
                     "sender_id": a.get("sender_id", 0), "kind": a.get("kind", "text"), "body": a.get("body", ""),
                     "state": "pending", "created_at": a.get("created_at", ""), "expires_at": a.get("expires_at", ""),
                     "meta": a.get("meta", "")}
                self.msgs[a["client_id"]] = m
            return m, ("msg", a["messaging_id"])
        if op == "msg.markSent":
            m = self.msgs.get(a["client_id"])
            if not m:
                return False, None
            m.update(state="sent", seq=a.get("seq", m["seq"]), remote_id=a.get("remote_id", m["remote_id"]))
            return True, ("msg", m["messaging_id"])
        if op == "msg.setMeta":
            m = self.msgs.get(a["client_id"])
            if not m:
                return False, None
            m["meta"] = a.get("meta", "")
            return True, ("msg", m["messaging_id"])
        if op == "msg.markFailed":
            m = self.msgs.get(a["client_id"])
            if m and a.get("permanent"):
                m["state"] = "failed"
            return bool(m), ("msg", a.get("messaging_id"))
        if op == "msg.upsertReceived":
            me = a.get("my_user_id", 0)
            for it in a["items"]:
                m = self.msgs.setdefault(it["client_id"], {"client_id": it["client_id"], "body": "", "state": "", "meta": ""})
                keep = m["body"] and m["state"] != "received"
                m.update(messaging_id=a["messaging_id"], remote_id=it.get("remote_id", ""), seq=it.get("seq", 0),
                         sender_id=it.get("sender_id", 0), kind=it.get("kind", "text"),
                         created_at=it.get("created_at", ""), expires_at=it.get("expires_at") or "")
                if not keep:
                    m["body"] = it.get("body", "")
                    m["meta"] = it.get("meta", "") or m.get("meta", "")
                m["state"] = "sent" if m["sender_id"] == me else "received"
            return len(a["items"]), ("msg", a["messaging_id"])
        if op == "msg.list":
            rows = [m for m in self.msgs.values() if m["messaging_id"] == a["messaging_id"]]
            before, limit = a.get("before_seq", 0), a.get("limit", 50)
            done = sorted([m for m in rows if m["seq"] > 0 and (before == 0 or m["seq"] < before)], key=lambda m: m["seq"])
            page = done[-limit:]
            if before == 0:
                page += [m for m in rows if m["seq"] == 0]
            return page, None
        if op == "msg.pending":
            return [m for m in self.msgs.values() if m["state"] == "pending"][: a.get("limit", 100)], None
        if op == "msg.search":
            q = a["q"].lower()
            return [m for m in self.msgs.values() if q in m["body"].lower()][: a.get("limit", 50)], None
        if op == "msg.purgeExpired":
            dead = [k for k, m in self.msgs.items() if m["expires_at"] and m["expires_at"] < a["now"]]
            for k in dead:
                del self.msgs[k]
            return len(dead), ("msg", None)
        if op == "wipe":
            self.__init__()
            return True, ("conv", None)
        raise ValueError(f"opération inconnue : {op}")


async def main(path):
    store, clients = Store(), set()

    async def handle(reader, writer):
        clients.add(writer)
        try:
            while line := await reader.readline():
                req = json.loads(line)
                try:
                    result, change = store.op(req["op"], req.get("args", {}))
                    resp = {"id": req.get("id"), "ok": True, "result": result}
                except Exception as exc:  # noqa: BLE001
                    resp, change = {"id": req.get("id"), "ok": False, "error": str(exc)}, None
                writer.write((json.dumps(resp) + "\n").encode())
                if change:
                    evt = {"event": "changed", "scope": change[0], "messaging_id": change[1]}
                    for w in list(clients):
                        w.write((json.dumps(evt) + "\n").encode())
                await writer.drain()
        finally:
            clients.discard(writer)

    server = await asyncio.start_unix_server(handle, path=path)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main(sys.argv[1]))
