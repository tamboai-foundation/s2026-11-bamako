"""Moteur des assistants IA : chaque bot est un appareil NGOMA à part entière (NGOMA Ratchet v2)."""
from __future__ import annotations

import json
import logging
import uuid
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import F, Q
from django.utils import timezone

from accounts import prekeys
from accounts.models import Device
from fcrypto import ratchet as r
from messaging import services
from messaging.models import Envelope, Message

from . import llm, vault
from .models import BotProfile, BotSession, BotTurn

log = logging.getLogger("ngoma.bots")
User = get_user_model()
LEASE = timedelta(seconds=120)
OPK_LOW, OPK_BATCH = 10, 50
WELCOME = ("Bonjour, je suis votre assistant IA. Nos échanges sont chiffrés jusqu'au serveur NGOMA, "
           "où je les déchiffre pour les transmettre au fournisseur d'IA que vous avez choisi. "
           "Envoyez /reset pour effacer ma mémoire de la conversation.")


class BotError(Exception):
    pass


# ---------------------------------------------------------------- activation / désactivation

def _publish_prekeys(device: Device, keys: r.DeviceKeys, count: int) -> None:
    up = keys.public_upload(keys.new_opks(count))
    prekeys.publish(device, up["spk_id"], up["spk"], up["spk_sig"], up["opks"])


def activate(owner, *, provider: str, model: str, api_key: str | None, base_url: str = "", system_prompt: str = "") -> BotProfile:
    if provider not in dict(BotProfile.PROVIDERS):
        raise BotError("Fournisseur inconnu")
    if not model.strip():
        raise BotError("Nom du modèle requis")
    try:
        url = llm.validate_base_url(provider, base_url)
    except llm.LLMError as exc:
        raise BotError(str(exc)) from exc
    if not vault.configured():
        raise BotError("Les assistants IA ne sont pas configurés sur ce serveur")

    with transaction.atomic():
        profile = BotProfile.objects.select_for_update().filter(owner=owner).first()
        if profile is None:
            bot_user = User.objects.create_user(f"assistant-{owner.id}-{uuid.uuid4().hex[:6]}", first_name="Assistant IA")
            bot_user.set_unusable_password()
            bot_user.save()
            profile = BotProfile(owner=owner, bot_user=bot_user)
        if not api_key and not profile.api_key_enc:
            raise BotError("Clé API requise")
        fresh_identity = not profile.active or profile.bot_device is None
        profile.provider, profile.model_name = provider, model.strip()[:120]
        profile.base_url = url if base_url else ""
        profile.system_prompt = system_prompt[:4000]
        if api_key:
            profile.api_key_enc = vault.seal(api_key.strip())
        if fresh_identity:
            keys = r.DeviceKeys.generate()
            device, _token = Device.issue(profile.bot_user, "assistant", r.b64e(keys.identity_pk))
            _publish_prekeys(device, keys, OPK_BATCH)
            profile.bot_device = device
            profile.keys_enc = vault.seal_json(keys.d)
            if profile.pk:
                profile.sessions.all().delete()
        profile.active, profile.last_error, profile.updated_at = True, "", timezone.now()
        profile.save()
        conv, _ = services.create_conversation(owner, "direct", [profile.bot_user.id])
        if profile.messaging_id != conv.id:
            profile.messaging = conv
        profile.last_seq = conv.last_seq if fresh_identity else profile.last_seq
        profile.save()
    if fresh_identity:
        try:
            send_text(profile, WELCOME)
        except BotError as exc:  # appareil du propriétaire sans prékeys (ancien client) : pas bloquant
            log.warning("message d'accueil non envoyé : %s", exc)
    return profile


def deactivate(owner) -> None:
    profile = BotProfile.objects.filter(owner=owner).first()
    if profile is None or not profile.active:
        return
    with transaction.atomic():
        if profile.bot_device:
            profile.bot_device.revoke()
        profile.sessions.all().delete()
        profile.turns.all().delete()
        profile.api_key_enc = profile.keys_enc = ""
        profile.active, profile.bot_device, profile.updated_at = False, None, timezone.now()
        profile.save()
        if profile.messaging_id:
            services.add_system_message(profile.messaging_id, profile.bot_user,
                                        "L'assistant IA a été désactivé ; ses clés et son historique ont été effacés.")


# ---------------------------------------------------------------- crypto du bot

class _Runtime:
    def __init__(self, profile: BotProfile):
        self.p = profile
        # Toujours relu en base : une copie périmée pourrait écraser des prékeys publiées entre-temps.
        enc = BotProfile.objects.values_list("keys_enc", flat=True).get(pk=profile.pk)
        self.keys = r.DeviceKeys(vault.open_json(enc))
        self.keys_dirty = False

    def session(self, device_id) -> dict | None:
        row = BotSession.objects.filter(bot=self.p, peer_device_id=device_id).first()
        return vault.open_json(row.state_enc) if row else None

    def save_session(self, device_id, state: dict) -> None:
        BotSession.objects.update_or_create(bot=self.p, peer_device_id=device_id,
                                            defaults={"state_enc": vault.seal_json(state)})

    def flush_keys(self) -> None:
        if self.keys_dirty:
            BotProfile.objects.filter(pk=self.p.pk).update(keys_enc=vault.seal_json(self.keys.d))
            self.keys_dirty = False
        if prekeys.count(self.p.bot_device)["opk_count"] < OPK_LOW:
            _publish_prekeys(self.p.bot_device, self.keys, OPK_BATCH)
            BotProfile.objects.filter(pk=self.p.pk).update(keys_enc=vault.seal_json(self.keys.d))


def send_text(profile: BotProfile, text: str, attempt: int = 0) -> None:
    rt = _Runtime(profile)
    devices = services.expected_devices(profile.messaging, exclude_device=profile.bot_device)
    missing = [str(d.pk) for d in devices if rt.session(d.pk) is None]
    bundles = prekeys.claim(missing) if missing else {}
    plaintext = json.dumps({"v": 1, "t": "text", "b": text}, separators=(",", ":")).encode()
    envelopes = []
    for d in devices:
        s = rt.session(d.pk)
        if s is None:
            b = bundles.get(str(d.pk))
            if b is None or b["identity_key"] != d.public_key:
                raise BotError(f"aucun paquet de prékeys pour l'appareil {d.pk}")
            s = r.initiate(rt.keys, b)
        envelopes.append({"device_id": str(d.pk), "payload": r.encrypt(s, plaintext)})
        rt.save_session(d.pk, s)
    try:
        services.push_message(user=profile.bot_user, device=profile.bot_device, messaging_id=profile.messaging_id,
                              client_id=uuid.uuid4(), envelopes=envelopes)
    except services.DeviceSetMismatch:
        if attempt == 0:
            return send_text(profile, text, attempt + 1)
        raise BotError("liste d'appareils instable") from None
    rt.flush_keys()


# ---------------------------------------------------------------- traitement

def _history(profile: BotProfile) -> list[dict]:
    n = settings.NGOMA["BOT_HISTORY_TURNS"]
    rows = list(profile.turns.order_by("-id")[:n])[::-1]
    return [{"role": t.role, "content": vault.open_(t.content_enc)} for t in rows]


def _remember(profile: BotProfile, role: str, content: str) -> None:
    BotTurn.objects.create(bot=profile, role=role, content_enc=vault.seal(content))
    keep = settings.NGOMA["BOT_HISTORY_TURNS"] * 2
    old = list(profile.turns.order_by("-id").values_list("id", flat=True)[keep:])
    if old:
        BotTurn.objects.filter(id__in=old).delete()


def _acquire(profile_id: int) -> bool:
    now = timezone.now()
    return bool(BotProfile.objects.filter(pk=profile_id, active=True)
                .filter(Q(lease_until__isnull=True) | Q(lease_until__lt=now))
                .update(lease_until=now + LEASE))


def process_bot(profile: BotProfile, http_client=None) -> int:
    """Traite les nouveaux messages d'une conversation de bot. Renvoie le nombre de réponses envoyées."""
    if not _acquire(profile.pk):
        return 0
    replies = 0
    try:
        profile.refresh_from_db()
        msgs = list(Message.objects.filter(messaging_id=profile.messaging_id, seq__gt=profile.last_seq).order_by("seq")[:50])
        for m in msgs:
            BotProfile.objects.filter(pk=profile.pk).update(last_seq=m.seq, lease_until=timezone.now() + LEASE)
            if m.sender_id != profile.owner_id or m.kind == Message.SYSTEM:
                continue
            env = Envelope.objects.filter(message=m, device=profile.bot_device).first()
            if env is None or m.sender_device is None:
                continue
            rt = _Runtime(profile)
            try:
                pt, state = r.decrypt(rt.keys, rt.session(m.sender_device_id), json.loads(env.payload))
            except r.CryptoError as exc:
                log.warning("bot %s : message %s indéchiffrable (%s)", profile.pk, m.seq, exc)
                continue
            if state["peer_ik"] != m.sender_device.public_key:  # épinglage : identité de l'appareil émetteur
                log.warning("bot %s : identité d'appareil inattendue", profile.pk)
                continue
            rt.save_session(m.sender_device_id, state)
            rt.keys_dirty = True
            rt.flush_keys()
            body = json.loads(pt)
            if body.get("t") != "text":
                send_text(profile, "Je ne traite que les messages texte pour le moment.")
                replies += 1
                continue
            text = str(body.get("b", "")).strip()
            if text == "/reset":
                profile.turns.all().delete()
                send_text(profile, "Mémoire de la conversation effacée.")
                replies += 1
                continue
            _remember(profile, "user", text)
            try:
                answer = llm.complete(provider=profile.provider, base_url=llm.validate_base_url(profile.provider, profile.base_url),
                                      model=profile.model_name, api_key=vault.open_(profile.api_key_enc),
                                      system_prompt=profile.system_prompt, history=_history(profile), client=http_client)
                _remember(profile, "assistant", answer)
                BotProfile.objects.filter(pk=profile.pk).update(last_error="")
            except llm.LLMError as exc:
                answer = f"⚠ Le fournisseur d'IA n'a pas pu répondre ({exc})."
                BotProfile.objects.filter(pk=profile.pk).update(last_error=str(exc)[:300])
            send_text(profile, answer)
            replies += 1
    finally:
        BotProfile.objects.filter(pk=profile.pk).update(lease_until=None)
    return replies


def pending_profiles():
    return BotProfile.objects.filter(active=True, messaging__last_seq__gt=F("last_seq")).select_related(
        "messaging", "bot_device", "bot_user")
