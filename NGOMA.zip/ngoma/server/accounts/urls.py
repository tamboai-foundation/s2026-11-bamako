from django.urls import path

from . import views

urlpatterns = [
    path("auth/signup", views.SignupView.as_view()),
    path("auth/enroll", views.EnrollDeviceView.as_view()),
    path("me", views.MeView.as_view()),
    path("me/devices", views.OwnDevicesView.as_view()),
    path("me/devices/<uuid:device_id>/revoke", views.RevokeDeviceView.as_view()),
    path("users/search", views.UserSearchView.as_view()),
    path("users/devices", views.UserDevicesView.as_view()),
    path("keys/prekeys", views.PreKeysView.as_view()),
    path("keys/claim", views.ClaimPreKeysView.as_view()),
]
