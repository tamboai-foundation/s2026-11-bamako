import json
import secrets
import uuid

import httpx
import pytest
import respx
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from rest_framework.test import APIClient

from accounts.models import Device, OneTimePreKey
from bots import engine
from bots.models import BotProfile, BotTurn
from fcrypto import ratchet as r

pytestmark = pytest.mark.django_db
PASSWORD = secrets.token_urlsafe(16)
CODE = secrets.token_urlsafe(12)
API_KEY = secrets.token_urlsafe(24)
User = get_user_model()


class Terminal:
    """Terminal simulé (même protocole que le client C++)."""

    def __init__(self, username, device="t"):
        self.user = User.objects.filter(username=username).first() or User.objects.create_user(username, password=secrets.token_urlsafe(16))
        self.keys = r.DeviceKeys.generate()
        self.device, token = Device.issue(self.user, device, r.b64e(self.keys.identity_pk))
        self.api = APIClient()
        self.api.credentials(HTTP_AUTHORIZATION=f"Device {token}")
        self.sessions = {}
        self.cursor = {}
        up = self.keys.public_upload(self.keys.new_opks(5))
        assert self.api.post("/api/v1/keys/prekeys", up, format="json").status_code == 200

    def send(self, conv_id, text):
        devices = [d for d in self.api.get(f"/api/v1/conversations/{conv_id}/devices").json()
                   if d["device_id"] != str(self.device.pk)]
        missing = [d["device_id"] for d in devices if d["device_id"] not in self.sessions]
        bundles = self.api.post("/api/v1/keys/claim", {"device_ids": missing}, format="json").json() if missing else {}
        pt = json.dumps({"v": 1, "t": "text", "b": text}).encode()
        envs = []
        for d in devices:
            s = self.sessions.get(d["device_id"]) or r.initiate(self.keys, bundles[d["device_id"]])
            envs.append({"device_id": d["device_id"], "payload": r.encrypt(s, pt)})
            self.sessions[d["device_id"]] = s
        return self.api.post("/api/v1/sync/push", {"messaging_id": conv_id, "client_id": str(uuid.uuid4()),
                                                   "envelopes": envs}, format="json")

    def receive(self, conv_id, after=None):
        """Comme le vrai client : lit à partir de son curseur (un message déjà déchiffré ne peut pas l'être à nouveau)."""
        out = []
        after = self.cursor.get(conv_id, 0) if after is None else after
        for it in self.api.get(f"/api/v1/sync/pull?messaging_id={conv_id}&after_seq={after}").json()["items"]:
            self.cursor[conv_id] = it["seq"]
            if it["kind"] == "system":
                out.append(("system", it["system_text"]))
                continue
            if it["envelope"] is None:
                continue
            dev = it["sender_device_id"]
            pt, self.sessions[dev] = r.decrypt(self.keys, self.sessions.get(dev), it["envelope"])
            out.append((it["sender_id"], json.loads(pt)["b"]))
        return out


# ---------------------------------------------------------------- prékeys

def test_prekeys_publish_claim_once_and_signature_checked():
    a, b = Terminal("alice"), Terminal("bob")
    conv = a.api.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.user.id]}, format="json").json()
    assert b.api.get("/api/v1/keys/prekeys").json()["opk_count"] == 5
    got = a.api.post("/api/v1/keys/claim", {"device_ids": [str(b.device.pk)]}, format="json").json()
    assert got[str(b.device.pk)]["opk_id"] is not None
    assert OneTimePreKey.objects.filter(device=b.device).count() == 4
    r.verify_bundle(got[str(b.device.pk)])
    # signature falsifiée refusée
    up = b.keys.public_upload([])
    up["spk"] = r.b64e(r.random_bytes(32))
    assert b.api.post("/api/v1/keys/prekeys", up, format="json").status_code == 400
    # un inconnu ne peut pas réserver les prékeys de Bob
    m = Terminal("mallory")
    assert m.api.post("/api/v1/keys/claim", {"device_ids": [str(b.device.pk)]}, format="json").json() == {}
    assert conv["id"]


def test_end_to_end_ratchet_through_server():
    a, b = Terminal("alice"), Terminal("bob")
    conv = a.api.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.user.id]}, format="json").json()["id"]
    assert a.send(conv, "un").status_code == 201
    assert a.send(conv, "deux").status_code == 201
    assert [t for _, t in b.receive(conv)] == ["un", "deux"]
    assert b.send(conv, "trois").status_code == 201
    assert a.receive(conv) == [(b.user.id, "trois")]


def test_rejects_malformed_v2_envelope():
    a, b = Terminal("alice"), Terminal("bob")
    conv = a.api.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.user.id]}, format="json").json()["id"]
    bad = {"v": 2, "type": "msg", "h": "AAAA", "c": "AAAA"}
    r_ = a.api.post("/api/v1/sync/push", {"messaging_id": conv, "client_id": str(uuid.uuid4()),
                                          "envelopes": [{"device_id": str(b.device.pk), "payload": bad}]}, format="json")
    assert r_.status_code == 400


# ---------------------------------------------------------------- pièces jointes et appels

def test_media_upload_download_membership(tmp_path, settings):
    settings.MEDIA_ROOT = tmp_path
    a, b, m = Terminal("alice"), Terminal("bob"), Terminal("mallory")
    conv = a.api.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.user.id]}, format="json").json()["id"]
    blob = r.random_bytes(5000)
    up = a.api.post("/api/v1/media", {"messaging_id": conv, "file": SimpleUploadedFile("x.bin", blob)}, format="multipart")
    assert up.status_code == 201
    mid = up.json()["media_id"]
    got = b.api.get(f"/api/v1/media/{mid}")
    assert got.status_code == 200 and b"".join(got.streaming_content) == blob
    assert m.api.get(f"/api/v1/media/{mid}").status_code == 404


def test_call_token_is_hmac():
    import hashlib
    import hmac

    from django.conf import settings

    a, b = Terminal("alice"), Terminal("bob")
    conv = a.api.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.user.id]}, format="json").json()["id"]
    call_id = uuid.uuid4()
    t = a.api.post("/api/v1/calls/token", {"messaging_id": conv, "call_id": str(call_id)}, format="json").json()
    msg = call_id.bytes + a.user.id.to_bytes(8, "big") + a.device.pk.bytes + t["exp"].to_bytes(8, "big")
    assert t["token"] == hmac.new(settings.NGOMA["RELAY_SECRET"].encode(), msg, hashlib.sha256).hexdigest()
    assert Terminal("mallory").api.post("/api/v1/calls/token", {"messaging_id": conv, "call_id": str(call_id)},
                                        format="json").status_code == 404


# ---------------------------------------------------------------- assistants IA

@pytest.fixture
def private_llm(settings):
    settings.NGOMA = {**settings.NGOMA, "BOT_ALLOW_PRIVATE_BASE_URL": True}


def test_bot_ssrf_protection():
    owner = Terminal("alice")
    for url in ["http://api.example.com", "https://127.0.0.1", "https://10.0.0.5", "https://localhost"]:
        res = owner.api.post("/api/v1/bots/me", {"provider": "openai", "model": "m", "api_key": "k", "base_url": url},
                             format="json")
        assert res.status_code == 400, url


@respx.mock
def test_bot_full_cycle_openai_compatible(private_llm):
    route = respx.post("http://llm.local/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={"choices": [{"message": {"content": "Paris."}}]}))
    owner = Terminal("alice")
    res = owner.api.post("/api/v1/bots/me", {"provider": "openai", "model": "test-model", "api_key": API_KEY,
                                             "base_url": "http://llm.local", "system_prompt": "Sois bref."}, format="json")
    assert res.status_code == 201, res.content
    st = res.json()
    assert st["active"] and st["api_key_set"] and "api_key" not in st
    conv = st["conversation_id"]
    # le bot a initié la session (X3DH côté Python) avec un message d'accueil
    welcome = owner.receive(conv)
    assert welcome[0][1].startswith("Bonjour, je suis votre assistant IA")

    assert owner.send(conv, "Quelle est la capitale de la France ?").status_code == 201
    profile = BotProfile.objects.get(owner=owner.user)
    assert engine.process_bot(profile) == 1
    sent = json.loads(route.calls.last.request.content)
    assert route.calls.last.request.headers["authorization"] == f"Bearer {API_KEY}"
    assert sent["messages"][0] == {"role": "system", "content": "Sois bref."}
    assert sent["messages"][-1] == {"role": "user", "content": "Quelle est la capitale de la France ?"}
    assert owner.receive(conv)[-1] == (profile.bot_user_id, "Paris.")
    # la clé API est chiffrée au repos
    assert API_KEY not in BotProfile.objects.get(pk=profile.pk).api_key_enc


@respx.mock
def test_bot_anthropic_errors_reset_and_deactivate(private_llm):
    route = respx.post("http://llm.local/v1/messages").mock(side_effect=[
        httpx.Response(500, json={}),
        httpx.Response(200, json={"content": [{"type": "text", "text": "Rebonjour"}]}),
    ])
    owner = Terminal("alice")
    owner.api.post("/api/v1/bots/me", {"provider": "anthropic", "model": "claude-test", "api_key": API_KEY,
                                       "base_url": "http://llm.local"}, format="json")
    profile = BotProfile.objects.get(owner=owner.user)
    conv = str(profile.messaging_id)
    owner.receive(conv)
    owner.send(conv, "salut")
    engine.process_bot(profile)
    assert "n'a pas pu répondre" in owner.receive(conv)[-1][1]
    assert BotProfile.objects.get(pk=profile.pk).last_error
    owner.send(conv, "encore")
    engine.process_bot(profile)
    req = json.loads(route.calls.last.request.content)
    assert route.calls.last.request.headers["x-api-key"] == API_KEY
    assert [m["role"] for m in req["messages"]] == ["user"]  # tours utilisateur consécutifs fusionnés
    owner.send(conv, "/reset")
    engine.process_bot(profile)
    assert BotTurn.objects.filter(bot=profile).count() == 0

    assert owner.api.delete("/api/v1/bots/me").json()["active"] is False
    p = BotProfile.objects.get(pk=profile.pk)
    assert p.api_key_enc == "" and p.keys_enc == "" and p.sessions.count() == 0
    last = owner.receive(conv)[-1]
    assert last[0] == "system" and "désactivé" in last[1]
    # après désactivation, l'appareil du bot n'est plus destinataire
    devs = owner.api.get(f"/api/v1/conversations/{conv}/devices").json()
    assert all(d["user_id"] != profile.bot_user_id for d in devs)


def test_bot_not_in_search_and_cannot_have_bot(private_llm):
    owner = Terminal("alice")
    with respx.mock:
        owner.api.post("/api/v1/bots/me", {"provider": "openai", "model": "m", "api_key": "k",
                                           "base_url": "http://llm.local"}, format="json")
    assert owner.api.get("/api/v1/users/search?q=assistant").json() == []
