// Ngoma — types échangés par iceoryx2 entre processus du terminal.
// Règles : types trivialement copiables, taille fixe, aucun pointeur, champ de version ABI.
#pragma once

#include <cstdint>

namespace ngoma::ipc {

constexpr std::uint32_t kAbiVersion = 2;

// Noms de services iceoryx2 (domaine « ngoma »).
constexpr const char* kSvcVideoLocal = "ngoma/media/video/local";    // capture locale → UI
constexpr const char* kSvcVideoRemote = "ngoma/media/video/remote";  // flux distant décodé → UI
constexpr const char* kSvcAudioLevel = "ngoma/media/audio/level";    // niveaux micro/haut-parleur → UI
constexpr const char* kSvcCallControl = "ngoma/call/control";        // cœur → ngoma-media
constexpr const char* kSvcCallState = "ngoma/call/state";            // ngoma-media → cœur
constexpr const char* kSvcMessageEvent = "ngoma/events/message";     // cœur → services locaux (LED, buzzer…)

enum class PixelFormat : std::uint32_t { Rgb32 = 1, Nv12 = 2 };

/// En-tête utilisateur placé devant chaque trame vidéo (charge utile = Slice<uint8_t>).
struct VideoFrameHeader {
    static constexpr const char* IOX2_TYPE_NAME = "ngoma::VideoFrameHeader";
    std::uint32_t abi = kAbiVersion;
    std::uint32_t width = 0;
    std::uint32_t height = 0;
    std::uint32_t stride = 0;
    PixelFormat format = PixelFormat::Rgb32;
    std::uint32_t reserved = 0;
    std::uint64_t pts_us = 0;
    std::uint64_t frame_no = 0;
};

struct AudioLevel {
    static constexpr const char* IOX2_TYPE_NAME = "ngoma::AudioLevel";
    std::uint32_t abi = kAbiVersion;
    float mic_rms = 0.f;
    float speaker_rms = 0.f;
    std::uint32_t reserved = 0;
};

enum class CallCommand : std::uint32_t { Start = 1, Stop = 2, Mute = 3, Unmute = 4, CameraOn = 5, CameraOff = 6 };

/// Commande d'appel. Pour Start : coordonnées du relais, jeton d'accès et clé média E2EE de l'appel.
/// La clé ne transite que par la mémoire partagée locale (utilisateur système ngoma, 0600).
struct CallControl {
    static constexpr const char* IOX2_TYPE_NAME = "ngoma::CallControl";
    std::uint32_t abi = kAbiVersion;
    CallCommand command = CallCommand::Stop;
    std::uint64_t call_seq = 0;
    char call_id[40] = {};      // UUID texte
    std::uint32_t width = 640;
    std::uint32_t height = 480;
    std::uint32_t fps = 15;
    std::uint32_t relay_port = 0;
    char relay_host[64] = {};
    char token[72] = {};        // HMAC hexadécimal (64 caractères)
    std::uint64_t user_id = 0;
    std::uint64_t exp = 0;
    char device_id[40] = {};    // UUID texte de cet appareil
    std::uint8_t call_key[32] = {};
};

enum class MediaState : std::uint32_t { Idle = 0, Starting = 1, Running = 2, Error = 3 };

struct CallState {
    static constexpr const char* IOX2_TYPE_NAME = "ngoma::CallState";
    std::uint32_t abi = kAbiVersion;
    MediaState state = MediaState::Idle;
    std::uint64_t call_seq = 0;
    std::uint32_t frames_sent = 0;
    std::uint32_t reserved = 0;
};

struct MessageEvent {
    static constexpr const char* IOX2_TYPE_NAME = "ngoma::MessageEvent";
    std::uint32_t abi = kAbiVersion;
    std::uint32_t unread_total = 0;
    char messaging_id[40] = {};
};

}  // namespace ngoma::ipc
