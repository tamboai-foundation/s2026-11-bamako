#pragma once

#include <QDateTime>
#include <QRandomGenerator>
#include <QString>
#include <array>
#include <cstdint>

namespace ngoma {

/// UUID version 7 (RFC 9562) : triable dans le temps, généré hors ligne. Sert de clé d'idempotence.
inline QString uuid7() {
    std::array<std::uint8_t, 16> b{};
    const std::uint64_t ms = static_cast<std::uint64_t>(QDateTime::currentMSecsSinceEpoch());
    for (int i = 0; i < 6; ++i) b[size_t(i)] = std::uint8_t(ms >> (8 * (5 - i)));
    auto* rng = QRandomGenerator::system();
    for (size_t i = 6; i < 16; ++i) b[i] = std::uint8_t(rng->bounded(256));
    b[6] = std::uint8_t((b[6] & 0x0F) | 0x70);  // version 7
    b[8] = std::uint8_t((b[8] & 0x3F) | 0x80);  // variante RFC
    static const char* hex = "0123456789abcdef";
    QString out;
    out.reserve(36);
    for (size_t i = 0; i < 16; ++i) {
        if (i == 4 || i == 6 || i == 8 || i == 10) out.append(QLatin1Char('-'));
        out.append(QLatin1Char(hex[b[i] >> 4]));
        out.append(QLatin1Char(hex[b[i] & 0x0F]));
    }
    return out;
}

}  // namespace ngoma
