// NGOMA Ratchet v2 — X3DH + Double Ratchet (jumeau C++ de server/fcrypto/ratchet.py).
// Spécification : docs/CRYPTO.md. Les états sont des objets JSON pour être persistés tels quels.
#pragma once

#include <QByteArray>
#include <QJsonArray>
#include <QJsonObject>
#include <QString>
#include <optional>

namespace ngoma::ratchet {

struct Error {
    QString message;
};

/// Clés privées de l'appareil : identité Ed25519, prékey signée (courante + précédente), prékeys à usage unique.
class DeviceKeys {
public:
    DeviceKeys() = default;
    explicit DeviceKeys(QJsonObject d) : m_d(std::move(d)) {}
    static DeviceKeys generate();

    bool valid() const { return identityPublic().size() == 32 && identitySecret64().size() == 64; }
    QByteArray identityPublic() const;
    QByteArray identitySecret64() const;
    const QJsonObject& json() const { return m_d; }

    QJsonObject rotateSignedPrekey();
    QJsonArray newOneTimePrekeys(int count);
    /// Corps de POST keys/prekeys.
    QJsonObject publicUpload(const QJsonArray& opks) const;
    int oneTimePrekeyCount() const { return int(m_d.value(QStringLiteral("opks")).toObject().size()); }
    qint64 signedPrekeyCreatedAt() const;

    std::optional<QByteArray> signedPrekeySecret(int id) const;
    std::optional<QByteArray> oneTimePrekeySecret(int id) const;
    void dropOneTimePrekey(int id);

private:
    QJsonObject m_d;
};

/// Vérifie la signature de la prékey signée d'un paquet `{identity_key, spk_id, spk, spk_sig, opk_id?, opk?}`.
bool verifyBundle(const QJsonObject& bundle);

/// Ouvre une session vers un appareil (rôle initiateur).
std::optional<QJsonObject> initiate(const DeviceKeys& me, const QJsonObject& bundle, QString* error = nullptr);

/// Chiffre `plaintext` et fait avancer la chaîne d'envoi. Renvoie l'enveloppe v2 `{v, type, h, c, x?}`.
std::optional<QJsonObject> encrypt(QJsonObject& session, const QByteArray& plaintext);

struct Decrypted {
    QByteArray plaintext;
    QJsonObject session;   // nouvel état à persister
    bool consumedOneTimePrekey = false;
    int oneTimePrekeyId = -1;
};

/// Déchiffre une enveloppe v2. `session` peut être vide (aucune session existante).
/// L'état n'est modifié qu'en cas de succès : l'appelant persiste `Decrypted::session` (et retire la prékey consommée).
std::optional<Decrypted> decrypt(const DeviceKeys& me, const QJsonObject& session, const QJsonObject& envelope,
                                 QString* error = nullptr);

/// Clé d'identité du pair dans une session (pour l'épinglage TOFU).
QByteArray peerIdentity(const QJsonObject& session);

}  // namespace ngoma::ratchet
