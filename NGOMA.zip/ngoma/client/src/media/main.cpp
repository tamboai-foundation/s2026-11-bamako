// ngoma-media — moteur média du terminal (sans Qt, ordonnançable en temps réel).
//
//   cœur Qt ──iceoryx2 (commande, clé d'appel)──► ngoma-media ──UDP chiffré──► ngoma-relay ──► pair
//   caméra V4L2 / mire ─► H.264 ─┐                         ▲
//   micro ALSA / test   ─► Opus ─┴─► SecureTransport ──────┘
//   pair ─► déchiffrement ─► tampon de gigue / réassemblage ─► Opus / H.264 ─► haut-parleur, iceoryx2 (UI)
//
// Toutes les trames vidéo vers l'UI passent en mémoire partagée (iceoryx2, sans copie côté producteur).
// Variables : NGOMA_CAMERA, NGOMA_AUDIO_TEST, NGOMA_ALSA_DEVICE, NGOMA_H264_ENCODER,
//             NGOMA_IPC_PREFIX (bancs d'essai : plusieurs terminaux sur une même machine).
#include <fcntl.h>
#include <linux/videodev2.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

#include <sodium.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <csignal>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <map>
#include <optional>
#include <string>
#include <vector>

#include "iox2/iceoryx2.hpp"
#include "ipc/IpcTypes.h"
#include "media/Codecs.h"
#include "media/Transport.h"

using namespace iox2;
namespace fipc = ngoma::ipc;
namespace fm = ngoma::media;
namespace fw = ngoma::wire;
using Clock = std::chrono::steady_clock;

namespace {

std::atomic<bool> g_stop{false};
std::string g_prefix;

ServiceName svc(const char* name) { return ServiceName::create((g_prefix + name).c_str()).value(); }

inline std::uint8_t clamp8(int v) { return static_cast<std::uint8_t>(v < 0 ? 0 : (v > 255 ? 255 : v)); }

/// Source V4L2 minimale (mmap, YUYV) convertie en BGRx.
class V4l2Camera {
public:
    bool open(const char* dev, std::uint32_t w, std::uint32_t h, std::uint32_t fps) {
        fd_ = ::open(dev, O_RDWR | O_NONBLOCK);
        if (fd_ < 0) return false;
        v4l2_format fmt{};
        fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        fmt.fmt.pix.width = w;
        fmt.fmt.pix.height = h;
        fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
        fmt.fmt.pix.field = V4L2_FIELD_NONE;
        if (ioctl(fd_, VIDIOC_S_FMT, &fmt) < 0 || fmt.fmt.pix.pixelformat != V4L2_PIX_FMT_YUYV) return fail();
        width_ = fmt.fmt.pix.width;
        height_ = fmt.fmt.pix.height;
        stride_ = fmt.fmt.pix.bytesperline;
        v4l2_streamparm parm{};
        parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        parm.parm.capture.timeperframe = {1, fps};
        ioctl(fd_, VIDIOC_S_PARM, &parm);
        v4l2_requestbuffers req{};
        req.count = 4;
        req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        req.memory = V4L2_MEMORY_MMAP;
        if (ioctl(fd_, VIDIOC_REQBUFS, &req) < 0 || req.count < 2) return fail();
        for (std::uint32_t i = 0; i < req.count; ++i) {
            v4l2_buffer b{};
            b.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            b.memory = V4L2_MEMORY_MMAP;
            b.index = i;
            if (ioctl(fd_, VIDIOC_QUERYBUF, &b) < 0) return fail();
            void* p = mmap(nullptr, b.length, PROT_READ | PROT_WRITE, MAP_SHARED, fd_, b.m.offset);
            if (p == MAP_FAILED) return fail();
            bufs_.push_back({p, b.length});
            if (ioctl(fd_, VIDIOC_QBUF, &b) < 0) return fail();
        }
        v4l2_buf_type t = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        if (ioctl(fd_, VIDIOC_STREAMON, &t) < 0) return fail();
        return true;
    }
    bool grab(std::uint8_t* dst) {
        v4l2_buffer b{};
        b.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        b.memory = V4L2_MEMORY_MMAP;
        if (ioctl(fd_, VIDIOC_DQBUF, &b) < 0) return false;
        const auto* src = static_cast<const std::uint8_t*>(bufs_[b.index].ptr);
        for (std::uint32_t y = 0; y < height_; ++y) {
            const std::uint8_t* row = src + std::size_t(y) * stride_;
            std::uint8_t* out = dst + std::size_t(y) * width_ * 4;
            for (std::uint32_t x = 0; x + 1 < width_; x += 2) {
                const int y0 = row[0] - 16, u = row[1] - 128, y1 = row[2] - 16, v = row[3] - 128;
                for (int k = 0; k < 2; ++k) {
                    const int c = 298 * (k == 0 ? y0 : y1);
                    out[0] = clamp8((c + 516 * u + 128) >> 8);
                    out[1] = clamp8((c - 100 * u - 208 * v + 128) >> 8);
                    out[2] = clamp8((c + 409 * v + 128) >> 8);
                    out[3] = 0xFF;
                    out += 4;
                }
                row += 4;
            }
        }
        ioctl(fd_, VIDIOC_QBUF, &b);
        return true;
    }
    void close() {
        if (fd_ < 0) return;
        v4l2_buf_type t = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        ioctl(fd_, VIDIOC_STREAMOFF, &t);
        for (auto& b : bufs_) munmap(b.ptr, b.len);
        bufs_.clear();
        ::close(fd_);
        fd_ = -1;
    }
    ~V4l2Camera() { close(); }
    std::uint32_t width() const { return width_; }
    std::uint32_t height() const { return height_; }

private:
    bool fail() {
        close();
        return false;
    }
    struct Buf {
        void* ptr;
        std::size_t len;
    };
    int fd_ = -1;
    std::uint32_t width_ = 0, height_ = 0, stride_ = 0;
    std::vector<Buf> bufs_;
};

void testPattern(std::uint8_t* dst, std::uint32_t w, std::uint32_t h, std::uint64_t n) {
    static constexpr std::uint32_t colors[8] = {0xFFFFFFFF, 0xFFFFFF00, 0xFF00FFFF, 0xFF00FF00,
                                                0xFFFF00FF, 0xFFFF0000, 0xFF0000FF, 0xFF202020};
    for (std::uint32_t y = 0; y < h; ++y) {
        auto* px = reinterpret_cast<std::uint32_t*>(dst + std::size_t(y) * w * 4);
        for (std::uint32_t x = 0; x < w; ++x) px[x] = colors[((x + n * 4) / (w / 8 + 1)) % 8];
    }
}

using VideoPub = Publisher<ServiceType::Ipc, bb::Slice<uint8_t>, fipc::VideoFrameHeader>;

void publishFrame(VideoPub& pub, const std::uint8_t* bgrx, std::uint32_t w, std::uint32_t h, std::uint64_t n) {
    auto loan = pub.loan_slice_uninit(std::uint64_t(w) * h * 4);
    if (!loan.has_value()) return;
    auto smp = std::move(loan.value());
    std::memcpy(smp.payload_mut().data(), bgrx, std::size_t(w) * h * 4);
    auto& hdr = smp.user_header_mut();
    hdr = fipc::VideoFrameHeader{};
    hdr.width = w;
    hdr.height = h;
    hdr.stride = w * 4;
    hdr.format = fipc::PixelFormat::Rgb32;
    hdr.frame_no = n;
    hdr.pts_us = std::uint64_t(std::chrono::duration_cast<std::chrono::microseconds>(Clock::now().time_since_epoch()).count());
    send(assume_init(std::move(smp))).has_value();
}

/// État de réception d'un pair (un par appareil distant).
struct RemotePeer {
    fm::OpusCodec opus;
    fm::JitterBuffer jitter;
    fm::FrameAssembler assembler;
    fm::VideoDecoder video;
    Clock::time_point lastKeyRequest{};
    bool ready = false;
};

}  // namespace

int main() {
    std::signal(SIGINT, [](int) { g_stop = true; });
    std::signal(SIGTERM, [](int) { g_stop = true; });
    set_log_level_from_env_or(LogLevel::Warn);
    if (sodium_init() < 0) return 2;
    if (const char* p = std::getenv("NGOMA_IPC_PREFIX")) g_prefix = p;
    const char* camDev = std::getenv("NGOMA_CAMERA") ? std::getenv("NGOMA_CAMERA") : "/dev/video0";

    auto node = NodeBuilder().name(NodeName::create("ngoma-media").value()).create<ServiceType::Ipc>().value();
    auto fixed = [&](const char* name) {
        return node.service_builder(svc(name));
    };
    auto ctlSvc = fixed(fipc::kSvcCallControl).publish_subscribe<fipc::CallControl>()
                      .history_size(1).subscriber_max_buffer_size(4).enable_safe_overflow(true).open_or_create().value();
    auto stSvc = fixed(fipc::kSvcCallState).publish_subscribe<fipc::CallState>()
                     .history_size(1).subscriber_max_buffer_size(4).enable_safe_overflow(true).open_or_create().value();
    auto auSvc = fixed(fipc::kSvcAudioLevel).publish_subscribe<fipc::AudioLevel>()
                     .history_size(1).subscriber_max_buffer_size(4).enable_safe_overflow(true).open_or_create().value();
    auto video = [&](const char* name) {
        return fixed(name).publish_subscribe<bb::Slice<uint8_t>>().user_header<fipc::VideoFrameHeader>()
            .history_size(0).subscriber_max_buffer_size(2).enable_safe_overflow(true).open_or_create().value();
    };
    auto localSvc = video(fipc::kSvcVideoLocal);
    auto remoteSvc = video(fipc::kSvcVideoRemote);

    auto control = ctlSvc.subscriber_builder().create().value();
    auto state = stSvc.publisher_builder().create().value();
    auto audioLevel = auSvc.publisher_builder().create().value();
    auto localPub = localSvc.publisher_builder().initial_max_slice_len(1280 * 720 * 4)
                        .allocation_strategy(AllocationStrategy::PowerOfTwo).create().value();
    auto remotePub = remoteSvc.publisher_builder().initial_max_slice_len(1280 * 720 * 4)
                         .allocation_strategy(AllocationStrategy::PowerOfTwo).create().value();

    auto publishState = [&](fipc::MediaState s, std::uint64_t seq, std::uint32_t frames) {
        auto smp = state.loan_uninit();
        if (smp.has_value()) send(smp.value().write_payload(fipc::CallState{fipc::kAbiVersion, s, seq, frames, 0})).has_value();
    };

    // ---- état de l'appel
    bool running = false, cameraOn = true, muted = false;
    std::uint64_t callSeq = 0;
    std::uint32_t w = 640, h = 480, fps = 15, frames = 0, frameId = 0;
    std::optional<V4l2Camera> cam;
    std::vector<std::uint8_t> bgrx;
    fm::SecureTransport transport;
    fm::AudioCapture mic;
    fm::AudioPlayback speaker;
    fm::OpusCodec opusEnc;
    std::optional<fm::VideoEncoder> encoder;
    std::map<fw::Uuid, RemotePeer> peers;
    bool keyframeWanted = true;
    std::uint32_t audioTs = 0;
    auto videoPeriod = std::chrono::milliseconds(1000 / 15);
    const auto audioPeriod = std::chrono::milliseconds(20);
    auto nextVideo = Clock::now(), nextAudio = Clock::now(), lastLevel = Clock::now();
    float micLevel = 0.f, speakerLevel = 0.f;

    auto stopCall = [&] {
        running = false;
        transport.close();
        cam.reset();
        encoder.reset();
        peers.clear();
        mic.close();
        speaker.close();
    };

    std::fprintf(stderr, "ngoma-media prêt (préfixe IPC : « %s », caméra : %s)\n", g_prefix.c_str(), camDev);
    publishState(fipc::MediaState::Idle, 0, 0);

    std::int16_t pcm[fm::kFrameSamples], mix[fm::kFrameSamples], tmp[fm::kFrameSamples];
    std::uint8_t opusBuf[400];
    std::vector<std::uint8_t> decoded, frame, pkt;

    while (!g_stop) {
        for (auto s = control.receive(); s.has_value() && s.value().has_value(); s = control.receive()) {
            const auto& c = s.value()->payload();
            if (c.abi != fipc::kAbiVersion) continue;
            switch (c.command) {
            case fipc::CallCommand::Start: {
                stopCall();
                callSeq = c.call_seq;
                fps = c.fps ? c.fps : 15;
                w = c.width ? c.width : 640;
                h = c.height ? c.height : 480;
                videoPeriod = std::chrono::milliseconds(1000 / fps);
                cam.emplace();
                if (!cam->open(camDev, w, h, fps)) cam.reset();
                else {
                    w = cam->width();
                    h = cam->height();
                }
                bgrx.assign(std::size_t(w) * h * 4, 0);
                frames = 0;
                running = true;
                std::string err;
                if (c.relay_port != 0) {  // appel réseau ; sinon aperçu local seul
                    if (!transport.open(c, err)) {
                        std::fprintf(stderr, "ngoma-media : %s\n", err.c_str());
                        publishState(fipc::MediaState::Error, callSeq, 0);
                    } else {
                        std::string encName;
                        encoder.emplace();
                        if (!encoder->open(int(w), int(h), int(fps), 600, encName)) {
                            std::fprintf(stderr, "ngoma-media : aucun encodeur H.264, appel audio seul\n");
                            encoder.reset();
                        } else {
                            std::fprintf(stderr, "ngoma-media : encodeur %s %ux%u@%u\n", encName.c_str(), w, h, fps);
                        }
                        opusEnc.init();
                        mic.open();
                        speaker.open();
                        keyframeWanted = true;
                    }
                }
                publishState(fipc::MediaState::Running, callSeq, 0);
                break;
            }
            case fipc::CallCommand::Stop:
                stopCall();
                publishState(fipc::MediaState::Idle, callSeq, frames);
                break;
            case fipc::CallCommand::CameraOff: cameraOn = false; break;
            case fipc::CallCommand::CameraOn: cameraOn = true; break;
            case fipc::CallCommand::Mute: muted = true; break;
            case fipc::CallCommand::Unmute: muted = false; break;
            }
        }

        const auto now = Clock::now();
        if (running) {
            transport.tick();

            // ---- réception
            transport.poll([&](const fw::Uuid& sender, fw::Kind kind, const std::uint8_t* d, std::size_t len) {
                auto& peer = peers[sender];
                if (!peer.ready) {
                    peer.ready = peer.opus.init() && peer.video.open();
                }
                if (kind == fw::Audio && len > 4) {
                    peer.jitter.push(std::uint32_t(fw::getBe(d, 4)), d + 4, len - 4);
                } else if (kind == fw::Video && len > 13) {
                    const auto fid = std::uint32_t(fw::getBe(d, 4));
                    const auto idx = std::uint16_t(fw::getBe(d + 4, 2));
                    const auto cnt = std::uint16_t(fw::getBe(d + 6, 2));
                    const bool key = d[8] & 1;
                    bool isKey = false;
                    if (peer.assembler.add(fid, idx, cnt, key, d + 13, len - 13, frame, isKey)) {
                        int dw = 0, dh = 0;
                        if (peer.video.decode(frame.data(), frame.size(), decoded, dw, dh))
                            publishFrame(remotePub, decoded.data(), std::uint32_t(dw), std::uint32_t(dh), fid);
                    }
                    if (peer.assembler.needsKeyframe() && now - peer.lastKeyRequest > std::chrono::seconds(1)) {
                        const std::uint8_t req = fw::KeyframeRequest;
                        transport.send(fw::Control, &req, 1);
                        peer.lastKeyRequest = now;
                    }
                } else if (kind == fw::Control && len >= 1 && d[0] == fw::KeyframeRequest) {
                    keyframeWanted = true;
                }
            });

            // ---- audio : 20 ms
            while (now >= nextAudio) {
                nextAudio += audioPeriod;
                if (transport.isOpen()) {
                    if (mic.read(pcm)) {
                        micLevel = std::max(micLevel * 0.8f, fm::rms(pcm, fm::kFrameSamples));
                        if (!muted) {
                            const int n = opusEnc.encode(pcm, opusBuf + 4, int(sizeof opusBuf) - 4);
                            if (n > 0) {
                                fw::putBe(opusBuf, audioTs, 4);
                                transport.send(fw::Audio, opusBuf, std::size_t(n) + 4);
                            }
                        }
                        audioTs += fm::kFrameSamples;
                    }
                    std::memset(mix, 0, sizeof mix);
                    bool any = false;
                    for (auto& kv : peers) {
                        std::vector<std::uint8_t> packet;
                        if (!kv.second.ready || !kv.second.jitter.pop(packet)) continue;
                        const int n = kv.second.opus.decode(packet.empty() ? nullptr : packet.data(), int(packet.size()), tmp);
                        if (n <= 0) continue;
                        for (int i = 0; i < n; ++i) mix[i] = std::int16_t(std::clamp(int(mix[i]) + tmp[i], -32768, 32767));
                        any = true;
                    }
                    if (any) {
                        speaker.write(mix);
                        speakerLevel = std::max(speakerLevel * 0.8f, fm::rms(mix, fm::kFrameSamples));
                    } else {
                        speakerLevel *= 0.8f;
                    }
                }
                if (nextAudio < now - std::chrono::milliseconds(200)) nextAudio = now;  // retard : on ne rattrape pas
            }

            // ---- vidéo
            if (now >= nextVideo) {
                nextVideo = now + videoPeriod;
                if (cameraOn) {
                    const bool ok = cam ? cam->grab(bgrx.data()) : (testPattern(bgrx.data(), w, h, frames), true);
                    if (ok) {
                        publishFrame(localPub, bgrx.data(), w, h, frames);
                        if (encoder && transport.joined()) {
                            bool isKey = false;
                            pkt = encoder->encode(bgrx.data(), keyframeWanted, isKey);
                            if (!pkt.empty()) {
                                if (isKey) keyframeWanted = false;
                                constexpr std::size_t kChunk = 1100;
                                const auto count = std::uint16_t((pkt.size() + kChunk - 1) / kChunk);
                                std::uint8_t part[13 + kChunk];
                                ++frameId;
                                for (std::uint16_t i = 0; i < count; ++i) {
                                    const std::size_t off = std::size_t(i) * kChunk;
                                    const std::size_t n = std::min(kChunk, pkt.size() - off);
                                    fw::putBe(part, frameId, 4);
                                    fw::putBe(part + 4, i, 2);
                                    fw::putBe(part + 6, count, 2);
                                    part[8] = isKey ? 1 : 0;
                                    fw::putBe(part + 9, w, 2);
                                    fw::putBe(part + 11, h, 2);
                                    std::memcpy(part + 13, pkt.data() + off, n);
                                    transport.send(fw::Video, part, 13 + n);
                                }
                            }
                        }
                        ++frames;
                    }
                }
            }

            if (now - lastLevel > std::chrono::milliseconds(100)) {
                lastLevel = now;
                auto lvl = audioLevel.loan_uninit();
                if (lvl.has_value())
                    send(lvl.value().write_payload(fipc::AudioLevel{fipc::kAbiVersion, micLevel, speakerLevel, 0})).has_value();
                if (frames % 30 == 0) publishState(fipc::MediaState::Running, callSeq, frames);
            }
        }

        if (!node.wait(bb::Duration::from_millis(running ? 2 : 20)).has_value()) break;
    }
    stopCall();
    std::fprintf(stderr, "ngoma-media arrêté (envoyés : %llu, reçus : %llu, rejetés : %llu)\n",
                 static_cast<unsigned long long>(transport.sent()), static_cast<unsigned long long>(transport.received()),
                 static_cast<unsigned long long>(transport.dropped()));
    return 0;
}
