from rest_framework.response import Response
from rest_framework.views import APIView

from . import engine
from .models import BotProfile


def _status(owner) -> dict:
    p = BotProfile.objects.filter(owner=owner).first()
    if p is None:
        return {"active": False}
    return {
        "active": p.active, "provider": p.provider, "model": p.model_name, "base_url": p.base_url,
        "system_prompt": p.system_prompt, "api_key_set": bool(p.api_key_enc),
        "conversation_id": str(p.messaging_id) if p.messaging_id else None,
        "bot_user_id": p.bot_user_id, "last_error": p.last_error,
    }


class MyBotView(APIView):
    """GET : état · POST : activer / reconfigurer (la clé API n'est jamais renvoyée) · DELETE : désactiver."""

    def get(self, request):
        return Response(_status(request.user))

    def post(self, request):
        if BotProfile.objects.filter(bot_user=request.user).exists():
            return Response({"detail": "Un assistant ne peut pas avoir d'assistant"}, status=403)
        d = request.data
        try:
            engine.activate(request.user, provider=str(d.get("provider", "")), model=str(d.get("model", "")),
                            api_key=str(d.get("api_key") or "") or None, base_url=str(d.get("base_url") or ""),
                            system_prompt=str(d.get("system_prompt") or ""))
        except engine.BotError as exc:
            return Response({"detail": str(exc)}, status=400)
        return Response(_status(request.user), status=201)

    def delete(self, request):
        engine.deactivate(request.user)
        return Response(_status(request.user))
