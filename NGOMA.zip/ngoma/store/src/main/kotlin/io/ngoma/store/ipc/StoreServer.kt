package io.ngoma.store.ipc

import io.ngoma.store.Store
import io.ngoma.store.inData
import io.ngoma.store.long
import io.ngoma.store.str
import kotlinx.serialization.json.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.StandardProtocolFamily
import java.net.UnixDomainSocketAddress
import java.nio.channels.Channels
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.attribute.PosixFilePermissions
import java.util.concurrent.CopyOnWriteArrayList
import java.util.logging.Logger

/**
 * Protocole IPC local (socket Unix, une ligne JSON par trame, UTF-8) :
 *   requête  : {"id": 7, "op": "msg.list", "args": {...}}
 *   réponse  : {"id": 7, "ok": true, "result": ...}  |  {"id": 7, "ok": false, "error": "..."}
 *   événement: {"event": "changed", "scope": "conv"|"msg", "messaging_id": "..."}   (sans id)
 *
 * Choix : JSON-lignes plutôt que gRPC pour supprimer la génération de code côté JVM et C++ et alléger l'empreinte
 * embarquée. Le socket est en 0600 ; seul l'utilisateur système `ngoma` peut s'y connecter.
 * Les messages volumineux (médias) ne transitent PAS ici : seulement leurs métadonnées.
 */
class StoreServer(private val socketPath: Path, private val maxLine: Int = 1 shl 20) {
    private val log = Logger.getLogger("ngoma.store")
    private val clients = CopyOnWriteArrayList<Client>()

    private inner class Client(val ch: SocketChannel) {
        private val out = Channels.newOutputStream(ch)
        @Synchronized
        fun send(o: JsonObject) {
            out.write((o.toString() + "\n").toByteArray(StandardCharsets.UTF_8))
            out.flush()
        }
    }

    fun serve() {
        // Activation par socket systemd (ngoma-store.socket) : le socket est hérité, déjà en 0600.
        val inherited = System.inheritedChannel() as? ServerSocketChannel
        val server = inherited ?: run {
            Files.createDirectories(socketPath.parent)
            Files.deleteIfExists(socketPath)
            ServerSocketChannel.open(StandardProtocolFamily.UNIX).also {
                it.bind(UnixDomainSocketAddress.of(socketPath))
                Files.setPosixFilePermissions(socketPath, PosixFilePermissions.fromString("rw-------"))
            }
        }
        log.info("ngoma-store à l'écoute sur ${if (inherited != null) "socket systemd hérité" else socketPath}")
        while (true) {
            val ch = server.accept()
            Thread.ofVirtual().name("store-client").start { handle(Client(ch)) }
        }
    }

    private fun handle(c: Client) {
        clients += c
        try {
            BufferedReader(InputStreamReader(Channels.newInputStream(c.ch), StandardCharsets.UTF_8)).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.length > maxLine) { c.send(err(null, "trame trop longue")); break }
                    if (line.isBlank()) continue
                    val req = runCatching { Json.parseToJsonElement(line).jsonObject }.getOrNull()
                    if (req == null) { c.send(err(null, "JSON invalide")); continue }
                    val id = req["id"]
                    val response = try {
                        val (result, change) = dispatch(req.str("op") ?: "", req["args"]?.jsonObject ?: JsonObject(emptyMap()))
                        change?.let { broadcast(it) }
                        buildJsonObject { id?.let { put("id", it) }; put("ok", true); put("result", result) }
                    } catch (e: Exception) {
                        log.warning("op ${req.str("op")} : ${e.message}")
                        err(id, e.message ?: e.javaClass.simpleName)
                    }
                    c.send(response)
                }
            }
        } catch (_: Exception) {
        } finally {
            clients -= c
            runCatching { c.ch.close() }
        }
    }

    private fun broadcast(evt: JsonObject) {
        for (c in clients) runCatching { c.send(evt) }
    }

    private fun err(id: JsonElement?, msg: String) = buildJsonObject {
        id?.let { put("id", it) }
        put("ok", false)
        put("error", msg)
    }

    private fun changed(scope: String, messagingId: String? = null) = buildJsonObject {
        put("event", "changed"); put("scope", scope); messagingId?.let { put("messaging_id", it) }
    }

    /** Retourne (résultat, événement à diffuser éventuel). */
    private fun dispatch(op: String, a: JsonObject): Pair<JsonElement, JsonObject?> = when (op) {
        "ping" -> JsonPrimitive("pong") to null
        "setting.get" -> inData { Store.getSetting(a.req("key")) }.let { JsonPrimitive(it) } to null
        "setting.set" -> inData { Store.setSetting(a.req("key"), a.str("value") ?: "") }.let { JsonPrimitive(true) } to null
        "conv.upsert" -> inData { Store.upsertConversations(a["items"]!!.jsonArray) }.let { JsonPrimitive(it) } to changed("conv")
        "conv.list" -> inData { Store.listConversations() } to null
        "conv.setServerSeq" -> inData { Store.setServerSeq(a.req("id"), a.long("seq") ?: 0) }.let { JsonPrimitive(it) } to changed("conv", a.str("id"))
        "conv.setPulled" -> inData { Store.setPulled(a.req("id"), a.long("seq") ?: 0, a.str("updated_at")) }.let { JsonPrimitive(true) } to changed("conv", a.str("id"))
        "conv.setRead" -> inData { Store.setRead(a.req("id"), a.long("seq") ?: 0) }.let { JsonPrimitive(true) } to changed("conv", a.str("id"))
        "conv.setPeerRead" -> inData { Store.setPeerRead(a.req("id"), a.long("seq") ?: 0) }.let { JsonPrimitive(true) } to changed("msg", a.str("id"))
        "conv.setDraft" -> inData { Store.setDraft(a.req("id"), a.str("text") ?: "") }.let { JsonPrimitive(true) } to null
        "msg.insertOutgoing" -> inData { Store.insertOutgoing(a) } to changed("msg", a.str("messaging_id"))
        "msg.markSent" -> inData { Store.markSent(a) }.let { JsonPrimitive(it) } to changed("msg", a.str("messaging_id"))
        "msg.setMeta" -> inData { Store.setMeta(a.req("client_id"), a.str("meta") ?: "") }
            .let { JsonPrimitive(it) } to changed("msg", a.str("messaging_id"))
        "msg.markFailed" -> inData { Store.markFailed(a.req("client_id"), a["permanent"]?.jsonPrimitive?.booleanOrNull ?: false) }
            .let { JsonPrimitive(it) } to changed("msg", a.str("messaging_id"))
        "msg.upsertReceived" -> inData {
            Store.upsertReceived(a.req("messaging_id"), a["items"]!!.jsonArray, a.long("my_user_id") ?: 0)
        }.let { JsonPrimitive(it) } to changed("msg", a.str("messaging_id"))
        "msg.list" -> inData { Store.listMessages(a.req("messaging_id"), a.long("before_seq") ?: 0, (a.long("limit") ?: 50).toInt().coerceIn(1, 500)) } to null
        "msg.pending" -> inData { Store.pendingOutbox((a.long("limit") ?: 100).toInt()) } to null
        "msg.search" -> inData { Store.search(a.req("q"), (a.long("limit") ?: 50).toInt().coerceIn(1, 200)) } to null
        "msg.purgeExpired" -> inData { Store.purgeExpired(a.req("now")) }.let { JsonPrimitive(it) } to changed("msg")
        "wipe" -> inData { Store.wipe() }.let { JsonPrimitive(true) } to changed("conv")
        else -> throw IllegalArgumentException("opération inconnue : $op")
    }

    private fun JsonObject.req(k: String): String = str(k) ?: throw IllegalArgumentException("argument manquant : $k")
}
