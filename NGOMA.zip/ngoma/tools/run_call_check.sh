#!/usr/bin/env bash
# Appel complet sur une machine : ngoma-relay + deux ngoma-media (préfixes IPC a/ et b/) + test.
set -euo pipefail
BUILD="${1:?dossier de build du client}"
export NGOMA_RELAY_SECRET="${NGOMA_RELAY_SECRET:-$(python3 -c "import secrets;print(secrets.token_urlsafe(32))")}" RELAY_PORT="${RELAY_PORT:-3499}"
NGOMA_RELAY_BIND=127.0.0.1 NGOMA_RELAY_PORT=$RELAY_PORT "$BUILD/ngoma-relay" &
for p in a b; do
    NGOMA_IPC_PREFIX="$p/" NGOMA_AUDIO_TEST=sine NGOMA_CAMERA=/dev/null-no-camera \
        NGOMA_H264_ENCODER="${NGOMA_H264_ENCODER:-libx264}" "$BUILD/ngoma-media" &
done
trap 'kill $(jobs -p) 2>/dev/null || true' EXIT
sleep 0.7
"$BUILD/integration_call"
