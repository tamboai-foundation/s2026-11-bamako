from django.core.management.base import BaseCommand

from messaging.services import purge_expired, purge_media


class Command(BaseCommand):
    help = "Supprime définitivement les messages éphémères expirés (lancer via un timer systemd)."

    def handle(self, *args, **options):
        n = purge_expired()
        m = purge_media()
        self.stdout.write(f"{n} message(s) et {m} pièce(s) jointe(s) supprimé(s)")
