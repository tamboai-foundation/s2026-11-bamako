// Test d'intégration iceoryx2 : nécessite ngoma-media lancé (tools/run_ipc_check.sh).
// Vérifie le chemin complet : commande d'appel → capture/mire → trame en mémoire partagée → QImage côté UI.
#include <QSignalSpy>
#include <QtTest>
#include <cstring>

#include "ipc/IpcBus.h"

using namespace ngoma;

class IntegrationIpc : public QObject {
    Q_OBJECT
private slots:
    void framesFlowThroughSharedMemory() {
        IpcBus bus;
        QVERIFY(bus.available());
        QSignalSpy frames(&bus, &IpcBus::localFrame);
        QSignalSpy states(&bus, &IpcBus::mediaState);
        bus.setVideoReceiving(true);

        ipc::CallControl start;
        start.command = ipc::CallCommand::Start;
        start.call_seq = 42;
        std::strcpy(start.call_id, "test-call");
        start.width = 320;
        start.height = 240;
        start.fps = 30;
        bus.sendCallControl(start);

        QTRY_VERIFY_WITH_TIMEOUT(frames.count() >= 10, 5000);
        const auto img = frames.last().at(0).value<QImage>();
        QCOMPARE(img.width(), 320);
        QCOMPARE(img.height(), 240);
        QTRY_VERIFY_WITH_TIMEOUT(!states.isEmpty() && states.last().at(1).toULongLong() == 42, 3000);

        ipc::CallControl stop;
        stop.command = ipc::CallCommand::Stop;
        stop.call_seq = 42;
        bus.sendCallControl(stop);
        QTest::qWait(300);
        const int after = int(frames.count());
        QTest::qWait(500);
        QVERIFY(frames.count() - after <= 2);  // le flux s'arrête
    }
};

QTEST_GUILESS_MAIN(IntegrationIpc)
#include "integration_ipc.moc"
