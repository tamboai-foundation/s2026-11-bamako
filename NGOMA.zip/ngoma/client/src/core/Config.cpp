#include "Config.h"

#include <QSettings>
#include <QtGlobal>

namespace ngoma {

Config Config::load() {
    Config c;
    const QString path = qEnvironmentVariable("NGOMA_CONFIG", QStringLiteral("/etc/ngoma/client.conf"));
    QSettings s(path, QSettings::IniFormat);
    s.beginGroup(QStringLiteral("ngoma"));
    auto pick = [&](const char* env, const QString& key, const QString& def) {
        const QString e = qEnvironmentVariable(env);
        return e.isEmpty() ? s.value(key, def).toString() : e;
    };
    c.serverUrl = QUrl(pick("NGOMA_SERVER_URL", QStringLiteral("server_url"), c.serverUrl.toString()));
    c.dataDir = pick("NGOMA_DATA_DIR", QStringLiteral("data_dir"), c.dataDir);
    c.storeSocket = pick("NGOMA_STORE_SOCK", QStringLiteral("store_socket"), c.storeSocket);
    c.caFile = pick("NGOMA_CA_FILE", QStringLiteral("ca_file"), c.caFile);
    c.clientCertFile = pick("NGOMA_CLIENT_CERT", QStringLiteral("client_cert"), c.clientCertFile);
    c.clientKeyFile = pick("NGOMA_CLIENT_KEY", QStringLiteral("client_key"), c.clientKeyFile);
    c.deviceName = pick("NGOMA_DEVICE_NAME", QStringLiteral("device_name"), c.deviceName);
    c.allowInsecure = pick("NGOMA_ALLOW_INSECURE", QStringLiteral("allow_insecure"), QStringLiteral("false")) ==
                      QLatin1String("true");
    s.endGroup();
    return c;
}

QUrl Config::apiUrl(const QString& path) const {
    QUrl u = serverUrl;
    QString base = u.path();
    if (base.endsWith(QLatin1Char('/'))) base.chop(1);
    // « chemin?requête » : la requête est déjà encodée par l'appelant (QUrlQuery) et ne doit pas
    // être intégrée au chemin (sinon « ? » devient « %3F »).
    const qsizetype q = path.indexOf(QLatin1Char('?'));
    u.setPath(base + QStringLiteral("/api/v1/") + (q < 0 ? path : path.left(q)));
    if (q >= 0) u.setQuery(path.mid(q + 1), QUrl::StrictMode);
    return u;
}

QUrl Config::realtimeUrl() const {
    QUrl u = serverUrl;
    u.setScheme(u.scheme() == QLatin1String("http") ? QStringLiteral("ws") : QStringLiteral("wss"));
    QString base = u.path();
    if (base.endsWith(QLatin1Char('/'))) base.chop(1);
    u.setPath(base + QStringLiteral("/ws/v1/realtime"));
    return u;
}

}  // namespace ngoma
