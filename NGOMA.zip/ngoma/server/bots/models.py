from django.conf import settings
from django.db import models
from django.utils import timezone


class BotProfile(models.Model):
    """Assistant IA personnel d'un utilisateur : un compte « bot » avec son propre appareil et ses propres clés.

    Le bot est un participant chiffré de bout en bout comme un autre : il ne lit que les messages qui lui sont
    chiffrés, dans sa conversation directe avec son propriétaire. Les secrets sont chiffrés au repos (Fernet)."""

    ANTHROPIC, OPENAI = "anthropic", "openai"
    PROVIDERS = [(ANTHROPIC, "Anthropic (Claude)"), (OPENAI, "Compatible OpenAI")]

    owner = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="assistant")
    bot_user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="bot_profile")
    bot_device = models.ForeignKey("accounts.Device", on_delete=models.SET_NULL, null=True, related_name="+")
    messaging = models.ForeignKey("messaging.Messaging", on_delete=models.SET_NULL, null=True, related_name="+")
    provider = models.CharField(max_length=16, choices=PROVIDERS)
    model_name = models.CharField(max_length=120)
    base_url = models.CharField(max_length=300, blank=True)
    system_prompt = models.TextField(blank=True)
    api_key_enc = models.TextField(blank=True)
    keys_enc = models.TextField(blank=True)
    active = models.BooleanField(default=False, db_index=True)
    last_seq = models.BigIntegerField(default=0)
    lease_until = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(default=timezone.now)


class BotSession(models.Model):
    bot = models.ForeignKey(BotProfile, on_delete=models.CASCADE, related_name="sessions")
    peer_device = models.ForeignKey("accounts.Device", on_delete=models.CASCADE, related_name="+")
    state_enc = models.TextField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=["bot", "peer_device"], name="uniq_bot_session")]


class BotTurn(models.Model):
    """Historique court de la conversation, chiffré au repos, purgé à la désactivation."""

    bot = models.ForeignKey(BotProfile, on_delete=models.CASCADE, related_name="turns")
    role = models.CharField(max_length=10)
    content_enc = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        indexes = [models.Index(fields=["bot", "id"])]
