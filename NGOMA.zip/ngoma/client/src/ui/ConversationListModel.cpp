#include "ConversationListModel.h"

#include <QDateTime>

namespace ngoma {

ConversationListModel::ConversationListModel(QObject* parent) : QAbstractListModel(parent) {}

int ConversationListModel::rowCount(const QModelIndex& parent) const { return parent.isValid() ? 0 : int(m_items.size()); }

QHash<int, QByteArray> ConversationListModel::roleNames() const {
    return {{IdRole, "conversationId"}, {TitleRole, "title"},   {KindRole, "kind"},   {UnreadRole, "unread"},
            {LastBodyRole, "lastBody"}, {LastAtRole, "lastAt"}, {DraftRole, "draft"}, {MemberCountRole, "memberCount"}, {IsAssistantRole, "isAssistant"}};
}

QString ConversationListModel::titleFor(const QJsonObject& c) const {
    const QString t = c.value(QStringLiteral("title")).toString();
    if (!t.isEmpty()) return t;
    QStringList names;
    for (const auto& m : c.value(QStringLiteral("members")).toArray()) {
        const auto o = m.toObject();
        if (o.value(QStringLiteral("id")).toInteger() == m_me) continue;
        const QString dn = o.value(QStringLiteral("display_name")).toString();
        names << (dn.isEmpty() ? o.value(QStringLiteral("username")).toString() : dn);
    }
    return names.isEmpty() ? tr("Conversation") : names.join(QStringLiteral(", "));
}

QVariant ConversationListModel::data(const QModelIndex& index, int role) const {
    if (!index.isValid() || index.row() >= m_items.size()) return {};
    const auto& c = m_items.at(index.row());
    switch (role) {
    case IdRole: return c.value(QStringLiteral("id")).toString();
    case TitleRole: return titleFor(c);
    case KindRole: return c.value(QStringLiteral("kind")).toString();
    case UnreadRole: return int(c.value(QStringLiteral("unread")).toInteger());
    case LastBodyRole: return c.value(QStringLiteral("last_body")).toString();
    case LastAtRole: {
        const auto dt = QDateTime::fromString(c.value(QStringLiteral("last_at")).toString(), Qt::ISODateWithMs).toLocalTime();
        if (!dt.isValid()) return QString();
        return dt.date() == QDate::currentDate() ? dt.toString(QStringLiteral("HH:mm")) : dt.toString(QStringLiteral("dd/MM"));
    }
    case DraftRole: return c.value(QStringLiteral("draft")).toString();
    case MemberCountRole: return int(c.value(QStringLiteral("members")).toArray().size());
    case IsAssistantRole:
        // Les comptes d'assistant IA sont nommés « assistant-<propriétaire>-<suffixe> » par le serveur.
        for (const auto& m : c.value(QStringLiteral("members")).toArray())
            if (m.toObject().value(QStringLiteral("username")).toString().startsWith(QLatin1String("assistant-"))) return true;
        return false;
    }
    return {};
}

void ConversationListModel::replace(const QJsonArray& items) {
    QList<QJsonObject> next;
    next.reserve(items.size());
    int unread = 0;
    for (const auto& v : items) {
        next.append(v.toObject());
        unread += int(v.toObject().value(QStringLiteral("unread")).toInteger());
    }
    // Même ensemble, même ordre : mise à jour des lignes sans réinitialiser la vue (pas de saut de défilement).
    bool sameShape = next.size() == m_items.size();
    for (int i = 0; sameShape && i < next.size(); ++i)
        sameShape = next[i].value(QStringLiteral("id")) == m_items[i].value(QStringLiteral("id"));
    if (sameShape) {
        m_items = std::move(next);
        if (!m_items.isEmpty()) emit dataChanged(index(0), index(int(m_items.size()) - 1));
    } else {
        beginResetModel();
        m_items = std::move(next);
        endResetModel();
        emit countChanged();
    }
    if (unread != m_unread) {
        m_unread = unread;
        emit unreadTotalChanged();
    }
}

QJsonObject ConversationListModel::byId(const QString& id) const {
    for (const auto& c : m_items)
        if (c.value(QStringLiteral("id")).toString() == id) return c;
    return {};
}

QVariantMap ConversationListModel::infoOf(const QString& id) const {
    for (int i = 0; i < m_items.size(); ++i)
        if (m_items[i].value(QStringLiteral("id")).toString() == id)
            return {{QStringLiteral("kind"), data(index(i), KindRole)},
                    {QStringLiteral("isAssistant"), data(index(i), IsAssistantRole)},
                    {QStringLiteral("memberCount"), data(index(i), MemberCountRole)}};
    return {};
}

QString ConversationListModel::titleOf(const QString& id) const {
    const auto c = byId(id);
    return c.isEmpty() ? QString() : titleFor(c);
}

}  // namespace ngoma
