"""Publication et distribution des prékeys X3DH (NGOMA Ratchet v2)."""
from __future__ import annotations

import base64
import binascii

from django.db import transaction
from django.utils import timezone
from nacl.exceptions import BadSignatureError
from nacl.signing import VerifyKey

from .models import Device, OneTimePreKey, SignedPreKey

SPK_SIG_PREFIX = b"NGM-SPK1"
MAX_OPKS_PER_DEVICE = 200


class PreKeyError(Exception):
    pass


def _b64(value: str, size: int) -> bytes:
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError, TypeError) as exc:
        raise PreKeyError("base64 invalide") from exc
    if len(raw) != size:
        raise PreKeyError("taille de clé invalide")
    return raw


@transaction.atomic
def publish(device: Device, spk_id: int, spk: str, spk_sig: str, opks: list[dict]) -> int:
    ik = _b64(device.public_key, 32)
    spk_raw = _b64(spk, 32)
    try:
        VerifyKey(ik).verify(SPK_SIG_PREFIX + spk_raw, _b64(spk_sig, 64))
    except BadSignatureError as exc:
        raise PreKeyError("signature de prékey invalide") from exc
    SignedPreKey.objects.update_or_create(
        device=device, defaults={"key_id": int(spk_id), "public_key": spk, "signature": spk_sig, "updated_at": timezone.now()}
    )
    existing = OneTimePreKey.objects.filter(device=device).count()
    room = max(0, MAX_OPKS_PER_DEVICE - existing)
    rows = []
    for o in opks[:room]:
        _b64(o["key"], 32)
        rows.append(OneTimePreKey(device=device, key_id=int(o["id"]), public_key=o["key"]))
    OneTimePreKey.objects.bulk_create(rows, ignore_conflicts=True)
    return OneTimePreKey.objects.filter(device=device).count()


def count(device: Device) -> dict:
    spk = SignedPreKey.objects.filter(device=device).first()
    return {"opk_count": OneTimePreKey.objects.filter(device=device).count(), "spk_id": spk.key_id if spk else None}


def claim(device_ids: list[str], allowed_user_ids: set[int] | None = None) -> dict[str, dict]:
    """Réserve une prékey à usage unique par appareil demandé et renvoie les paquets X3DH."""
    out: dict[str, dict] = {}
    devices = Device.objects.filter(pk__in=device_ids, revoked_at__isnull=True).select_related("signed_prekey")
    for d in devices:
        if allowed_user_ids is not None and d.user_id not in allowed_user_ids:
            continue
        spk = getattr(d, "signed_prekey", None)
        if spk is None:
            continue
        with transaction.atomic():
            opk = (
                OneTimePreKey.objects.select_for_update(skip_locked=True).filter(device=d).order_by("key_id").first()
            )
            bundle = {"identity_key": d.public_key, "spk_id": spk.key_id, "spk": spk.public_key,
                      "spk_sig": spk.signature, "opk_id": None, "opk": None}
            if opk is not None:
                bundle["opk_id"], bundle["opk"] = opk.key_id, opk.public_key
                opk.delete()
        out[str(d.pk)] = bundle
    return out
