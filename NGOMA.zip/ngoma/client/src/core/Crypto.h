#pragma once

#include <QByteArray>
#include <QString>
#include <optional>

namespace ngoma {

struct Sealed {
    QString nonceB64;
    QString ciphertextB64;
};

/// Chiffrement de bout en bout par appareil (libsodium, crypto_box : X25519 + XSalsa20-Poly1305).
///
/// Chaque message est chiffré une fois par appareil destinataire et authentifié par la clé de l'appareil émetteur.
/// Limites assumées de la V1 : pas de confidentialité persistante (forward secrecy) ; l'étape suivante est
/// libsignal (1:1) et MLS (groupes), derrière cette même interface.
class Crypto {
public:
    static bool init();

    /// Génère une paire de clés. Renvoie false si libsodium n'est pas initialisé.
    static bool generateKeyPair(QByteArray& publicKey, QByteArray& secretKey);

    static std::optional<Sealed> seal(const QByteArray& plaintext, const QByteArray& recipientPublicKey,
                                      const QByteArray& senderSecretKey);
    static std::optional<QByteArray> open(const QString& nonceB64, const QString& ciphertextB64,
                                          const QByteArray& senderPublicKey, const QByteArray& recipientSecretKey);

    /// Empreinte lisible (vérification hors bande des clés, « numéro de sécurité »).
    static QString fingerprint(const QByteArray& publicKey);

    static void wipe(QByteArray& secret);

    /// Chiffrement d'une pièce jointe : clé et nonce aléatoires (XChaCha20-Poly1305). Renvoie le chiffré ;
    /// `key` et `nonce` (base64) voyagent dans l'enveloppe Ratchet du message, jamais en clair sur le serveur.
    static QByteArray sealBlob(const QByteArray& plaintext, QByteArray& key, QByteArray& nonce);
    static std::optional<QByteArray> openBlob(const QByteArray& ciphertext, const QByteArray& key, const QByteArray& nonce);
    static QByteArray sha256(const QByteArray& data);
    static QByteArray random(int n);
};

}  // namespace ngoma
