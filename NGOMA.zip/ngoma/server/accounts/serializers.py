import base64
import binascii

from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from .models import Device

User = get_user_model()


def validate_x25519_key(value: str) -> str:
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise serializers.ValidationError("Clé publique non base64") from exc
    if len(raw) != 32:
        raise serializers.ValidationError("Clé publique X25519 attendue (32 octets)")
    return value


class DeviceEnrollSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(write_only=True)
    device_name = serializers.CharField(max_length=120)
    public_key = serializers.CharField(validators=[validate_x25519_key])


class SignupSerializer(DeviceEnrollSerializer):
    display_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    provisioning_code = serializers.CharField(required=False, allow_blank=True)

    def validate_username(self, value):
        if User.objects.filter(username__iexact=value).exists():
            raise serializers.ValidationError("Identifiant déjà utilisé")
        return value

    def validate_password(self, value):
        validate_password(value)
        return value


class PublicDeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = ["id", "public_key", "name"]


class UserSerializer(serializers.ModelSerializer):
    display_name = serializers.CharField(source="first_name")

    class Meta:
        model = User
        fields = ["id", "username", "display_name"]


class OwnDeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = ["id", "name", "created_at", "last_seen_at", "revoked_at"]
