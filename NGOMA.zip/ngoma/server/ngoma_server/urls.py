import os

from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path


def health(_request):
    return JsonResponse({"status": "ok"})


urlpatterns = [
    path("healthz", health),
    path("api/v1/", include("accounts.urls")),
    path("api/v1/", include("messaging.urls")),
    path("api/v1/", include("bots.urls")),
]

# Le back-office n'est exposé que si explicitement activé (réseau d'administration interne).
if os.environ.get("NGOMA_ENABLE_ADMIN", "0") == "1":
    urlpatterns.append(path("internal-admin/", admin.site.urls))
