"""Chiffrement au repos des secrets des bots (clé API, clés privées, sessions, historique)."""
import json
import sys

from cryptography.fernet import Fernet, InvalidToken
from django.conf import settings


_TEST_KEY: bytes | None = None


class VaultUnavailable(Exception):
    pass


def _fernet() -> Fernet:
    key = settings.NGOMA["BOT_KEY"]
    if key:
        return Fernet(key.encode())
    if "pytest" in sys.modules:  # tests : clé aléatoire propre au processus, jamais persistée
        global _TEST_KEY
        if _TEST_KEY is None:
            _TEST_KEY = Fernet.generate_key()
        return Fernet(_TEST_KEY)
    raise VaultUnavailable("NGOMA_BOT_KEY n'est pas configurée sur le serveur")


def seal(text: str) -> str:
    return _fernet().encrypt(text.encode()).decode()


def open_(token: str) -> str:
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken as exc:
        raise VaultUnavailable("secret illisible (clé de coffre modifiée ?)") from exc


def seal_json(obj) -> str:
    return seal(json.dumps(obj, separators=(",", ":")))


def open_json(token: str):
    return json.loads(open_(token))


def configured() -> bool:
    try:
        _fernet()
        return True
    except VaultUnavailable:
        return False
