#include "SecretStore.h"

#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QRegularExpression>
#include <QSaveFile>
#include <sodium.h>

namespace ngoma {

namespace {
bool writeSecret(const QString& path, const QJsonObject& o) {
    QSaveFile f(path);
    if (!f.open(QIODevice::WriteOnly)) return false;
    f.setPermissions(QFileDevice::ReadOwner | QFileDevice::WriteOwner);
    QByteArray data = QJsonDocument(o).toJson(QJsonDocument::Compact);
    f.write(data);
    sodium_memzero(data.data(), size_t(data.size()));
    return f.commit();
}

void shred(const QString& path) {
    QFile f(path);
    if (f.open(QIODevice::ReadWrite)) {
        f.write(QByteArray(int(f.size()), '\0'));
        f.close();
    }
    f.remove();
}
}  // namespace

SecretStore::SecretStore(QString dataDir) : m_dir(std::move(dataDir)) {}

QString SecretStore::path() const { return QDir(m_dir).filePath(QStringLiteral("identity.json")); }

QString SecretStore::sessionPath(const QString& peerDeviceId) const {
    static const QRegularExpression uuid(QStringLiteral("^[0-9a-fA-F-]{36}$"));
    if (!uuid.match(peerDeviceId).hasMatch()) return {};  // jamais de chemin construit depuis une donnée non validée
    return QDir(m_dir).filePath(QStringLiteral("sessions/") + peerDeviceId + QStringLiteral(".json"));
}

bool SecretStore::load(Identity& out) const {
    QFile f(path());
    if (!f.open(QIODevice::ReadOnly)) return false;
    const auto o = QJsonDocument::fromJson(f.readAll()).object();
    out.userId = o.value(QStringLiteral("user_id")).toInteger();
    out.username = o.value(QStringLiteral("username")).toString();
    out.displayName = o.value(QStringLiteral("display_name")).toString();
    out.deviceId = o.value(QStringLiteral("device_id")).toString();
    out.token = o.value(QStringLiteral("token")).toString();
    out.keys = ratchet::DeviceKeys(o.value(QStringLiteral("keys")).toObject());
    return out.valid();
}

bool SecretStore::save(const Identity& id) const {
    QDir().mkpath(m_dir);
    return writeSecret(path(), {{QStringLiteral("v"), 2},
                                {QStringLiteral("user_id"), id.userId},
                                {QStringLiteral("username"), id.username},
                                {QStringLiteral("display_name"), id.displayName},
                                {QStringLiteral("device_id"), id.deviceId},
                                {QStringLiteral("token"), id.token},
                                {QStringLiteral("keys"), id.keys.json()}});
}

bool SecretStore::clear() const {
    shred(path());
    QDir sessions(QDir(m_dir).filePath(QStringLiteral("sessions")));
    for (const auto& name : sessions.entryList(QDir::Files)) shred(sessions.filePath(name));
    return !QFile::exists(path());
}

std::optional<QJsonObject> SecretStore::loadSession(const QString& peerDeviceId) const {
    const QString p = sessionPath(peerDeviceId);
    if (p.isEmpty()) return std::nullopt;
    QFile f(p);
    if (!f.open(QIODevice::ReadOnly)) return std::nullopt;
    const auto doc = QJsonDocument::fromJson(f.readAll());
    if (!doc.isObject()) return std::nullopt;
    return doc.object();
}

bool SecretStore::saveSession(const QString& peerDeviceId, const QJsonObject& state) const {
    const QString p = sessionPath(peerDeviceId);
    if (p.isEmpty()) return false;
    QDir().mkpath(QDir(m_dir).filePath(QStringLiteral("sessions")));
    QFile::setPermissions(QDir(m_dir).filePath(QStringLiteral("sessions")),
                          QFileDevice::ReadOwner | QFileDevice::WriteOwner | QFileDevice::ExeOwner);
    return writeSecret(p, state);
}

}  // namespace ngoma
