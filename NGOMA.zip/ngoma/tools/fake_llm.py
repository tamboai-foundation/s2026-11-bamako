#!/usr/bin/env python3
"""Faux fournisseur LLM « compatible OpenAI » pour les tests d'intégration (aucun appel externe).
Répond « Réponse IA : <dernier message utilisateur> ». Usage : fake_llm.py <port>"""
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer


EXPECTED_KEY = os.environ["NGOMA_FAKE_LLM_KEY"]  # générée par le script appelant, jamais versionnée


class H(BaseHTTPRequestHandler):
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        ok = self.path == "/v1/chat/completions" and self.headers.get("Authorization") == f"Bearer {EXPECTED_KEY}"
        last = [m["content"] for m in body.get("messages", []) if m["role"] == "user"][-1:] or [""]
        data = {"choices": [{"message": {"content": f"Réponse IA : {last[0]}"}}]} if ok else {"error": "refusé"}
        raw = json.dumps(data).encode()
        self.send_response(200 if ok else 401)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def log_message(self, *a):
        pass


HTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
