# Exploitation, sécurité, licences, feuille de route (v1.2)

## Services côté serveur

| Service | Rôle | Échelle |
|---|---|---|
| `api` (Uvicorn, Django) | REST, WebSocket, prékeys, médias, jetons d'appel | sans état, ×N |
| `bots` (`manage.py run_bots`) | assistants IA | ×N possible : un bail de 120 s par bot évite les doublons |
| `ngoma-relay` (C++, UDP 3479) | relais des appels, sans aucune clé média | une instance par zone ; découpage par `call_id` possible |
| PostgreSQL, Redis | données, couche de canaux, présence | Redis est **obligatoire** dès qu'il y a plus d'un processus (y compris le worker des bots) |
| Caddy | TLS 1.3, uniquement `/api/v1`, `/ws/v1` et `/healthz` ; corps limité à 27 Mo | — |

Tâches planifiées :
- `manage.py purge_expired` (toutes les minutes) : messages éphémères, et pièces jointes au-delà de `NGOMA_MEDIA_RETENTION_DAYS`.

Secrets à générer :
- `NGOMA_SECRET_KEY` ;
- `NGOMA_RELAY_SECRET`, partagé entre l'API et le relais, d'au moins 16 caractères ;
- `NGOMA_BOT_KEY`, une clé Fernet ;
- le mot de passe PostgreSQL.

## Montée en charge

- Les processus `api` se multiplient horizontalement. On place PgBouncer devant PostgreSQL, avec des réplicas de lecture pour `sync/pull`.
- Au-delà de quelques centaines de millions de messages, partitionner `messaging_message` et `messaging_envelope` par hachage de `messaging_id`.
- La table `accounts_onetimeprekey` se réserve avec `SELECT … FOR UPDATE SKIP LOCKED` : pas de contention entre réservations concurrentes.
- Pièces jointes : `FileSystemStorage` par défaut, à monter sur un volume partagé ; avec plusieurs nœuds, passer à un stockage objet (django-storages / S3).
- OCUDU (station 5G CU/DU) ne gère pas les utilisateurs. Il ne sert que pour un réseau 5G privé desservant les terminaux.

## Sécurité

**Terminal :**
- démarrage vérifié, dm-verity, partition `/var/lib/ngoma` chiffrée par LUKS avec une clé scellée dans le TPM ;
- `identity.json` et `sessions/` en droits 0600, écritures atomiques, effacement par écrasement à la déconnexion.

**Chiffrement de bout en bout :** NGOMA Ratchet v2 (X3DH et Double Ratchet), voir `CRYPTO.md`. **Un audit externe est requis avant un déploiement sensible.**

**Assistant IA :**
- le bot est un appareil côté serveur ; ses messages sont déchiffrés sur le serveur puis envoyés au fournisseur choisi, ce que l'interface affiche avant l'activation ;
- clés API, clés du bot, sessions et historique (20 tours) sont chiffrés au repos (Fernet) et effacés à la désactivation ;
- protection SSRF : HTTPS obligatoire et hôtes publics uniquement. `NGOMA_BOT_ALLOW_PRIVATE_BASE_URL=1` n'est à activer que pour un LLM interne de confiance, ou pour les tests ;
- un bot ne répond qu'à son propriétaire, ne peut pas avoir lui-même de bot, et n'apparaît pas dans la recherche.

**Relais :**
- admission sur jeton HMAC à durée limitée (4 h) ;
- anti-usurpation : couple device et adresse ;
- débit limité à 1 500 paquets/s par membre ;
- expiration après 30 s de silence.

## Choix techniques assumés (écarts par rapport à la feuille de route initiale)

1. **Les appels n'utilisent pas WebRTC.** libdatachannel n'a pas pu être récupérée dans l'environnement de développement. Le transport retenu est un relais UDP avec chiffrement de bout en bout propre (ChaCha20-Poly1305, clé d'appel par Ratchet), avec Opus et H.264 via FFmpeg.
   - Avantage : simple, entièrement testé, et adapté à une flotte de terminaux derrière des NAT, puisque tout passe par le relais, comme avec un TURN permanent.
   - Limites :
     - pas d'ICE ni de connexion directe entre terminaux ;
     - pas de contrôle de congestion adaptatif : débits fixes de 600 kbit/s en vidéo et 24 kbit/s en audio, avec FEC Opus ;
     - pas d'annulation d'écho logicielle : il faut celle du matériel ou d'un DSP ALSA, ou passer par `module-echo-cancel` de PipeWire.
2. **Pas libsignal** (AGPL-3.0). L'implémentation suit les spécifications publiques sur libsodium et doit être auditée.
3. **Groupes chiffrés par paires plutôt que MLS**, avec confidentialité persistante, jusqu'à 256 membres.

## Licences

- **Qt 6, édition open source, LGPLv3, liée dynamiquement.**
  - Il faut livrer les `.so` de Qt, le texte de la licence et l'offre du code source.
  - L'utilisateur doit pouvoir réinstaller un Qt modifié, ce qui demande une validation juridique sur un appareil verrouillé.
  - Le clavier virtuel Qt est sous GPLv3 en édition open source : il faut le remplacer ou faire valider ce point.
- Licences des autres composants :
  - iceoryx2 : Apache-2.0 ou MIT ;
  - T-Modeler : EPL-2.0 ;
  - libsodium : ISC ;
  - Opus : BSD ;
  - Django, DRF, Channels, PyNaCl : BSD / Apache ;
  - cryptography : Apache / BSD ;
  - httpx : BSD.
- **FFmpeg** est sous LGPL en liaison dynamique, mais **x264 est sous GPLv2**.
  - En production, utiliser l'encodeur matériel `h264_v4l2m2m` (sélectionné en premier s'il est présent) ou libopenh264 (BSD, avec licence de brevet Cisco).
  - Sinon, se procurer une licence commerciale x264.
  - H.264 est soumis aux brevets du pool Via LA.

## Feuille de route

1. **V1.3**
   - contrôle de congestion pour les appels (rapports du récepteur, débit adaptatif) et annulation d'écho ;
   - vocaux enregistrés dans la conversation ;
   - assistant IA dans les groupes, sur invitation explicite.
2. **V2.0**
   - MLS pour les grands groupes, PQXDH ;
   - appels de groupe (le relais accepte déjà 8 membres ; il manque l'interface et le mixage) ;
   - réseau 5G privé OCUDU selon le site ;
   - audit cryptographique externe.
