// Ngoma — bus IPC local à faible latence (iceoryx2, zéro copie).
//
// Le cœur Qt ne dépend que de cette interface. Sans iceoryx2 (option NGOMA_WITH_ICEORYX2=OFF,
// ex. poste de développement), une implémentation nulle est utilisée : la messagerie fonctionne,
// seuls les médias locaux sont désactivés.
#pragma once

#include <QImage>
#include <QObject>
#include <QTimer>
#include <memory>

#include "IpcTypes.h"

namespace ngoma {

class IpcBus : public QObject {
    Q_OBJECT
public:
    /// `prefix` : espace de noms des services (défaut : variable NGOMA_IPC_PREFIX, vide en production).
    explicit IpcBus(QObject* parent = nullptr, const QString& prefix = qEnvironmentVariable("NGOMA_IPC_PREFIX"));
    ~IpcBus() override;

    bool available() const;

    void sendCallControl(const ipc::CallControl& cmd);
    void publishMessageEvent(const QString& messagingId, int unreadTotal);

    /// Active la réception des trames vidéo (sondage sur la boucle Qt ; ~ 60 Hz).
    void setVideoReceiving(bool on);

signals:
    void localFrame(const QImage& frame);
    void remoteFrame(const QImage& frame);
    void audioLevel(float mic, float speaker);
    void mediaState(int state, quint64 callSeq, quint32 framesSent);

private:
    void poll();
    struct Impl;
    std::unique_ptr<Impl> d;
    QTimer m_timer;
};

}  // namespace ngoma
