import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Ngoma.Core

ApplicationWindow {
    id: window
    visible: true
    visibility: Window.FullScreen
    width: 1024
    height: 600
    title: Theme.brand
    color: Theme.background
    font.pixelSize: Theme.fontBody

    // Palette sombre globale : tout contrôle non personnalisé (ComboBox, Switch, Dialog, menus…) hérite du thème.
    palette {
        window: Theme.background
        windowText: Theme.text
        base: Theme.surfaceHigh
        alternateBase: Theme.surface
        text: Theme.text
        button: Theme.surfaceHigh
        buttonText: Theme.text
        brightText: Theme.text
        highlight: Theme.accent
        highlightedText: Theme.accentText
        placeholderText: Theme.textMuted
        light: Theme.surfaceHover
        midlight: Theme.surfaceHigh
        mid: Theme.outlineStrong
        dark: Theme.outline
        shadow: "#000000"
        toolTipBase: Theme.surfaceHigh
        toolTipText: Theme.text
        link: Theme.accent
    }

    StatusBar { id: statusBar; anchors.top: parent.top; anchors.left: parent.left; anchors.right: parent.right; z: 10 }

    StackView {
        id: stack
        anchors.top: statusBar.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        initialItem: splash
    }

    Component {
        id: splash
        Item {
            Column {
                anchors.centerIn: parent
                spacing: 16
                Text { text: Theme.brand; color: Theme.text; font.pixelSize: 44; font.weight: Font.Bold; font.letterSpacing: 6; anchors.horizontalCenter: parent.horizontalCenter }
                BusyIndicator { running: true; anchors.horizontalCenter: parent.horizontalCenter }
            }
        }
    }
    Component { id: enrollPage; EnrollPage {} }
    Component { id: conversationsPage; ConversationsPage {} }

    function route() {
        if (App.state === "enroll") stack.replace(null, enrollPage)
        else if (App.state === "ready") stack.replace(null, conversationsPage)
    }
    Connections {
        target: App
        function onStateChanged() { window.route() }
        function onErrorOccurred(message) { toast.show(message, true) }
        function onNotice(message) { toast.show(message, false) }
    }
    Component.onCompleted: route()

    CallOverlay { anchors.fill: parent; z: 50 }

    // Notification non bloquante
    Rectangle {
        id: toast
        property bool error: false
        z: 100
        width: Math.min(parent.width - 48, 720)
        height: toastRow.implicitHeight + 28
        radius: Theme.radius
        color: error ? "#3b1a19" : Theme.surfaceHigh
        border.color: error ? Theme.danger : Theme.outlineStrong
        anchors.horizontalCenter: parent.horizontalCenter
        y: visible ? parent.height - height - 28 : parent.height
        visible: false
        Behavior on y { NumberAnimation { duration: 160 } }
        RowLayout {
            id: toastRow
            anchors.fill: parent; anchors.margins: 14; spacing: 12
            Image { source: Theme.icon(toast.error ? "alert" : "check", toast.error ? "danger" : "accent"); sourceSize: Qt.size(22, 22) }
            Text { id: toastText; Layout.fillWidth: true; color: Theme.text; wrapMode: Text.Wrap; font.pixelSize: Theme.fontBody }
        }
        Timer { id: toastTimer; interval: 4500; onTriggered: toast.visible = false }
        MouseArea { anchors.fill: parent; onClicked: toast.visible = false }
        function show(message, isError) {
            toastText.text = message; error = isError; visible = true; toastTimer.restart()
        }
    }
}
