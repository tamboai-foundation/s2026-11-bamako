// Codecs de ngoma-media : audio Opus (48 kHz mono, trames de 20 ms) et vidéo H.264 (FFmpeg / libavcodec).
#pragma once

#include <chrono>
#include <cstdint>
#include <map>
#include <memory>
#include <string>
#include <vector>

struct OpusEncoder;
struct OpusDecoder;
struct AVCodecContext;
struct AVFrame;
struct AVPacket;
struct SwsContext;
struct _snd_pcm;

namespace ngoma::media {

constexpr int kSampleRate = 48000;
constexpr int kFrameSamples = 960;  // 20 ms

// ------------------------------------------------------------------ audio

/// Capture : ALSA (« default ») ou source de test (NGOMA_AUDIO_TEST=sine : 440 Hz ; =silence).
class AudioCapture {
public:
    bool open();
    void close();
    /// Remplit `out` (kFrameSamples) si une trame complète est disponible.
    bool read(std::int16_t* out);
    bool isTest() const { return m_test; }

private:
    _snd_pcm* m_pcm = nullptr;
    bool m_test = false;
    bool m_sine = false;
    double m_phase = 0;
    std::vector<std::int16_t> m_ring;
};

/// Restitution : ALSA ou puits nul (bancs d'essai) ; la mesure de niveau fonctionne dans les deux cas.
class AudioPlayback {
public:
    bool open();
    void close();
    void write(const std::int16_t* pcm);

private:
    _snd_pcm* m_pcm = nullptr;
};

class OpusCodec {
public:
    ~OpusCodec();
    bool init();
    int encode(const std::int16_t* pcm, std::uint8_t* out, int maxBytes);
    int decode(const std::uint8_t* data, int len, std::int16_t* pcm);  // data == nullptr : masquage de perte

private:
    OpusEncoder* m_enc = nullptr;
    OpusDecoder* m_dec = nullptr;
};

/// Tampon de gigue d'un émetteur : réordonne par horodatage, démarre après 3 trames, masque les pertes.
class JitterBuffer {
public:
    void push(std::uint32_t ts, const std::uint8_t* data, std::size_t len);
    /// Trame suivante à restituer (vide = perte à masquer). Faux tant que le tampon s'amorce.
    bool pop(std::vector<std::uint8_t>& out);

private:
    std::map<std::uint32_t, std::vector<std::uint8_t>> m_q;
    std::uint32_t m_next = 0;
    bool m_started = false;
    int m_misses = 0;
};

float rms(const std::int16_t* pcm, int n);

// ------------------------------------------------------------------ vidéo

class VideoEncoder {
public:
    ~VideoEncoder();
    /// Encodeur H.264 : NGOMA_H264_ENCODER, sinon h264_v4l2m2m (matériel), libx264, libopenh264.
    bool open(int width, int height, int fps, int bitrateKbps, std::string& name);
    /// Encode une image BGRx (stride = width*4). Renvoie les octets Annex-B de la trame (vide si retenue).
    std::vector<std::uint8_t> encode(const std::uint8_t* bgrx, bool forceKeyframe, bool& isKey);

private:
    AVCodecContext* m_ctx = nullptr;
    AVFrame* m_frame = nullptr;
    AVPacket* m_pkt = nullptr;
    SwsContext* m_sws = nullptr;
    std::int64_t m_pts = 0;
};

class VideoDecoder {
public:
    ~VideoDecoder();
    bool open();
    /// Décode une trame Annex-B ; écrit une image BGRx dans `out`.
    bool decode(const std::uint8_t* data, std::size_t len, std::vector<std::uint8_t>& out, int& width, int& height);

private:
    AVCodecContext* m_ctx = nullptr;
    AVFrame* m_frame = nullptr;
    AVPacket* m_pkt = nullptr;
    SwsContext* m_sws = nullptr;
    int m_swsW = 0, m_swsH = 0;
};

/// Réassemblage des fragments vidéo d'un émetteur.
class FrameAssembler {
public:
    /// Renvoie vrai quand une trame complète est disponible dans `frame`.
    bool add(std::uint32_t frameId, std::uint16_t idx, std::uint16_t count, bool key, const std::uint8_t* data,
             std::size_t len, std::vector<std::uint8_t>& frame, bool& isKey);
    bool needsKeyframe() const { return m_needKey; }
    void keyframeReceived() { m_needKey = false; }

private:
    std::uint32_t m_id = 0;
    std::uint16_t m_count = 0;
    bool m_key = false;
    std::vector<std::vector<std::uint8_t>> m_parts;
    std::uint16_t m_have = 0;
    bool m_active = false;
    bool m_needKey = true;
    std::uint32_t m_lastComplete = 0;
};

}  // namespace ngoma::media
