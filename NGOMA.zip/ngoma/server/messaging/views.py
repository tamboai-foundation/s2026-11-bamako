import uuid

from rest_framework import serializers
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.serializers import UserSerializer

from . import services
from .models import Messaging, Receipt


def _error(exc: services.SyncError) -> Response:
    return Response({"detail": exc.detail, **exc.extra}, status=exc.status)


def conversation_payload(conv: Messaging) -> dict:
    return {
        "id": str(conv.id),
        "kind": conv.kind,
        "title": conv.title,
        "last_seq": conv.last_seq,
        "updated_at": conv.updated_at.isoformat(),
        "members": [
            {**UserSerializer(m.user).data, "role": m.role} for m in conv.memberships.all()
        ],
    }


class CreateConversationSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=[Messaging.DIRECT, Messaging.GROUP])
    member_ids = serializers.ListField(child=serializers.IntegerField(), min_length=1, max_length=512)
    title = serializers.CharField(required=False, allow_blank=True, max_length=200)


class ConversationsView(APIView):
    def get(self, request):
        return Response([conversation_payload(c) for c in services.conversations_for(request.user)])

    def post(self, request):
        ser = CreateConversationSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        try:
            conv, created = services.create_conversation(
                request.user, ser.validated_data["kind"], ser.validated_data["member_ids"],
                ser.validated_data.get("title", ""),
            )
        except services.SyncError as exc:
            return _error(exc)
        conv = services.conversations_for(request.user).get(pk=conv.pk)
        return Response(conversation_payload(conv), status=201 if created else 200)


class ConversationDevicesView(APIView):
    """Appareils destinataires attendus pour chiffrer un message dans cette conversation."""

    def get(self, request, messaging_id):
        try:
            membership = services.membership_or_raise(request.user, messaging_id)
        except services.SyncError as exc:
            return _error(exc)
        devices = services.expected_devices(membership.messaging)
        return Response(
            [{"device_id": str(d.pk), "user_id": d.user_id, "public_key": d.public_key} for d in devices]
        )


class PushSerializer(serializers.Serializer):
    messaging_id = serializers.UUIDField()
    client_id = serializers.UUIDField()
    kind = serializers.ChoiceField(choices=["text", "media"], default="text")
    expires_in = serializers.IntegerField(required=False, allow_null=True)
    envelopes = serializers.ListField(child=serializers.DictField(), min_length=0, max_length=4096)


class PushView(APIView):
    def post(self, request):
        ser = PushSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        try:
            res = services.push_message(
                user=request.user, device=request.auth, messaging_id=d["messaging_id"], client_id=d["client_id"],
                envelopes=d["envelopes"], kind=d["kind"], expires_in=d.get("expires_in"),
            )
        except services.SyncError as exc:
            return _error(exc)
        m = res.message
        return Response(
            {"id": str(m.id), "seq": m.seq, "client_id": str(m.client_id), "created_at": m.created_at.isoformat(),
             "duplicate": not res.created},
            status=201 if res.created else 200,
        )


class PullView(APIView):
    def get(self, request):
        try:
            messaging_id = uuid.UUID(request.query_params["messaging_id"])
            after_seq = int(request.query_params.get("after_seq", 0))
            limit = int(request.query_params.get("limit", 100))
        except (KeyError, ValueError):
            return Response({"detail": "Paramètres invalides"}, status=400)
        try:
            return Response(
                services.pull_messages(
                    user=request.user, device=request.auth, messaging_id=messaging_id, after_seq=after_seq, limit=limit
                )
            )
        except services.SyncError as exc:
            return _error(exc)


class StateView(APIView):
    def get(self, request):
        return Response({"conversations": services.sync_state(request.user)})


class AckSerializer(serializers.Serializer):
    messaging_id = serializers.UUIDField()
    delivered_seq = serializers.IntegerField(required=False, min_value=0)
    read_seq = serializers.IntegerField(required=False, min_value=0)


class AckView(APIView):
    def post(self, request):
        ser = AckSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        d = ser.validated_data
        try:
            r = services.ack(
                user=request.user, messaging_id=d["messaging_id"], delivered_seq=d.get("delivered_seq"),
                read_seq=d.get("read_seq"),
            )
        except services.SyncError as exc:
            return _error(exc)
        return Response({"delivered_seq": r.delivered_seq, "read_seq": r.read_seq})


class ReceiptsView(APIView):
    def get(self, request, messaging_id):
        try:
            services.membership_or_raise(request.user, messaging_id)
        except services.SyncError as exc:
            return _error(exc)
        rows = Receipt.objects.filter(messaging_id=messaging_id).values("user_id", "delivered_seq", "read_seq")
        return Response(list(rows))
