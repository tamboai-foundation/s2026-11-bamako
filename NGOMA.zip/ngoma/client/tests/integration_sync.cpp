// Test d'intégration bout en bout (V1.2) : serveur Django réel + worker des bots + deux terminaux C++.
// Variables : NGOMA_SERVER_URL, NGOMA_PROVISIONING_CODE, STORE_A, STORE_B, FAKE_LLM_URL.
#include <QJsonArray>
#include <QJsonDocument>
#include <QTemporaryDir>
#include <QtTest>

#include "core/ApiClient.h"
#include "core/Crypto.h"
#include "core/RealtimeClient.h"
#include "core/StoreClient.h"
#include "core/SyncEngine.h"
#include "core/Uuid7.h"

using namespace ngoma;

namespace {
struct Terminal {
    Config cfg;
    QTemporaryDir dir;
    std::unique_ptr<SecretStore> secrets;
    std::unique_ptr<ApiClient> api;
    std::unique_ptr<RealtimeClient> rt;
    std::unique_ptr<StoreClient> store;
    std::unique_ptr<SyncEngine> sync;
    Identity id;
};

ApiReply waitReply(std::function<void(ApiClient::Callback)> fn) {
    ApiReply out;
    bool done = false;
    fn([&](const ApiReply& r) { out = r; done = true; });
    if (!QTest::qWaitFor([&] { return done; }, 10000)) qWarning("délai dépassé (API)");
    return out;
}

QJsonValue storeCall(StoreClient& s, const QString& op, const QJsonObject& args) {
    QJsonValue out;
    bool done = false;
    s.call(op, args, [&](bool, const QJsonValue& v, const QString&) { out = v; done = true; });
    if (!QTest::qWaitFor([&] { return done; }, 5000)) qWarning("délai dépassé (stockage)");
    return out;
}

QJsonArray messages(Terminal& t, const QString& conv) {
    return storeCall(*t.store, "msg.list", {{"messaging_id", conv}, {"before_seq", 0}, {"limit", 100}}).toArray();
}
}  // namespace

class IntegrationSync : public QObject {
    Q_OBJECT
    Terminal a, b;
    QString conv;

    void makeTerminal(Terminal& t, const QString& sock, const QString& username) {
        t.cfg = Config::load();
        t.cfg.storeSocket = sock;
        t.cfg.dataDir = t.dir.path();
        t.secrets = std::make_unique<SecretStore>(t.cfg.dataDir);
        t.api = std::make_unique<ApiClient>(t.cfg);
        t.rt = std::make_unique<RealtimeClient>(t.cfg, t.api->sslConfiguration());
        t.store = std::make_unique<StoreClient>(sock);
        t.sync = std::make_unique<SyncEngine>(*t.api, *t.rt, *t.store, *t.secrets);
        t.store->connectToDaemon();
        QTRY_VERIFY_WITH_TIMEOUT(t.store->isReady(), 5000);

        t.id.keys = ratchet::DeviceKeys::generate();
        const QJsonObject req{{"username", username}, {"password", QString::fromLatin1(Crypto::random(18).toHex())}, {"display_name", username},
                              {"provisioning_code", qEnvironmentVariable("NGOMA_PROVISIONING_CODE")},
                              {"device_name", "test"}, {"public_key", QString::fromLatin1(t.id.keys.identityPublic().toBase64())}};
        const auto r = waitReply([&](ApiClient::Callback cb) { t.api->post("auth/signup", QJsonDocument(req), cb); });
        QVERIFY2(r.ok(), qPrintable(QString::number(r.status) + r.body.toJson()));
        const auto o = r.body.object();
        t.id.userId = o["user"].toObject()["id"].toInteger();
        t.id.username = username;
        t.id.deviceId = o["device_id"].toString();
        t.id.token = o["token"].toString();
        QVERIFY(t.secrets->save(t.id));
        t.api->setToken(t.id.token);
    }

    static bool prekeysPublished(Terminal& t) {
        const auto r = waitReply([&](ApiClient::Callback cb) { t.api->get("keys/prekeys", cb); });
        return r.ok() && r.body.object()["opk_count"].toInt() >= 20;
    }

private slots:
    void initTestCase() {
        QVERIFY(Crypto::init());
        const QString suffix = uuid7().right(6);
        makeTerminal(a, qEnvironmentVariable("STORE_A"), "alice" + suffix);
        makeTerminal(b, qEnvironmentVariable("STORE_B"), "bob" + suffix);
        a.sync->start(a.id);
        b.sync->start(b.id);
        QTRY_VERIFY_WITH_TIMEOUT(a.sync->isOnline() && b.sync->isOnline(), 10000);
        QTRY_VERIFY_WITH_TIMEOUT(prekeysPublished(a) && prekeysPublished(b), 10000);
    }

    void ratchetMessagesBothDirections() {
        const auto r = waitReply([&](ApiClient::Callback cb) {
            a.api->post("conversations", QJsonDocument(QJsonObject{{"kind", "direct"}, {"member_ids", QJsonArray{b.id.userId}}}), cb);
        });
        QVERIFY(r.ok());
        conv = r.body.object()["id"].toString();
        QTRY_VERIFY_WITH_TIMEOUT(storeCall(*b.store, "conv.list", {}).toArray().size() == 1, 10000);
        bool synced = false;
        a.sync->refreshConversations([&] { synced = true; });
        QTRY_VERIFY_WITH_TIMEOUT(synced, 5000);

        a.sync->sendText(conv, QStringLiteral("Bonjour Bob — Double Ratchet ✓"));
        a.sync->sendText(conv, QStringLiteral("deuxième message"));
        QTRY_VERIFY_WITH_TIMEOUT(messages(b, conv).size() == 2 &&
                                     messages(b, conv)[1].toObject()["body"].toString() == QStringLiteral("deuxième message") &&
                                     messages(b, conv)[0].toObject()["body"].toString() == QStringLiteral("Bonjour Bob — Double Ratchet ✓"),
                                 15000);
        b.sync->sendText(conv, QStringLiteral("Réponse de Bob"));  // rotation DH côté Bob
        QTRY_VERIFY_WITH_TIMEOUT(messages(a, conv).size() == 3 &&
                                     messages(a, conv)[2].toObject()["body"].toString() == QStringLiteral("Réponse de Bob"),
                                 15000);
        // La session d'Alice vers Bob existe désormais sur disque, et la prékey utilisée a été consommée.
        QVERIFY(a.secrets->loadSession(b.id.deviceId).has_value());
        QVERIFY(b.secrets->loadSession(a.id.deviceId).has_value());
        b.sync->markRead(conv, 2);
        QTRY_VERIFY_WITH_TIMEOUT(storeCall(*a.store, "conv.list", {}).toArray()[0].toObject()["peer_read_seq"].toInteger() == 2, 10000);
    }

    void offlineOutboxIsFlushedOnReconnect() {
        a.rt->stop();
        QTRY_VERIFY_WITH_TIMEOUT(!a.sync->isOnline(), 5000);
        a.sync->sendText(conv, QStringLiteral("écrit hors ligne"));
        QTRY_COMPARE_WITH_TIMEOUT(storeCall(*a.store, "msg.pending", {}).toArray().size(), qsizetype(1), 5000);
        a.rt->start(a.id.token);
        QTRY_VERIFY_WITH_TIMEOUT(messages(b, conv).size() == 4 &&
                                     messages(b, conv)[3].toObject()["body"].toString() == QStringLiteral("écrit hors ligne"),
                                 20000);
        QCOMPARE(storeCall(*a.store, "msg.pending", {}).toArray().size(), qsizetype(0));
    }

    void encryptedAttachment() {
        const QByteArray plain = Crypto::random(200000);
        QByteArray key, nonce;
        const QByteArray blob = Crypto::sealBlob(plain, key, nonce);
        const auto up = waitReply([&](ApiClient::Callback cb) { a.api->postFile("media", {{"messaging_id", conv}}, blob, cb); });
        QVERIFY2(up.ok(), qPrintable(QString::number(up.status)));
        const QJsonObject meta{{"id", up.body.object()["media_id"]}, {"name", "rapport.bin"}, {"mime", "application/octet-stream"},
                               {"size", plain.size()}, {"sha256", QString::fromLatin1(Crypto::sha256(plain).toBase64())},
                               {"k", QString::fromLatin1(key.toBase64())}, {"n", QString::fromLatin1(nonce.toBase64())},
                               {"path", "/chemin/local/secret"}};
        a.sync->sendMedia(conv, QStringLiteral("le rapport"), meta);
        QJsonObject got;
        QTRY_VERIFY_WITH_TIMEOUT(
            [&] {
                const auto l = messages(b, conv);
                if (l.size() < 5) return false;
                got = l[4].toObject();
                return got["kind"].toString() == "media";
            }(),
            15000);
        QCOMPARE(got["body"].toString(), QStringLiteral("le rapport"));
        const auto m = QJsonDocument::fromJson(got["meta"].toString().toUtf8()).object();
        QVERIFY2(!m.contains("path"), "le chemin local de l'expéditeur ne doit pas être transmis");
        int status = 0;
        QByteArray downloaded;
        b.api->getBytes("media/" + m["id"].toString(), [&](int s, const QByteArray& d) { status = s; downloaded = d; });
        QTRY_COMPARE_WITH_TIMEOUT(status, 200, 10000);
        const auto opened = Crypto::openBlob(downloaded, QByteArray::fromBase64(m["k"].toString().toLatin1()),
                                             QByteArray::fromBase64(m["n"].toString().toLatin1()));
        QVERIFY(opened.has_value());
        QCOMPARE(Crypto::sha256(*opened).toBase64(), m["sha256"].toString().toLatin1());
    }

    void callKeyExchange() {
        const QByteArray secret = R"({"t":"callkey","call_id":"x","k":"AAAA"})";
        bool done = false;
        QJsonObject envs;
        a.sync->encryptForUser(conv, b.id.userId, secret, [&](bool ok, const QJsonObject& e) {
            QVERIFY(ok);
            envs = e;
            done = true;
        });
        QTRY_VERIFY_WITH_TIMEOUT(done, 10000);
        QVERIFY(envs.contains(b.id.deviceId));
        const auto plain = b.sync->decryptFromDevice(a.id.deviceId, envs[b.id.deviceId].toObject());
        QVERIFY(plain.has_value());
        QCOMPARE(*plain, secret);
    }

    void serverSideAssistant() {
        const QString llm = qEnvironmentVariable("FAKE_LLM_URL");
        if (llm.isEmpty()) QSKIP("FAKE_LLM_URL non défini");
        const auto r = waitReply([&](ApiClient::Callback cb) {
            a.api->post("bots/me", QJsonDocument(QJsonObject{{"provider", "openai"}, {"model", "modele-test"},
                                                            {"api_key", qEnvironmentVariable("NGOMA_FAKE_LLM_KEY")}, {"base_url", llm}}), cb);
        });
        QVERIFY2(r.ok(), qPrintable(r.body.toJson()));
        QVERIFY(!r.body.object().contains("api_key"));
        const QString botConv = r.body.object()["conversation_id"].toString();
        // Le bot (Python) a ouvert une session X3DH vers l'appareil C++ d'Alice : message d'accueil déchiffré.
        QTRY_VERIFY_WITH_TIMEOUT(!messages(a, botConv).isEmpty() &&
                                     messages(a, botConv)[0].toObject()["body"].toString().startsWith("Bonjour, je suis votre assistant IA"),
                                 15000);
        a.sync->sendText(botConv, QStringLiteral("Quelle est la capitale du Bénin ?"));
        QTRY_VERIFY_WITH_TIMEOUT(
            [&] {
                const auto l = messages(a, botConv);
                return l.size() >= 3 && l.last().toObject()["body"].toString() ==
                                            QStringLiteral("Réponse IA : Quelle est la capitale du Bénin ?");
            }(),
            20000);
        const auto off = waitReply([&](ApiClient::Callback cb) { a.api->del("bots/me", cb); });
        QVERIFY(off.ok() && !off.body.object()["active"].toBool());
        QTRY_VERIFY_WITH_TIMEOUT(messages(a, botConv).last().toObject()["body"].toString().contains("désactivé"), 10000);
    }
};

QTEST_GUILESS_MAIN(IntegrationSync)
#include "integration_sync.moc"
