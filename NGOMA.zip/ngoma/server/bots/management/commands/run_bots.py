import logging
import signal
import time

from django.conf import settings
from django.core.management.base import BaseCommand

from bots.engine import pending_profiles, process_bot

log = logging.getLogger("ngoma.bots")


class Command(BaseCommand):
    help = "Worker des assistants IA (plusieurs instances possibles : un bail par bot évite les doublons)."

    def add_arguments(self, parser):
        parser.add_argument("--once", action="store_true", help="Une seule passe puis sortie")

    def handle(self, *args, **opts):
        stop = {"v": False}
        signal.signal(signal.SIGTERM, lambda *_: stop.update(v=True))
        poll = settings.NGOMA["BOT_POLL_SECONDS"]
        while not stop["v"]:
            for profile in pending_profiles():
                try:
                    process_bot(profile)
                except Exception:  # un bot défaillant ne bloque pas les autres
                    log.exception("bot %s : échec du traitement", profile.pk)
            if opts["once"]:
                return
            time.sleep(poll)
