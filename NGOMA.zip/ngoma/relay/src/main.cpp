// ngoma-relay — relais UDP des appels Ngoma (sélectif, sans décodage, sans clé).
//
// Le relais ne voit que des paquets chiffrés de bout en bout. Il :
//   * n'admet un appareil dans un appel que sur présentation d'un jeton HMAC émis par le serveur Django
//     (POST /api/v1/calls/token) et non expiré ;
//   * ne relaie un paquet DATA que s'il vient de l'adresse inscrite pour le device_id annoncé (anti-usurpation) ;
//   * limite le débit par membre et fait expirer les membres silencieux.
// Variables : NGOMA_RELAY_SECRET (obligatoire), NGOMA_RELAY_BIND (0.0.0.0), NGOMA_RELAY_PORT (3479).
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sodium.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <ctime>
#include <iterator>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <map>
#include <string>
#include <vector>

#include "media/MediaWire.h"

namespace w = ngoma::wire;
using Clock = std::chrono::steady_clock;

namespace {

volatile std::sig_atomic_t g_stop = 0;
constexpr auto kIdle = std::chrono::seconds(30);
constexpr double kRatePps = 1500.0;  // paquets/s par membre (vidéo 720p + audio ≈ 300)
constexpr double kBurst = 3000.0;

struct Member {
    sockaddr_storage addr{};
    socklen_t addrLen = 0;
    w::Uuid device{};
    std::uint64_t userId = 0;
    std::uint64_t exp = 0;
    Clock::time_point lastSeen;
    double tokens = kBurst;
    Clock::time_point lastRefill;
};

bool sameAddr(const sockaddr_storage& a, socklen_t al, const sockaddr_storage& b, socklen_t bl) {
    return al == bl && std::memcmp(&a, &b, al) == 0;
}

struct Relay {
    std::string secret;
    int fd = -1;
    std::map<w::Uuid, std::vector<Member>> calls;
    std::uint64_t forwarded = 0, rejected = 0;

    bool verifyJoin(const std::uint8_t* p) const {
        // MAC = HMAC-SHA256(secret, call_id | user_id | device_id | exp) — identique à media_views.relay_token
        std::uint8_t msg[48];
        std::memcpy(msg, p + 4, 16);         // call_id
        std::memcpy(msg + 16, p + 20, 8);    // user_id
        std::memcpy(msg + 24, p + 28, 16);   // device_id
        std::memcpy(msg + 40, p + 44, 8);    // exp
        std::uint8_t mac[crypto_auth_hmacsha256_BYTES];
        crypto_auth_hmacsha256_state st;
        crypto_auth_hmacsha256_init(&st, reinterpret_cast<const unsigned char*>(secret.data()), secret.size());
        crypto_auth_hmacsha256_update(&st, msg, sizeof msg);
        crypto_auth_hmacsha256_final(&st, mac);
        return sodium_memcmp(mac, p + 52, 32) == 0;
    }

    void reply(const sockaddr_storage& to, socklen_t len, w::Type t, const w::Uuid& call, std::uint8_t extra) {
        std::uint8_t out[w::kHeader + 1];
        w::header(out, t, call);
        out[w::kHeader] = extra;
        sendto(fd, out, sizeof out, 0, reinterpret_cast<const sockaddr*>(&to), len);
    }

    void onPacket(const std::uint8_t* p, std::size_t len, const sockaddr_storage& from, socklen_t fromLen) {
        if (!w::validHeader(p, len) || len > w::kMaxPacket) {
            ++rejected;
            return;
        }
        w::Uuid call;
        std::memcpy(call.data(), p + 4, 16);
        const auto now = Clock::now();
        const auto type = w::Type(p[3]);

        if (type == w::Join) {
            if (len != w::kHeader + 64) return;
            const std::uint64_t exp = w::getBe(p + 44, 8);
            const auto unixNow = std::uint64_t(std::time(nullptr));
            if (exp < unixNow || !verifyJoin(p)) {
                ++rejected;
                reply(from, fromLen, w::JoinNack, call, 1);
                return;
            }
            w::Uuid device;
            std::memcpy(device.data(), p + 28, 16);
            auto& members = calls[call];
            Member* m = nullptr;
            for (auto& x : members)
                if (x.device == device) m = &x;
            if (!m) {
                if (members.size() >= w::kMaxMembers) {
                    reply(from, fromLen, w::JoinNack, call, 2);
                    return;
                }
                members.push_back({});
                m = &members.back();
                m->lastRefill = now;
            }
            m->addr = from;
            m->addrLen = fromLen;
            m->device = device;
            m->userId = w::getBe(p + 20, 8);
            m->exp = exp;
            m->lastSeen = now;
            reply(from, fromLen, w::JoinAck, call, std::uint8_t(members.size()));
            return;
        }

        auto it = calls.find(call);
        if (it == calls.end() || len < w::kHeader + 16) {
            ++rejected;
            return;
        }
        w::Uuid device;
        std::memcpy(device.data(), p + w::kHeader, 16);
        Member* sender = nullptr;
        for (auto& x : it->second)
            if (x.device == device && sameAddr(x.addr, x.addrLen, from, fromLen)) sender = &x;
        if (!sender) {  // device_id non inscrit ou adresse différente : usurpation refusée
            ++rejected;
            return;
        }
        sender->lastSeen = now;
        if (type == w::Keepalive) return;
        if (type == w::Leave) {
            auto& v = it->second;
            v.erase(std::remove_if(v.begin(), v.end(), [&](const Member& m) { return m.device == device; }), v.end());
            if (v.empty()) calls.erase(it);
            return;
        }
        if (type != w::Data) return;
        const double dt = std::chrono::duration<double>(now - sender->lastRefill).count();
        sender->lastRefill = now;
        sender->tokens = std::min(kBurst, sender->tokens + dt * kRatePps);
        if (sender->tokens < 1.0) {
            ++rejected;
            return;
        }
        sender->tokens -= 1.0;
        for (const auto& m : it->second) {
            if (&m == sender) continue;
            sendto(fd, p, len, 0, reinterpret_cast<const sockaddr*>(&m.addr), m.addrLen);
            ++forwarded;
        }
    }

    void expire() {
        const auto now = Clock::now();
        const auto unixNow = std::uint64_t(std::time(nullptr));
        for (auto it = calls.begin(); it != calls.end();) {
            auto& v = it->second;
            v.erase(std::remove_if(v.begin(), v.end(),
                                   [&](const Member& m) { return now - m.lastSeen > kIdle || m.exp < unixNow; }),
                    v.end());
            it = v.empty() ? calls.erase(it) : std::next(it);
        }
    }
};

}  // namespace

int main() {
    if (sodium_init() < 0) return 2;
    const char* secret = std::getenv("NGOMA_RELAY_SECRET");
    if (!secret || std::strlen(secret) < 16) {
        std::fprintf(stderr, "ngoma-relay : NGOMA_RELAY_SECRET (≥ 16 caractères) requis\n");
        return 2;
    }
    const char* bind = std::getenv("NGOMA_RELAY_BIND") ? std::getenv("NGOMA_RELAY_BIND") : "0.0.0.0";
    const int port = std::getenv("NGOMA_RELAY_PORT") ? std::atoi(std::getenv("NGOMA_RELAY_PORT")) : 3479;

    Relay relay;
    relay.secret = secret;
    relay.fd = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);
    int buf = 4 << 20;
    setsockopt(relay.fd, SOL_SOCKET, SO_RCVBUF, &buf, sizeof buf);
    setsockopt(relay.fd, SOL_SOCKET, SO_SNDBUF, &buf, sizeof buf);
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(std::uint16_t(port));
    inet_pton(AF_INET, bind, &addr.sin_addr);
    if (::bind(relay.fd, reinterpret_cast<sockaddr*>(&addr), sizeof addr) != 0) {
        std::perror("bind");
        return 1;
    }
    std::signal(SIGINT, [](int) { g_stop = 1; });
    std::signal(SIGTERM, [](int) { g_stop = 1; });

    int ep = epoll_create1(0);
    epoll_event ev{};
    ev.events = EPOLLIN;
    ev.data.fd = relay.fd;
    epoll_ctl(ep, EPOLL_CTL_ADD, relay.fd, &ev);
    std::fprintf(stderr, "ngoma-relay à l'écoute sur %s:%d/udp\n", bind, port);

    auto lastExpire = Clock::now();
    std::uint8_t pkt[2048];
    while (!g_stop) {
        epoll_event out[16];
        const int n = epoll_wait(ep, out, 16, 1000);
        for (int i = 0; i < n; ++i) {
            for (;;) {
                sockaddr_storage from{};
                socklen_t fromLen = sizeof from;
                const ssize_t len = recvfrom(relay.fd, pkt, sizeof pkt, 0, reinterpret_cast<sockaddr*>(&from), &fromLen);
                if (len <= 0) break;
                relay.onPacket(pkt, std::size_t(len), from, fromLen);
            }
        }
        if (Clock::now() - lastExpire > std::chrono::seconds(5)) {
            relay.expire();
            lastExpire = Clock::now();
        }
    }
    std::fprintf(stderr, "ngoma-relay arrêté (relayés : %llu, rejetés : %llu)\n",
                 static_cast<unsigned long long>(relay.forwarded), static_cast<unsigned long long>(relay.rejected));
    close(ep);
    close(relay.fd);
    return 0;
}
