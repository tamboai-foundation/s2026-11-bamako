package io.ngoma.store

import ai.tambo.tmodeler.db.Tdb
import ai.tambo.tmodeler.extension.synchronization.core.TServerConfigBase
import ai.tambo.tmodeler.modeler.TModeler
import io.ngoma.store.models.Conversation
import kotlinx.serialization.json.*
import java.io.File
import java.nio.file.Files
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals

class StoreTest {
    companion object {
        private var started = false

        @Synchronized
        fun ready() {
            if (started) return
            val dir = Files.createTempDirectory("ngoma-store").toFile().also { it.deleteOnExit() }
            TModeler.start().connect(
                Tdb.Builder().type(Tdb.Type.SQLITE).dbDir(dir.path).dbName(File(dir, "t").path)
                    .server(TServerConfigBase()).accept(Conversation().clazz().getPackage()).start()!!
            )
            Store.commitSchema()
            started = true
        }
    }

    @BeforeTest
    fun setUp() {
        ready()
        inData { Store.wipe() }
    }

    private fun conv(id: String) = buildJsonArray {
        add(buildJsonObject { put("id", id); put("kind", "direct"); put("title", ""); put("last_seq", 0) })
    }

    @Test
    fun `outbox puis accuse d'envoi puis echo idempotent`() {
        inData { Store.upsertConversations(conv("c1")) }
        inData {
            Store.insertOutgoing(buildJsonObject {
                put("client_id", "u1"); put("messaging_id", "c1"); put("sender_id", 1); put("body", "bonjour")
            })
        }
        assertEquals(1, inData { Store.pendingOutbox(10) }.size)
        inData { Store.markSent(buildJsonObject { put("client_id", "u1"); put("seq", 1); put("remote_id", "r1") }) }
        assertEquals(0, inData { Store.pendingOutbox(10) }.size)

        // L'écho du pull ne duplique pas le message.
        inData {
            Store.upsertReceived("c1", buildJsonArray {
                add(buildJsonObject { put("client_id", "u1"); put("seq", 1); put("sender_id", 1); put("body", "bonjour") })
            }, myUserId = 1)
        }
        val list = inData { Store.listMessages("c1", 0, 50) }
        assertEquals(1, list.size)
        assertEquals("sent", list[0].jsonObject["state"]!!.jsonPrimitive.content)
    }

    @Test
    fun `pagination chronologique`() {
        inData { Store.upsertConversations(conv("c2")) }
        inData {
            Store.upsertReceived("c2", JsonArray((1..10).map { i ->
                buildJsonObject { put("client_id", "m$i"); put("seq", i); put("sender_id", 2); put("body", "n$i") }
            }), myUserId = 1)
        }
        val last3 = inData { Store.listMessages("c2", 0, 3) }.map { it.jsonObject["seq"]!!.jsonPrimitive.long }
        assertEquals(listOf(8L, 9L, 10L), last3)
        val before = inData { Store.listMessages("c2", 8, 3) }.map { it.jsonObject["seq"]!!.jsonPrimitive.long }
        assertEquals(listOf(5L, 6L, 7L), before)
    }
}
