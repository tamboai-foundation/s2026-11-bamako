import QtQuick
import QtQuick.Controls

// Bouton-icône carré ou rond. variant : "plain" (fond transparent), "filled", "primary", "danger".
AbstractButton {
    id: control
    property string iconName
    property string variant: "plain"
    property bool round: false
    property int iconSize: 24
    property string tip: ""

    implicitWidth: Theme.touch
    implicitHeight: Theme.touch
    hoverEnabled: true
    Accessible.name: tip

    contentItem: Item {
        Image {
            anchors.centerIn: parent
            source: control.iconName.length ? Theme.icon(control.iconName, control.variant === "primary" ? "dark" : "light") : ""
            sourceSize: Qt.size(control.iconSize, control.iconSize)
            opacity: control.enabled ? 1 : 0.35
        }
    }

    background: Rectangle {
        radius: control.round ? width / 2 : Theme.radiusSmall
        color: {
            if (control.variant === "primary") return control.down ? Theme.accentPressed : Theme.accent
            if (control.variant === "danger") return control.down ? Theme.dangerPressed : Theme.danger
            if (control.variant === "filled") return control.down ? Theme.surfacePressed : (control.hovered ? Theme.surfaceHover : Theme.surfaceHigh)
            return control.down ? Theme.surfacePressed : (control.hovered ? Theme.surfaceHigh : "transparent")
        }
        Behavior on color { ColorAnimation { duration: 90 } }
    }
}
