#include "ApiClient.h"

#include <QFile>
#include <QHttpMultiPart>
#include <QNetworkReply>
#include <QSslCertificate>
#include <QSslKey>

namespace ngoma {

ApiClient::ApiClient(const Config& cfg, QObject* parent) : QObject(parent), m_cfg(cfg) {
    m_ssl = QSslConfiguration::defaultConfiguration();
    m_ssl.setProtocol(QSsl::TlsV1_2OrLater);
    if (!cfg.caFile.isEmpty()) {
        // Épinglage de l'autorité : seule l'AC privée Ngoma est acceptée.
        const auto cas = QSslCertificate::fromPath(cfg.caFile);
        if (!cas.isEmpty()) m_ssl.setCaCertificates(cas);
    }
    if (!cfg.clientCertFile.isEmpty() && !cfg.clientKeyFile.isEmpty()) {
        const auto certs = QSslCertificate::fromPath(cfg.clientCertFile);
        QFile kf(cfg.clientKeyFile);
        if (!certs.isEmpty() && kf.open(QIODevice::ReadOnly)) {
            m_ssl.setLocalCertificate(certs.first());
            m_ssl.setPrivateKey(QSslKey(&kf, QSsl::Ec));
        }
    }
    m_nam.setTransferTimeout(15000);
    m_nam.setAutoDeleteReplies(true);
}

ApiClient::~ApiClient() {
    // Les réponses en vol sont abandonnées sans appeler leurs rappels (le destinataire peut être détruit).
    for (auto* reply : m_nam.findChildren<QNetworkReply*>()) {
        reply->disconnect(this);
        reply->abort();
    }
}

QNetworkRequest ApiClient::makeRequest(const QString& path) const {
    QNetworkRequest req(m_cfg.apiUrl(path));
    req.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    req.setRawHeader("Accept", "application/json");
    req.setRawHeader("User-Agent", "Ngoma-Terminal/1.0");
    if (!m_token.isEmpty()) req.setRawHeader("Authorization", "Device " + m_token.toLatin1());
    if (req.url().scheme() == QLatin1String("https")) req.setSslConfiguration(m_ssl);
    req.setAttribute(QNetworkRequest::Http2AllowedAttribute, true);
    return req;
}

void ApiClient::get(const QString& path, Callback cb) {
    handle(m_nam.get(makeRequest(path)), std::move(cb));
}

void ApiClient::post(const QString& path, const QJsonDocument& body, Callback cb) {
    handle(m_nam.post(makeRequest(path), body.toJson(QJsonDocument::Compact)), std::move(cb));
}

void ApiClient::del(const QString& path, Callback cb) {
    handle(m_nam.deleteResource(makeRequest(path)), std::move(cb));
}

void ApiClient::postFile(const QString& path, const QHash<QString, QString>& fields, const QByteArray& data, Callback cb) {
    auto* multi = new QHttpMultiPart(QHttpMultiPart::FormDataType);
    for (auto it = fields.cbegin(); it != fields.cend(); ++it) {
        QHttpPart part;
        part.setHeader(QNetworkRequest::ContentDispositionHeader, QStringLiteral("form-data; name=\"%1\"").arg(it.key()));
        part.setBody(it.value().toUtf8());
        multi->append(part);
    }
    QHttpPart file;
    file.setHeader(QNetworkRequest::ContentDispositionHeader, QStringLiteral("form-data; name=\"file\"; filename=\"blob.bin\""));
    file.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/octet-stream"));
    file.setBody(data);
    multi->append(file);
    QNetworkRequest req = makeRequest(path);
    req.setHeader(QNetworkRequest::ContentTypeHeader, QVariant());  // positionné par QHttpMultiPart (boundary)
    QNetworkReply* reply = m_nam.post(req, multi);
    multi->setParent(reply);
    reply->setProperty("ngoma_long", true);
    handle(reply, std::move(cb));
}

void ApiClient::getBytes(const QString& path, std::function<void(int, const QByteArray&)> cb) {
    QNetworkRequest req = makeRequest(path);
    req.setRawHeader("Accept", "application/octet-stream");
    QNetworkReply* reply = m_nam.get(req);
    connect(reply, &QNetworkReply::finished, this, [reply, cb = std::move(cb)]() {
        const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (cb) cb(status, reply->readAll());
    });
}

void ApiClient::handle(QNetworkReply* reply, Callback cb) {
    connect(reply, &QNetworkReply::finished, this, [this, reply, cb = std::move(cb)]() {
        ApiReply r;
        r.status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        const QByteArray data = reply->readAll();
        if (!data.isEmpty()) r.body = QJsonDocument::fromJson(data);
        if (reply->error() != QNetworkReply::NoError && r.status == 0) r.error = reply->errorString();
        if (r.status == 401 && !m_token.isEmpty()) emit unauthorized();
        if (cb) cb(r);
    });
}

}  // namespace ngoma
