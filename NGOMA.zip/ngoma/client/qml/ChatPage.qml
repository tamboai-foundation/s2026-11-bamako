import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import Ngoma.Core

Page {
    id: page
    background: Rectangle { color: Theme.background }
    property int ephemeral: 0   // secondes ; 0 = désactivé
    readonly property var info: App.conversations.count >= 0 ? App.conversations.infoOf(App.currentConversationId) : ({})
    readonly property bool isGroup: info.kind === "group"
    readonly property bool isAssistant: info.isAssistant === true

    header: PageHeader {
        showBack: true
        title: App.currentTitle
        subtitle: App.typingText.length ? App.typingText
                 : page.isAssistant ? qsTr("Assistant IA · déchiffré sur le serveur")
                 : page.isGroup ? qsTr("%1 membres").arg(page.info.memberCount || 0)
                 : qsTr("Chiffré de bout en bout")
        onBack: { App.saveDraft(input.text); App.closeConversation(); page.StackView.view.pop() }
        IconButton {
            iconName: "timer"; tip: qsTr("Messages éphémères")
            variant: page.ephemeral > 0 ? "primary" : "plain"
            onClicked: page.ephemeral = page.ephemeral === 0 ? 300 : (page.ephemeral === 300 ? 3600 : 0)
        }
        IconButton {
            iconName: "phone"; tip: qsTr("Appeler")
            visible: !page.isGroup && !page.isAssistant
            enabled: App.online && App.callState === "idle"
            onClicked: App.startCall()
        }
    }

    ListView {
        id: list
        anchors.top: parent.top; anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: ephemeralBar.top
        model: App.messages
        clip: true
        reuseItems: true
        cacheBuffer: 1200
        spacing: 4
        topMargin: 12; bottomMargin: 12
        boundsBehavior: Flickable.StopAtBounds
        ScrollIndicator.vertical: ScrollIndicator {}
        property bool stickToBottom: true

        delegate: MessageBubble {
            width: ListView.view.width
            body: model.body; mine: model.mine; state: model.state; time: model.time
            senderName: model.senderName; readByPeer: model.readByPeer; showSender: page.isGroup || page.isAssistant
            kind: model.kind; fileName: model.fileName; fileSize: model.fileSize; thumbnail: model.thumbnail
            localPath: model.localPath; isImage: model.isImage
            onRetry: App.retryFailed()
            onDownload: App.downloadAttachment(model.clientId)
        }
        onCountChanged: if (stickToBottom) Qt.callLater(positionViewAtEnd)
        onMovementEnded: stickToBottom = atYEnd
        onAtYBeginningChanged: if (atYBeginning && count > 0 && moving) App.loadOlder()
        Component.onCompleted: positionViewAtEnd()
    }

    Rectangle {
        id: ephemeralBar
        anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: composer.top
        height: page.ephemeral > 0 ? 34 : 0
        visible: height > 0
        color: Theme.warningSoft
        RowLayout {
            anchors.centerIn: parent; spacing: 8
            Image { source: Theme.icon("timer", "light"); sourceSize: Qt.size(16, 16) }
            Text { color: Theme.text; font.pixelSize: Theme.fontSmall
                   text: qsTr("Messages éphémères : supprimés après %1").arg(page.ephemeral >= 3600 ? qsTr("1 heure") : qsTr("5 minutes")) }
        }
    }

    FileDialog {
        id: picker
        title: qsTr("Joindre un fichier (%1 Mo max.)").arg(App.maxAttachmentMb)
        onAccepted: { App.sendFile(selectedFile, input.text); input.text = "" }
    }

    Rectangle {
        id: composer
        anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom
        height: Math.min(180, Math.max(Theme.touch + 20, input.implicitHeight + 20))
        color: Theme.surface
        Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: Theme.outline }
        RowLayout {
            anchors.fill: parent; anchors.margins: 10; spacing: 8
            IconButton { iconName: "attach"; tip: qsTr("Joindre"); enabled: !App.busy && !page.isAssistant; onClicked: picker.open(); Layout.alignment: Qt.AlignBottom }
            ScrollView {
                Layout.fillWidth: true; Layout.fillHeight: true
                TextArea {
                    id: input
                    placeholderText: page.ephemeral > 0 ? qsTr("Message éphémère…") : qsTr("Écrire un message")
                    placeholderTextColor: Theme.textMuted
                    wrapMode: TextEdit.Wrap; font.pixelSize: Theme.fontBody; color: Theme.text
                    selectionColor: Theme.accent; selectedTextColor: Theme.accentText
                    leftPadding: 16; rightPadding: 16; topPadding: 14; bottomPadding: 14
                    background: Rectangle {
                        radius: Theme.radius + 6; color: Theme.surfaceHigh
                        border.width: input.activeFocus ? 2 : 1
                        border.color: input.activeFocus ? Theme.accent : Theme.outline
                    }
                    text: App.draftFor(App.currentConversationId)
                    onTextChanged: if (text.length) App.notifyTyping()
                    Keys.onReturnPressed: (event) => {
                        if (event.modifiers & Qt.ShiftModifier) { event.accepted = false; return }
                        sendButton.clicked()
                    }
                }
            }
            IconButton {
                id: sendButton
                iconName: "send"; variant: "primary"; round: true; tip: qsTr("Envoyer")
                Layout.alignment: Qt.AlignBottom
                enabled: input.text.trim().length > 0
                onClicked: { App.send(input.text, page.ephemeral); input.text = ""; list.stickToBottom = true }
            }
        }
    }
}
