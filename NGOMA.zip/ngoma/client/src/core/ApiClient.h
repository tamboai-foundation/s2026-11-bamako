#pragma once

#include <QJsonDocument>
#include <QNetworkAccessManager>
#include <QObject>
#include <QSslConfiguration>
#include <functional>

#include "Config.h"

namespace ngoma {

struct ApiReply {
    int status = 0;         // 0 = erreur réseau (hors ligne, TLS, délai)
    QJsonDocument body;
    QString error;
    bool ok() const { return status >= 200 && status < 300; }
    bool networkError() const { return status == 0; }
};

/// Client REST asynchrone vers /api/v1. Toutes les requêtes ont un délai borné et sont authentifiées
/// par `Authorization: Device <jeton>` une fois l'appareil enrôlé.
class ApiClient : public QObject {
    Q_OBJECT
public:
    using Callback = std::function<void(const ApiReply&)>;

    explicit ApiClient(const Config& cfg, QObject* parent = nullptr);
    ~ApiClient() override;

    void setToken(const QString& token) { m_token = token; }
    const QSslConfiguration& sslConfiguration() const { return m_ssl; }

    void get(const QString& path, Callback cb);
    void post(const QString& path, const QJsonDocument& body, Callback cb);
    void del(const QString& path, Callback cb);
    /// Téléversement multipart (champs texte + un fichier binaire déjà chiffré).
    void postFile(const QString& path, const QHash<QString, QString>& fields, const QByteArray& data, Callback cb);
    /// Téléchargement binaire (pièce jointe chiffrée). `body` est vide : les octets sont dans `bytes`.
    void getBytes(const QString& path, std::function<void(int status, const QByteArray& bytes)> cb);

signals:
    void unauthorized();  // jeton révoqué : retour à l'écran d'enrôlement

private:
    QNetworkRequest makeRequest(const QString& path) const;
    void handle(QNetworkReply* reply, Callback cb);

    const Config& m_cfg;
    QNetworkAccessManager m_nam;
    QSslConfiguration m_ssl;
    QString m_token;
};

}  // namespace ngoma
