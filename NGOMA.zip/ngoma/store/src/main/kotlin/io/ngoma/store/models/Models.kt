package io.ngoma.store.models

import ai.tambo.tmodeler.field.common.IntField
import ai.tambo.tmodeler.field.common.TextField
import ai.tambo.tmodeler.model.TMignore
import ai.tambo.tmodeler.model.TModel
import ai.tambo.tmodeler.ms.Tms

/*
 * Modèles locaux du terminal NGOMA.
 *
 * Note : `id` / `_id` sont réservés par T-Modeler (identifiant serveur / clé locale). Les identifiants
 * Ngoma sont donc stockés dans des champs dédiés (`remoteId`, `clientId`, `messagingId`).
 * Le moteur de synchronisation est INTERNE (nexmsg-core, C++) : aucun TSyncEngine n'est branché,
 * ce démon est une base locale pure (§17 du guide T-Modeler : « Local database only »).
 * Le contenu en clair n'existe que sur la partition chiffrée (LUKS) du terminal.
 */

/** Conversation (1:1 ou groupe). */
class Conversation : TModel<Conversation>() {
    var remoteId = TextField().unique()
    var kind = TextField().default("")
    var title = TextField().default("")
    var membersJson = TextField().default("")        // [{"id":..,"username":..,"display_name":..,"role":..}]
    var serverSeq = IntField().default(0) // dernier seq connu côté serveur
    var pulledSeq = IntField().default(0) // dernier seq téléchargé (curseur de sync)
    var readSeq = IntField().default(0)   // dernier seq lu localement
    var peerReadSeq = IntField().default(0)
    var updatedAt = TextField().default("")           // ISO-8601
    var draft = TextField().default("")

    @TMignore var remoteId_ by remoteId
    @TMignore var kind_ by kind
    @TMignore var title_ by title
    @TMignore var membersJson_ by membersJson
    @TMignore var serverSeq_ by serverSeq
    @TMignore var pulledSeq_ by pulledSeq
    @TMignore var readSeq_ by readSeq
    @TMignore var peerReadSeq_ by peerReadSeq
    @TMignore var updatedAt_ by updatedAt
    @TMignore var draft_ by draft

    companion object {
        val tms by lazy { Tms(Conversation::class) }
    }
}

/** Message déchiffré. `state` : pending | sent | failed | received. */
class ChatMessage : TModel<ChatMessage>() {
    var clientId = TextField().unique()
    var remoteId = TextField().default("")
    var messagingId = TextField().default("")
    var seq = IntField().default(0)       // 0 tant que le serveur n'a pas attribué de seq
    var senderId = IntField().default(0)
    var kind = TextField().default("")
    var body = TextField().default("")
    var state = TextField().default("")
    var createdAt = TextField().default("")
    var expiresAt = TextField().default("")
    var attempts = IntField().default(0)
    var meta = TextField().default("")   // pièce jointe : JSON {id, k, n, name, mime, size, sha256, thumb?, path?}

    @TMignore var clientId_ by clientId
    @TMignore var remoteId_ by remoteId
    @TMignore var messagingId_ by messagingId
    @TMignore var seq_ by seq
    @TMignore var senderId_ by senderId
    @TMignore var kind_ by kind
    @TMignore var body_ by body
    @TMignore var state_ by state
    @TMignore var createdAt_ by createdAt
    @TMignore var expiresAt_ by expiresAt
    @TMignore var attempts_ by attempts
    @TMignore var meta_ by meta

    companion object {
        val tms by lazy { Tms(ChatMessage::class) }
    }
}

/** Paires clé/valeur non secrètes (utilisateur courant, URL serveur, préférences). */
class Setting : TModel<Setting>() {
    var key = TextField().unique()
    var value = TextField().default("")

    @TMignore var key_ by key
    @TMignore var value_ by value

    companion object {
        val tms by lazy { Tms(Setting::class) }
    }
}
