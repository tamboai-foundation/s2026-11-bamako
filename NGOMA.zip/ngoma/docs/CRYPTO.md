# NGOMA Ratchet v2 — spécification

Ce document est la référence normative des deux implémentations jumelles :
- `server/fcrypto/ratchet.py`, en Python, utilisée par les bots côté serveur ;
- `client/src/core/Ratchet.cpp`, en C++, utilisée par le terminal.

Leur interopérabilité est vérifiée octet par octet par `client/tests/test_ratchet.cpp`, qui pilote un pair Python, dans les deux rôles (initiateur et répondeur). Elle est aussi vérifiée de bout en bout via l'assistant IA par `integration_sync`.

Le protocole suit la conception publique de Signal (X3DH et Double Ratchet). **Ce n'est pas libsignal** : voir « Choix et limites ».

## Primitives (libsodium)

| Usage | Primitive |
|---|---|
| Identité d'appareil, signature de la prékey | Ed25519 |
| Échanges Diffie-Hellman | X25519. L'identité Ed25519 est convertie avec `crypto_sign_ed25519_{pk,sk}_to_curve25519` |
| Dérivations | HKDF-SHA256, HMAC-SHA256 |
| Chiffrement des messages | XChaCha20-Poly1305 IETF |

## Clés d'appareil

- `IK` : paire Ed25519 d'identité. La clé publique est le champ `public_key` de l'appareil sur le serveur.
- `SPK` : prékey signée X25519 (`id`, `pk`, `sig`). `sig = Ed25519(IK, "NGM-SPK1" ‖ spk_pk)`. Elle change tous les 7 jours, et la précédente est conservée.
- `OPK` : prékeys à usage unique X25519, par lots de 50. Elles sont réapprovisionnées sous 20 restantes. Le serveur en distribue chacune une seule fois, par réservation atomique (`keys/claim`).

Le serveur vérifie la signature de la SPK à la publication. Un appareil sans SPK publiée n'est pas joignable : il est exclu de la liste des destinataires attendus.

## X3DH

L'initiateur A ouvre une session vers l'appareil B à partir du paquet `{identity_key, spk_id, spk, spk_sig, opk_id?, opk?}` :

```
vérifier sig(SPK_B) avec IK_B
EK = X25519 aléatoire
DH1 = DH(IK_A, SPK_B)   DH2 = DH(EK, IK_B)   DH3 = DH(EK, SPK_B)   [DH4 = DH(EK, OPK_B)]
SK  = HKDF(sel = 0³², ikm = 0xFF³² ‖ DH1 ‖ DH2 ‖ DH3 [‖ DH4], info = "NgomaX3DH", 32)
AD  = IK_A ‖ IK_B            (clés publiques Ed25519)
```

Tant que A n'a reçu aucune réponse, chacun de ses messages est de type `prekey` et transporte `x = {ik, ek, spk, opk}`. Le répondeur peut ainsi établir la session à partir de n'importe lequel de ces messages, même si le premier est perdu.

Le répondeur ne consomme l'OPK qu'**après** un déchiffrement réussi. Une répétition du même `ek` réutilise la session déjà établie.

## Double Ratchet

```
KDF_RK(rk, dh) = HKDF(sel = rk, ikm = dh, info = "NgomaRatchet", 64) → (rk', ck)
KDF_CK(ck)     = (HMAC(ck, 0x02) → ck',  HMAC(ck, 0x01) → mk)
clé, nonce     = HKDF(sel = 0³², ikm = mk, info = "NgomaMsg", 56) → (32 o, 24 o)
en-tête h      = dh_pub (32) ‖ pn (u32 BE) ‖ n (u32 BE)                 = 40 o
chiffré        = XChaCha20-Poly1305(clé, nonce, clair, AD ‖ h)
```

- Initialisation de l'initiateur : `DHs` aléatoire, `DHr = SPK_B`, et `(rk, CKs) = KDF_RK(SK, DH(DHs, DHr))`.
- Initialisation du répondeur : `DHs = SPK_B`, `rk = SK`. Le pas DH se fait au premier message reçu.
- Au plus 1 000 clés sautées par pas, et au plus 2 000 conservées. Un rejeu est refusé, car chaque clé de message est détruite après usage.
- **L'état n'est modifié qu'après une authentification réussie.** Un message falsifié ne corrompt pas la session.

Enveloppe transmise (le serveur ne voit que sa forme) :

```json
{"v": 2, "type": "prekey" | "msg", "h": "<base64 40 o>", "c": "<base64>", "x": {"ik", "ek", "spk", "opk"}}
```

Texte clair : `{"v":1, "t":"text"|"media", "b": "<texte ou légende>", "m": {…pièce jointe…}}`.

## Persistance et reprise (terminal)

- Les sessions sont stockées dans `<data>/sessions/<device_id>.json` (droits 0600, écriture atomique). Les clés d'appareil sont dans `<data>/identity.json`.
- Ordre d'un `pull` :
  1. déchiffrement en mémoire ;
  2. écriture des messages dans `ngoma-store`, idempotente sur `client_id` ;
  3. validation des sessions et des OPK consommées ;
  4. avance du curseur.

  Un plantage entre deux étapes rejoue proprement.
- Épinglage TOFU de l'identité de chaque appareil pair. Un changement d'identité est refusé et signalé ; c'est le numéro de sécurité (empreinte BLAKE2b de l'identité) qui permet de vérifier hors bande.

## Pièces jointes

Le fichier est chiffré en entier par XChaCha20-Poly1305, avec une clé et un nonce aléatoires. Le chiffré est téléversé (`POST media`). `{id, k, n, sha256, name, mime, size, thumb?}` voyage dans l'enveloppe Ratchet du message. À la réception, le terminal vérifie le SHA-256 du clair.

## Appels

La clé d'appel est aléatoire (32 octets) et propre à chaque appel. Elle est envoyée chiffrée par Ratchet à chaque appareil du correspondant, dans la signalisation `invite`. Les médias sont protégés de bout en bout, sans dépendre du relais :
- clé d'émission par appareil : `HKDF(clé d'appel, info = "NGM-media-v1" ‖ device_id)` ;
- chiffrement ChaCha20-Poly1305 IETF ;
- nonce : `kind ‖ 0³ ‖ seq` ;
- données authentifiées (AD) : en-tête de routage, device, seq et kind ;
- fenêtre anti-rejeu de 64 paquets.

## Choix et limites

- **Pas libsignal.** libsignal est sous **AGPL-3.0**, ce qui est incompatible avec un produit embarqué fermé sans publier tout le code, et elle impose une chaîne Rust/FFI. L'implémentation suit les spécifications publiques X3DH et Double Ratchet avec les primitives de libsodium. Elle **doit faire l'objet d'un audit cryptographique externe** avant tout déploiement sensible.
- **Groupes : chiffrement par paires, pas MLS.** Chaque message de groupe est chiffré une fois par appareil destinataire avec sa session Double Ratchet. On obtient la même confidentialité persistante qu'en 1:1, pour un coût en O(n appareils), acceptable jusqu'à quelques centaines de membres (`MAX_GROUP_MEMBERS = 256`). MLS (RFC 9420, OpenMLS) reste l'évolution prévue pour les très grands groupes.
- Pas de PQXDH (post-quantique) en V1.2.
- **Assistant IA** : il est un participant comme un autre. Mais son appareil est **sur le serveur**, et ses messages y sont déchiffrés puis transmis au fournisseur d'IA. L'interface l'indique explicitement à l'activation. Les autres conversations ne sont pas concernées.
