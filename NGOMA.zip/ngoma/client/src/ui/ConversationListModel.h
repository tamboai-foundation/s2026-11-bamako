#pragma once

#include <QAbstractListModel>
#include <QJsonArray>
#include <QJsonObject>

namespace ngoma {

class ConversationListModel : public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(int count READ rowCount NOTIFY countChanged)
    Q_PROPERTY(int unreadTotal READ unreadTotal NOTIFY unreadTotalChanged)
public:
    enum Roles { IdRole = Qt::UserRole + 1, TitleRole, KindRole, UnreadRole, LastBodyRole, LastAtRole, DraftRole, MemberCountRole, IsAssistantRole };

    explicit ConversationListModel(QObject* parent = nullptr);
    void setMyUserId(qint64 id) { m_me = id; }

    int rowCount(const QModelIndex& parent = {}) const override;
    QVariant data(const QModelIndex& index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    void replace(const QJsonArray& items);
    int unreadTotal() const { return m_unread; }
    QJsonObject byId(const QString& id) const;
    Q_INVOKABLE QString titleOf(const QString& id) const;
    /// {kind, isAssistant, memberCount} d'une conversation (en-têtes QML).
    Q_INVOKABLE QVariantMap infoOf(const QString& id) const;

signals:
    void countChanged();
    void unreadTotalChanged();

private:
    QString titleFor(const QJsonObject& c) const;
    QList<QJsonObject> m_items;
    qint64 m_me = 0;
    int m_unread = 0;
};

}  // namespace ngoma
