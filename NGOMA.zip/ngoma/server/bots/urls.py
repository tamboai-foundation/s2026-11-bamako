from django.urls import path

from .views import MyBotView

urlpatterns = [path("bots/me", MyBotView.as_view())]
