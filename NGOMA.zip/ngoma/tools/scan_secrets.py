#!/usr/bin/env python3
"""Contrôle CI : aucun secret dans le dépôt NGOMA.

Échoue (code 1) si l'arborescence contient :
  * un fichier sensible (clés, certificats privés, .env réels, bases de données, identités de terminal) ;
  * une clé privée PEM/OpenSSH, un jeton de fournisseur connu (AWS, GitHub, Slack, Anthropic, OpenAI, Google…) ;
  * une affectation littérale de mot de passe, jeton, clé ou secret ;
  * une chaîne à forte entropie (base64 / hexadécimal ≥ 32 caractères) hors exceptions documentées.
Usage : scan_secrets.py [racine]
"""
import math
import os
import re
import sys

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
SKIP_DIRS = {".git", "build", "__pycache__", ".gradle", "node_modules", ".pytest_cache"}
BINARY = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".zip", ".jar", ".so", ".a", ".o"}
SENSITIVE_FILES = re.compile(r"(^|/)(\.env|server\.env|relay\.env|identity\.json|pg_password\.txt|.*\.(pem|key|p12|pfx|jks|keystore|sqlite3|db))$")

PATTERNS = {
    "clé privée": re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    "jeton AWS": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "jeton GitHub": re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b"),
    "jeton Slack": re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b"),
    "clé Anthropic/OpenAI": re.compile(r"\bsk-(ant-)?[A-Za-z0-9_-]{20,}\b"),
    "clé Google": re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b"),
    "affectation de secret": re.compile(
        r"(?i)\b(password|passwd|secret|token|api_?key|secret_key|bot_key|relay_secret|provisioning_code)\b"
        r"[\"']?\s*[:=]\s*[\"']([^\"'\s$<>{}()]{6,})[\"']"),
}
HIGH_ENTROPY = re.compile(r"(?<![A-Za-z0-9+/=_-])([A-Za-z0-9+/_-]{32,}={0,2})(?![A-Za-z0-9+/=_-])")
# Faux positifs légitimes : valeurs d'exemple explicites dans *.example et documentation.
ALLOWED_VALUES = re.compile(r"(?i)^(remplacer|changeme|example|exemple|x{6,}|\*+)")


def entropy(s: str) -> float:
    counts = {c: s.count(c) for c in set(s)}
    return -sum(n / len(s) * math.log2(n / len(s)) for n in counts.values())


def scan() -> list[str]:
    problems = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith("build")]
        for name in filenames:
            path = os.path.join(dirpath, name)
            rel = os.path.relpath(path, ROOT)
            if SENSITIVE_FILES.search(rel) and not rel.endswith(".example"):
                problems.append(f"{rel} : fichier sensible versionné")
                continue
            if os.path.splitext(name)[1].lower() in BINARY or rel.startswith("client/qml/icons/"):
                continue
            try:
                text = open(path, encoding="utf-8").read()
            except (UnicodeDecodeError, OSError):
                continue
            for lineno, line in enumerate(text.splitlines(), 1):
                for label, rx in PATTERNS.items():
                    for m in rx.finditer(line):
                        value = m.group(m.lastindex) if m.lastindex else m.group(0)
                        if label == "affectation de secret" and ALLOWED_VALUES.match(value):
                            continue
                        problems.append(f"{rel}:{lineno} : {label}")
                for m in HIGH_ENTROPY.finditer(line):
                    tok = m.group(1)
                    is_identifier = re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", tok) and "_" in tok  # ex. crypto_aead_…
                    if entropy(tok) >= 4.3 and not is_identifier and "/" not in tok.strip("/"):
                        problems.append(f"{rel}:{lineno} : chaîne à forte entropie ({tok[:8]}…)")
    return problems


if __name__ == "__main__":
    found = scan()
    for p in found:
        print("✗", p)
    print(f"{len(found)} problème(s) de secret détecté(s) dans {ROOT}")
    sys.exit(1 if found else 0)
