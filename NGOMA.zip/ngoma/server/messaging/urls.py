from django.urls import path

from . import media_views, views

urlpatterns = [
    path("conversations", views.ConversationsView.as_view()),
    path("conversations/<uuid:messaging_id>/devices", views.ConversationDevicesView.as_view()),
    path("conversations/<uuid:messaging_id>/receipts", views.ReceiptsView.as_view()),
    path("sync/state", views.StateView.as_view()),
    path("sync/push", views.PushView.as_view()),
    path("sync/pull", views.PullView.as_view()),
    path("sync/ack", views.AckView.as_view()),
    path("media", media_views.MediaUploadView.as_view()),
    path("media/<uuid:media_id>", media_views.MediaDownloadView.as_view()),
    path("calls/token", media_views.CallTokenView.as_view()),
]
