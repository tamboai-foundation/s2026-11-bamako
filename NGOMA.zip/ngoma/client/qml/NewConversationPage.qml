import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Ngoma.Core

Page {
    id: page
    background: Rectangle { color: Theme.background }
    property var results: []
    property var selected: ({})
    property bool groupMode: false
    readonly property int selectedCount: Object.keys(selected).length

    header: PageHeader {
        showBack: true
        title: groupMode ? qsTr("Nouveau groupe") : qsTr("Nouvelle conversation")
        onBack: page.StackView.view.pop()
    }

    Connections { target: App; function onUsersFound(users) { page.results = users } }

    ColumnLayout {
        anchors.fill: parent; anchors.margins: 20; spacing: Theme.spacing

        // Choix du type : segmenté, lisible au doigt
        Rectangle {
            Layout.fillWidth: true; height: 48; radius: Theme.radiusSmall; color: Theme.surface; border.color: Theme.outline
            RowLayout {
                anchors.fill: parent; anchors.margins: 4; spacing: 4
                Repeater {
                    model: [{ label: qsTr("Conversation directe"), group: false }, { label: qsTr("Groupe"), group: true }]
                    delegate: AbstractButton {
                        Layout.fillWidth: true; Layout.fillHeight: true
                        onClicked: { page.groupMode = modelData.group; page.selected = ({}) }
                        background: Rectangle { radius: Theme.radiusSmall - 2; color: page.groupMode === modelData.group ? Theme.accent : "transparent" }
                        contentItem: Text { text: modelData.label; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
                                            color: page.groupMode === modelData.group ? Theme.accentText : Theme.text; font.pixelSize: Theme.fontSmall + 1; font.weight: Font.DemiBold }
                    }
                }
            }
        }

        AppTextField { id: groupTitle; visible: groupMode; Layout.fillWidth: true; placeholderText: qsTr("Nom du groupe") }
        AppTextField {
            id: query; Layout.fillWidth: true
            placeholderText: qsTr("Rechercher un identifiant (2 lettres min.)")
            inputMethodHints: Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText
            leftPadding: 48
            onTextChanged: debounce.restart()
            Image { anchors.left: parent.left; anchors.leftMargin: 14; anchors.verticalCenter: parent.verticalCenter; source: Theme.icon("search", "muted"); sourceSize: Qt.size(20, 20) }
            Timer { id: debounce; interval: 300; onTriggered: if (query.text.length >= 2) App.searchUsers(query.text); else page.results = [] }
        }

        ListView {
            Layout.fillWidth: true; Layout.fillHeight: true; clip: true; spacing: 2
            model: page.results
            delegate: ItemDelegate {
                id: item
                width: ListView.view.width; height: 68
                hoverEnabled: true
                readonly property bool isSelected: page.selected[modelData.id] === true
                background: Rectangle { radius: Theme.radiusSmall; color: item.isSelected ? Theme.accentSoft : (item.down ? Theme.surfacePressed : (item.hovered ? Theme.surface : "transparent")) }
                contentItem: RowLayout {
                    spacing: 14
                    Avatar { name: modelData.display_name || modelData.username; size: 44 }
                    ColumnLayout {
                        Layout.fillWidth: true; spacing: 0
                        Text { Layout.fillWidth: true; text: modelData.display_name || modelData.username; color: Theme.text; font.pixelSize: Theme.fontBody }
                        Text { Layout.fillWidth: true; text: "@" + modelData.username; color: Theme.textMuted; font.pixelSize: Theme.fontSmall }
                    }
                    Rectangle {
                        visible: groupMode; width: 26; height: 26; radius: 13
                        color: item.isSelected ? Theme.accent : "transparent"; border.width: 2; border.color: item.isSelected ? Theme.accent : Theme.outlineStrong
                        Image { anchors.centerIn: parent; visible: item.isSelected; source: Theme.icon("check", "dark"); sourceSize: Qt.size(16, 16) }
                    }
                }
                onClicked: {
                    if (!groupMode) { App.createDirect(modelData.id); return }
                    const s = Object.assign({}, page.selected)
                    if (s[modelData.id]) delete s[modelData.id]; else s[modelData.id] = true
                    page.selected = s
                }
            }
            Text {
                anchors.centerIn: parent
                visible: parent.count === 0
                text: query.text.length >= 2 ? qsTr("Aucun résultat") : qsTr("Tapez au moins deux lettres d'un identifiant.")
                color: Theme.textMuted; font.pixelSize: Theme.fontSmall + 1
            }
        }
        AppButton {
            visible: groupMode; Layout.fillWidth: true; variant: "primary"; iconName: "group"
            enabled: selectedCount > 0 && groupTitle.text.trim().length > 0 && !App.busy
            text: qsTr("Créer le groupe (%1)").arg(selectedCount)
            onClicked: App.createGroup(groupTitle.text, Object.keys(page.selected).map(Number))
        }
    }
}
