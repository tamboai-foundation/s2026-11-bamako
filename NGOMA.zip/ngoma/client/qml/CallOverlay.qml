import QtQuick
import QtQuick.Layouts
import Ngoma
import Ngoma.Core

Rectangle {
    id: overlay
    visible: App.callState !== "idle"
    color: "#f20b0f13"

    MouseArea { anchors.fill: parent }  // bloque les interactions derrière l'appel

    VideoItem {
        id: remote
        source: VideoItem.Remote
        anchors.fill: parent
        visible: App.callState === "active" && hasFrame
    }

    // Vignette caméra locale
    Rectangle {
        anchors.right: parent.right; anchors.top: parent.top; anchors.margins: 20
        width: 240; height: 180; radius: Theme.radius; color: "black"; clip: true
        visible: App.callState === "active" || App.callState === "outgoing"
        border.color: Theme.outlineStrong; border.width: 2
        VideoItem { anchors.fill: parent; anchors.margins: 2; source: VideoItem.Local }
        Text { anchors.centerIn: parent; visible: !App.mediaAvailable; text: qsTr("Caméra indisponible"); color: Theme.textMuted; font.pixelSize: Theme.fontSmall }
        Rectangle {
            anchors.left: parent.left; anchors.bottom: parent.bottom; anchors.margins: 8
            width: lbl.implicitWidth + 16; height: 24; radius: 12; color: "#99000000"
            Text { id: lbl; anchors.centerIn: parent; text: qsTr("Vous"); color: "white"; font.pixelSize: 12 }
        }
    }

    ColumnLayout {
        anchors.centerIn: parent
        anchors.verticalCenterOffset: -40
        spacing: 14
        visible: !remote.visible
        Avatar { Layout.alignment: Qt.AlignHCenter; name: App.callPeer; size: 112 }
        Text { Layout.alignment: Qt.AlignHCenter; text: App.callPeer; color: Theme.text; font.pixelSize: 34; font.weight: Font.DemiBold }
        RowLayout {
            Layout.alignment: Qt.AlignHCenter; spacing: 8
            Image { source: Theme.icon("lock", "accent"); sourceSize: Qt.size(16, 16) }
            Text {
                color: Theme.textMuted; font.pixelSize: Theme.fontBody
                text: App.callState === "incoming" ? qsTr("Appel entrant chiffré…")
                     : App.callState === "outgoing" ? qsTr("Appel chiffré en cours…") : qsTr("En communication")
            }
        }
    }

    RowLayout {
        anchors.bottom: parent.bottom; anchors.horizontalCenter: parent.horizontalCenter; anchors.bottomMargin: 40
        spacing: 40
        ColumnLayout {
            visible: App.callState === "active"; spacing: 6
            IconButton {
                Layout.alignment: Qt.AlignHCenter
                implicitWidth: 72; implicitHeight: 72; round: true; iconSize: 30
                iconName: App.muted ? "mic-off" : "mic"; variant: App.muted ? "danger" : "filled"
                onClicked: App.toggleMute()
            }
            Rectangle {
                Layout.alignment: Qt.AlignHCenter; width: 72; height: 4; radius: 2; color: Theme.surfaceHigh
                Rectangle { width: parent.width * Math.min(1, App.micLevel * 4); height: parent.height; radius: 2; color: Theme.accent }
            }
        }
        IconButton {
            visible: App.callState === "incoming"
            implicitWidth: 84; implicitHeight: 84; round: true; iconSize: 34
            iconName: "phone"; variant: "primary"; tip: qsTr("Décrocher")
            onClicked: App.acceptCall()
        }
        IconButton {
            implicitWidth: 84; implicitHeight: 84; round: true; iconSize: 34
            iconName: "hangup"; variant: "danger"; tip: qsTr("Raccrocher")
            onClicked: App.hangup()
        }
    }
}
