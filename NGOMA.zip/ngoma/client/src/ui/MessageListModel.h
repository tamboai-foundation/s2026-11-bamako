#pragma once

#include <QAbstractListModel>
#include <QHash>
#include <QJsonArray>
#include <QJsonObject>

namespace ngoma {

/// Messages de la conversation ouverte, en ordre chronologique. Les mises à jour sont incrémentales :
/// ajout en fin (nouveaux messages), insertion en tête (historique), mise à jour en place (états).
class MessageListModel : public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(int count READ rowCount NOTIFY countChanged)
public:
    enum Roles {
        ClientIdRole = Qt::UserRole + 1, SeqRole, BodyRole, MineRole, StateRole, TimeRole, SenderRole, ReadRole, DayRole,
        KindRole, FileNameRole, FileSizeRole, ThumbRole, LocalPathRole, IsImageRole
    };

    explicit MessageListModel(QObject* parent = nullptr);

    void setContext(qint64 myUserId, const QHash<qint64, QString>& names) {
        m_me = myUserId;
        m_names = names;
    }
    void setPeerReadSeq(qint64 seq);

    int rowCount(const QModelIndex& parent = {}) const override;
    QVariant data(const QModelIndex& index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    void clear();
    void mergeLatest(const QJsonArray& items);  // page la plus récente (+ messages en attente)
    void prependOlder(const QJsonArray& items);
    qint64 oldestSeq() const;
    QJsonObject metaOf(const QString& clientId) const;
    qint64 newestSeq() const;

signals:
    void countChanged();

private:
    QList<QJsonObject> m_items;
    QHash<qint64, QString> m_names;
    qint64 m_me = 0;
    qint64 m_peerRead = 0;
};

}  // namespace ngoma
