#pragma once

#include <QString>
#include <QUrl>

namespace ngoma {

/// Configuration du terminal, lue depuis /etc/ngoma/client.conf (format INI, section [ngoma])
/// ou depuis le fichier indiqué par NGOMA_CONFIG. Les variables d'environnement NGOMA_* priment.
struct Config {
    QUrl serverUrl{QStringLiteral("https://ngoma.example.org")};
    QString dataDir{QStringLiteral("/var/lib/ngoma")};
    QString storeSocket{QStringLiteral("/run/ngoma/store.sock")};
    QString caFile;            // AC privée à épingler (recommandé en production)
    QString clientCertFile;    // mTLS terminal (optionnel)
    QString clientKeyFile;
    QString deviceName{QStringLiteral("Terminal Ngoma")};
    bool allowInsecure = false;  // http/ws en clair : développement uniquement

    static Config load();
    QUrl apiUrl(const QString& path) const;
    QUrl realtimeUrl() const;
};

}  // namespace ngoma
