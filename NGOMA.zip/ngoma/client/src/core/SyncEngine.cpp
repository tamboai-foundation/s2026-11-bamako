#include "SyncEngine.h"

#include <QDebug>
#include <QJsonDocument>
#include <QUrlQuery>
#include <algorithm>

#include "ApiClient.h"
#include "Ratchet.h"
#include "RealtimeClient.h"
#include "StoreClient.h"
#include "Uuid7.h"

namespace ngoma {

namespace {
constexpr int kDeviceCacheSec = 120;
constexpr int kPullPage = 100;
constexpr int kOpkLow = 20;
constexpr int kOpkBatch = 50;
constexpr qint64 kSpkMaxAgeSec = 7 * 24 * 3600;
const QString kPinsKey = QStringLiteral("key_pins");

QString nowIsoUtc() { return QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs); }
QString s(const QJsonObject& o, const char* k) { return o.value(QLatin1String(k)).toString(); }
qint64 n(const QJsonObject& o, const char* k) { return o.value(QLatin1String(k)).toInteger(); }
QString b64(const QByteArray& b) { return QString::fromLatin1(b.toBase64()); }
}  // namespace

SyncEngine::SyncEngine(ApiClient& api, RealtimeClient& rt, StoreClient& store, SecretStore& secrets, QObject* parent)
    : QObject(parent), m_api(api), m_rt(rt), m_store(store), m_secrets(secrets) {
    m_outboxRetry.setSingleShot(true);
    connect(&m_outboxRetry, &QTimer::timeout, this, &SyncEngine::flushOutbox);
    m_purge.setInterval(30000);
    connect(&m_purge, &QTimer::timeout, this, [this] {
        m_store.call(QStringLiteral("msg.purgeExpired"), {{QStringLiteral("now"), nowIsoUtc()}});
    });
    // Filet de sécurité : un signal temps réel perdu (coupure, redémarrage d'un nœud) ne bloque jamais un message.
    m_safetySync.setInterval(qEnvironmentVariableIntValue("NGOMA_SAFETY_SYNC_MS") > 0
                                 ? qEnvironmentVariableIntValue("NGOMA_SAFETY_SYNC_MS") : 60000);
    connect(&m_safetySync, &QTimer::timeout, this, [this] { if (m_online) fullSync(); });
    m_prekeyCheck.setInterval(3600 * 1000);
    connect(&m_prekeyCheck, &QTimer::timeout, this, &SyncEngine::ensurePrekeys);
    connect(&m_rt, &RealtimeClient::eventReceived, this, &SyncEngine::onEvent);
    connect(&m_rt, &RealtimeClient::connectedChanged, this, [this](bool c) {
        m_online = c;
        emit onlineChanged(c);
    });
}

void SyncEngine::start(const Identity& identity) {
    m_id = identity;
    m_running = true;
    m_store.call(QStringLiteral("setting.get"), {{QStringLiteral("key"), kPinsKey}},
                 [this](bool ok, const QJsonValue& v, const QString&) {
                     if (!ok || !v.isString()) return;
                     const auto o = QJsonDocument::fromJson(v.toString().toUtf8()).object();
                     for (auto it = o.begin(); it != o.end(); ++it) m_pins.insert(it.key(), it.value().toString());
                 });
    loadCursors({});
    m_purge.start();
    m_prekeyCheck.start();
    m_safetySync.start();
    ensurePrekeys();
    m_rt.start(identity.token);
}

void SyncEngine::stop() {
    m_running = false;
    m_rt.stop();
    m_purge.stop();
    m_prekeyCheck.stop();
    m_safetySync.stop();
    m_outboxRetry.stop();
    m_sendQueue.clear();
    m_flushing = false;
    m_pulled.clear();
    m_devices.clear();
    m_pins.clear();
    m_id = {};
}

void SyncEngine::saveIdentity() {
    if (!m_secrets.save(m_id)) emit errorOccurred(tr("Écriture des clés de l'appareil impossible."));
}

// ------------------------------------------------------------------ prékeys

void SyncEngine::ensurePrekeys() {
    if (!m_running) return;
    m_api.get(QStringLiteral("keys/prekeys"), [this](const ApiReply& r) {
        if (!r.ok() || !m_running) return;
        const auto o = r.body.object();
        const bool noSpk = o.value(QStringLiteral("spk_id")).isNull();
        const int count = int(n(o, "opk_count"));
        const bool oldSpk = QDateTime::currentSecsSinceEpoch() - m_id.keys.signedPrekeyCreatedAt() > kSpkMaxAgeSec;
        if (!noSpk && !oldSpk && count >= kOpkLow) return;
        if (oldSpk) m_id.keys.rotateSignedPrekey();
        const QJsonArray opks = m_id.keys.newOneTimePrekeys(std::max(0, kOpkBatch - count));
        saveIdentity();  // les secrets sont sur disque AVANT que les clés publiques ne soient distribuées
        m_api.post(QStringLiteral("keys/prekeys"), QJsonDocument(m_id.keys.publicUpload(opks)), [this](const ApiReply& rr) {
            if (rr.ok()) {
                m_prekeyAttempt = 0;
                return;
            }
            // Sans prékeys publiées l'appareil est injoignable : nouvel essai rapide avec attente croissante.
            const int delay = std::min(300000, 2000 * (1 << std::min(m_prekeyAttempt++, 7)));
            QTimer::singleShot(delay, this, &SyncEngine::ensurePrekeys);
            if (rr.status >= 400 && rr.status < 500) emit errorOccurred(tr("Publication des prékeys refusée (%1).").arg(rr.status));
        });
    });
}

// ------------------------------------------------------------------ événements temps réel

void SyncEngine::onEvent(const QJsonObject& evt) {
    const QString e = s(evt, "event");
    const QString mid = s(evt, "messaging_id");
    if (e == QLatin1String("hello")) {
        ensurePrekeys();
        fullSync();
    } else if (e == QLatin1String("message")) {
        pull(mid);
    } else if (e == QLatin1String("conversation")) {
        m_devices.remove(mid);
        refreshConversations([this, mid] { pull(mid); });
    } else if (e == QLatin1String("receipt")) {
        if (n(evt, "user_id") != m_id.userId)
            m_store.call(QStringLiteral("conv.setPeerRead"),
                         {{QStringLiteral("id"), mid}, {QStringLiteral("seq"), n(evt, "read_seq")}});
    } else if (e == QLatin1String("typing")) {
        emit typing(mid, n(evt, "user_id"));
    } else if (e == QLatin1String("call.signal")) {
        emit callSignal(evt);
    }
}

// ------------------------------------------------------------------ pull

void SyncEngine::loadCursors(std::function<void()> done) {
    m_store.call(QStringLiteral("conv.list"), {}, [this, done](bool ok, const QJsonValue& v, const QString&) {
        if (ok)
            for (const auto& c : v.toArray()) {
                const auto o = c.toObject();
                m_pulled.insert(s(o, "id"), n(o, "pulled_seq"));
            }
        if (done) done();
    });
}

void SyncEngine::refreshConversations(std::function<void()> done) {
    m_api.get(QStringLiteral("conversations"), [this, done](const ApiReply& r) {
        if (!r.ok()) {
            if (done) done();
            return;
        }
        m_store.call(QStringLiteral("conv.upsert"), {{QStringLiteral("items"), r.body.array()}},
                     [this, done](bool, const QJsonValue&, const QString&) { loadCursors(done); });
    });
}

void SyncEngine::fullSync() {
    if (!m_running) return;
    emit syncingChanged(true);
    refreshConversations([this] {
        m_api.get(QStringLiteral("sync/state"), [this](const ApiReply& r) {
            emit syncingChanged(false);
            if (!r.ok()) return;
            for (const auto& c : r.body.object().value(QStringLiteral("conversations")).toArray()) {
                const auto o = c.toObject();
                const QString mid = s(o, "messaging_id");
                m_store.call(QStringLiteral("conv.setServerSeq"),
                             {{QStringLiteral("id"), mid}, {QStringLiteral("seq"), n(o, "last_seq")}});
                if (n(o, "last_seq") > m_pulled.value(mid, 0)) pull(mid);
            }
            flushOutbox();
        });
    });
}

void SyncEngine::pull(const QString& messagingId) {
    if (!m_running || messagingId.isEmpty()) return;
    if (m_pulling.contains(messagingId)) {
        m_pullAgain.insert(messagingId);
        return;
    }
    m_pulling.insert(messagingId);
    const qint64 after = m_pulled.value(messagingId, 0);
    QUrlQuery q;
    q.addQueryItem(QStringLiteral("messaging_id"), messagingId);
    q.addQueryItem(QStringLiteral("after_seq"), QString::number(after));
    q.addQueryItem(QStringLiteral("limit"), QString::number(kPullPage));
    m_api.get(QStringLiteral("sync/pull?") + q.toString(QUrl::FullyEncoded), [this, messagingId, after](const ApiReply& r) {
        auto abort = [this, messagingId] {
            m_pulling.remove(messagingId);
            m_pullAgain.remove(messagingId);
        };
        if (!r.ok()) {
            if (r.status == 404) refreshConversations();
            abort();
            return;
        }
        const auto body = r.body.object();
        const auto items = body.value(QStringLiteral("items")).toArray();
        PendingCommit commit;
        QJsonArray decoded;
        qint64 maxSeq = after;
        int fromOthers = 0;
        for (const auto& it : items) {
            bool other = false;
            decoded.append(decryptItem(it.toObject(), other, commit));
            maxSeq = std::max(maxSeq, n(it.toObject(), "seq"));
            if (other) ++fromOthers;
        }
        const bool hasMore = body.value(QStringLiteral("has_more")).toBool();
        if (!hasMore) maxSeq = std::max(maxSeq, n(body, "last_seq"));
        const qint64 newCursor = maxSeq;

        auto commitCursor = [this, messagingId, newCursor, fromOthers, hasMore, commit, abort] {
            applyCommit(commit);  // 2) sessions et prékeys consommées validées APRÈS l'écriture des messages
            m_store.call(QStringLiteral("conv.setPulled"),
                         {{QStringLiteral("id"), messagingId}, {QStringLiteral("seq"), newCursor},
                          {QStringLiteral("updated_at"), nowIsoUtc()}},
                         [this, messagingId, newCursor, fromOthers, hasMore, abort](bool ok, const QJsonValue&, const QString&) {
                             if (!ok) {
                                 abort();
                                 return;
                             }
                             m_pulled.insert(messagingId, newCursor);
                             if (fromOthers > 0) {
                                 emit incoming(messagingId, fromOthers);
                                 m_api.post(QStringLiteral("sync/ack"),
                                            QJsonDocument(QJsonObject{{QStringLiteral("messaging_id"), messagingId},
                                                                      {QStringLiteral("delivered_seq"), newCursor}}),
                                            {});
                             }
                             m_pulling.remove(messagingId);
                             if (hasMore || m_pullAgain.remove(messagingId)) pull(messagingId);
                         });
        };
        if (decoded.isEmpty()) {
            commitCursor();
            return;
        }
        // 1) messages déchiffrés écrits dans le stockage local (idempotent sur client_id)
        m_store.call(QStringLiteral("msg.upsertReceived"),
                     {{QStringLiteral("messaging_id"), messagingId}, {QStringLiteral("items"), decoded},
                      {QStringLiteral("my_user_id"), m_id.userId}},
                     [commitCursor, abort](bool ok, const QJsonValue&, const QString& err) {
                         if (!ok) {
                             qWarning() << "ngoma-store : écriture des messages reçus impossible :" << err;
                             abort();
                             return;
                         }
                         commitCursor();
                     });
    });
}

void SyncEngine::applyCommit(const PendingCommit& commit) {
    for (auto it = commit.sessions.cbegin(); it != commit.sessions.cend(); ++it)
        if (!m_secrets.saveSession(it.key(), it.value())) qWarning() << "session non enregistrée pour" << it.key();
    if (!commit.consumedPrekeys.isEmpty()) {
        for (int id : commit.consumedPrekeys) m_id.keys.dropOneTimePrekey(id);
        saveIdentity();
        if (m_id.keys.oneTimePrekeyCount() < kOpkLow) ensurePrekeys();
    }
}

QJsonObject SyncEngine::decryptItem(const QJsonObject& item, bool& fromOther, PendingCommit& commit) {
    const qint64 sender = n(item, "sender_id");
    fromOther = sender != m_id.userId;
    QJsonObject out{
        {QStringLiteral("client_id"), s(item, "client_id")},
        {QStringLiteral("remote_id"), s(item, "id")},
        {QStringLiteral("seq"), n(item, "seq")},
        {QStringLiteral("sender_id"), sender},
        {QStringLiteral("kind"), s(item, "kind")},
        {QStringLiteral("created_at"), s(item, "created_at")},
        {QStringLiteral("expires_at"), item.value(QStringLiteral("expires_at")).toString()},
        {QStringLiteral("meta"), QString()},
    };
    if (s(item, "kind") == QLatin1String("system")) {
        out.insert(QStringLiteral("body"), s(item, "system_text"));
        return out;
    }
    const auto env = item.value(QStringLiteral("envelope")).toObject();
    const QString senderDevice = s(item, "sender_device_id");
    if (env.isEmpty()) {
        out.insert(QStringLiteral("body"), fromOther ? tr("[Message non disponible sur cet appareil]") : QString());
        return out;
    }
    // Session la plus récente : celle d'un message précédent du même lot, sinon celle du disque.
    QJsonObject session = commit.sessions.value(senderDevice);
    if (session.isEmpty()) session = m_secrets.loadSession(senderDevice).value_or(QJsonObject{});
    ratchet::DeviceKeys keys = m_id.keys;
    for (int id : commit.consumedPrekeys) keys.dropOneTimePrekey(id);
    QString err;
    const auto d = ratchet::decrypt(keys, session, env, &err);
    if (!d) {
        qWarning() << "déchiffrement impossible du seq" << n(item, "seq") << ":" << err;
        out.insert(QStringLiteral("body"), tr("[Message illisible : %1]").arg(err));
        return out;
    }
    if (!checkPin(senderDevice, ratchet::peerIdentity(d->session), sender)) {
        out.insert(QStringLiteral("body"), tr("[Identité de l'appareil expéditeur modifiée — message rejeté]"));
        return out;
    }
    commit.sessions.insert(senderDevice, d->session);
    if (d->consumedOneTimePrekey) commit.consumedPrekeys.append(d->oneTimePrekeyId);
    const auto o = QJsonDocument::fromJson(d->plaintext).object();
    out.insert(QStringLiteral("body"), o.value(QStringLiteral("b")).toString());
    if (o.value(QStringLiteral("t")).toString() == QLatin1String("media")) {
        out.insert(QStringLiteral("kind"), QStringLiteral("media"));
        out.insert(QStringLiteral("meta"),
                   QString::fromUtf8(QJsonDocument(o.value(QStringLiteral("m")).toObject()).toJson(QJsonDocument::Compact)));
    }
    return out;
}

bool SyncEngine::checkPin(const QString& deviceId, const QByteArray& identity, qint64 userId) {
    if (deviceId.isEmpty() || identity.size() != 32) return false;
    const QString key = b64(identity);
    const auto it = m_pins.constFind(deviceId);
    if (it == m_pins.constEnd()) {
        m_pins.insert(deviceId, key);  // première rencontre : épinglage (TOFU)
        savePins();
        return true;
    }
    if (*it == key) return true;
    emit keyChanged(deviceId, userId);
    return false;
}

void SyncEngine::savePins() {
    QJsonObject o;
    for (auto it = m_pins.cbegin(); it != m_pins.cend(); ++it) o.insert(it.key(), it.value());
    m_store.call(QStringLiteral("setting.set"),
                 {{QStringLiteral("key"), kPinsKey},
                  {QStringLiteral("value"), QString::fromUtf8(QJsonDocument(o).toJson(QJsonDocument::Compact))}});
}

// ------------------------------------------------------------------ chiffrement vers des appareils

void SyncEngine::devicesFor(const QString& messagingId, bool force,
                            std::function<void(bool, const QList<DeviceKey>&)> cb) {
    const auto it = m_devices.constFind(messagingId);
    if (!force && it != m_devices.constEnd() && it->fetched.secsTo(QDateTime::currentDateTimeUtc()) < kDeviceCacheSec) {
        cb(true, it->devices);
        return;
    }
    m_api.get(QStringLiteral("conversations/%1/devices").arg(messagingId), [this, messagingId, cb](const ApiReply& r) {
        if (!r.ok()) {
            cb(false, {});
            return;
        }
        DeviceCache c;
        c.fetched = QDateTime::currentDateTimeUtc();
        for (const auto& d : r.body.array()) {
            const auto o = d.toObject();
            DeviceKey k{s(o, "device_id"), n(o, "user_id"), QByteArray::fromBase64(s(o, "public_key").toLatin1())};
            if (k.id == m_id.deviceId) continue;
            if (!checkPin(k.id, k.identity, k.userId)) continue;  // identité substituée : appareil exclu
            c.devices.append(k);
        }
        m_devices.insert(messagingId, c);
        cb(true, c.devices);
    });
}

void SyncEngine::encryptToDevices(const QList<DeviceKey>& devices, const QByteArray& plaintext,
                                  std::function<void(bool, const QJsonArray&)> cb) {
    QStringList missing;
    for (const auto& d : devices)
        if (!m_secrets.loadSession(d.id)) missing << d.id;
    auto finish = [this, devices, plaintext, cb](const QJsonObject& bundles) {
        QJsonArray envelopes;
        for (const auto& d : devices) {
            QJsonObject session = m_secrets.loadSession(d.id).value_or(QJsonObject{});
            if (session.isEmpty()) {
                const auto b = bundles.value(d.id).toObject();
                if (b.isEmpty() || QByteArray::fromBase64(b.value(QStringLiteral("identity_key")).toString().toLatin1()) != d.identity) {
                    cb(false, {});  // appareil non joignable (pas de prékey) ou paquet incohérent
                    return;
                }
                QString err;
                auto init = ratchet::initiate(m_id.keys, b, &err);
                if (!init) {
                    emit errorOccurred(tr("Paquet de prékeys refusé : %1").arg(err));
                    cb(false, {});
                    return;
                }
                session = *init;
            }
            const auto env = ratchet::encrypt(session, plaintext);
            if (!env || !m_secrets.saveSession(d.id, session)) {
                cb(false, {});
                return;
            }
            envelopes.append(QJsonObject{{QStringLiteral("device_id"), d.id}, {QStringLiteral("payload"), *env}});
        }
        cb(true, envelopes);
    };
    if (missing.isEmpty()) {
        finish({});
        return;
    }
    m_api.post(QStringLiteral("keys/claim"),
               QJsonDocument(QJsonObject{{QStringLiteral("device_ids"), QJsonArray::fromStringList(missing)}}),
               [finish, cb](const ApiReply& r) {
                   if (!r.ok()) {
                       cb(false, {});
                       return;
                   }
                   finish(r.body.object());
               });
}

void SyncEngine::encryptForUser(const QString& messagingId, qint64 userId, const QByteArray& plaintext,
                                std::function<void(bool, const QJsonObject&)> cb) {
    devicesFor(messagingId, false, [this, userId, plaintext, cb](bool ok, const QList<DeviceKey>& all) {
        if (!ok) {
            cb(false, {});
            return;
        }
        QList<DeviceKey> mine;
        for (const auto& d : all)
            if (d.userId == userId) mine.append(d);
        encryptToDevices(mine, plaintext, [cb](bool ok2, const QJsonArray& envs) {
            QJsonObject byDevice;
            for (const auto& e : envs) byDevice.insert(e.toObject().value(QStringLiteral("device_id")).toString(),
                                                       e.toObject().value(QStringLiteral("payload")));
            cb(ok2, byDevice);
        });
    });
}

std::optional<QByteArray> SyncEngine::decryptFromDevice(const QString& deviceId, const QJsonObject& envelope) {
    const QJsonObject session = m_secrets.loadSession(deviceId).value_or(QJsonObject{});
    const auto d = ratchet::decrypt(m_id.keys, session, envelope);
    if (!d || !checkPin(deviceId, ratchet::peerIdentity(d->session), 0)) return std::nullopt;
    PendingCommit c;
    c.sessions.insert(deviceId, d->session);
    if (d->consumedOneTimePrekey) c.consumedPrekeys.append(d->oneTimePrekeyId);
    applyCommit(c);
    return d->plaintext;
}

// ------------------------------------------------------------------ envoi

void SyncEngine::queueOutgoing(const QJsonObject& rec) {
    m_store.call(QStringLiteral("msg.insertOutgoing"), rec, [this](bool ok, const QJsonValue&, const QString& err) {
        if (!ok) {
            emit errorOccurred(tr("Enregistrement local impossible : %1").arg(err));
            return;
        }
        flushOutbox();
    });
}

void SyncEngine::sendText(const QString& messagingId, const QString& text, int expiresInSec) {
    const QString body = text.trimmed();
    if (body.isEmpty() || messagingId.isEmpty() || !m_running) return;
    const auto now = QDateTime::currentDateTimeUtc();
    queueOutgoing({{QStringLiteral("client_id"), uuid7()},
                   {QStringLiteral("messaging_id"), messagingId},
                   {QStringLiteral("sender_id"), m_id.userId},
                   {QStringLiteral("kind"), QStringLiteral("text")},
                   {QStringLiteral("body"), body},
                   {QStringLiteral("meta"), QString()},
                   {QStringLiteral("created_at"), now.toString(Qt::ISODateWithMs)},
                   {QStringLiteral("expires_at"),
                    expiresInSec > 0 ? now.addSecs(expiresInSec).toString(Qt::ISODateWithMs) : QString()}});
}

void SyncEngine::sendMedia(const QString& messagingId, const QString& caption, const QJsonObject& meta) {
    if (messagingId.isEmpty() || !m_running) return;
    queueOutgoing({{QStringLiteral("client_id"), uuid7()},
                   {QStringLiteral("messaging_id"), messagingId},
                   {QStringLiteral("sender_id"), m_id.userId},
                   {QStringLiteral("kind"), QStringLiteral("media")},
                   {QStringLiteral("body"), caption.trimmed()},
                   {QStringLiteral("meta"), QString::fromUtf8(QJsonDocument(meta).toJson(QJsonDocument::Compact))},
                   {QStringLiteral("created_at"), nowIsoUtc()},
                   {QStringLiteral("expires_at"), QString()}});
}

void SyncEngine::retryFailed() { flushOutbox(); }

void SyncEngine::flushOutbox() {
    if (!m_running || !m_online || m_flushing) return;
    m_flushing = true;
    m_store.call(QStringLiteral("msg.pending"), {{QStringLiteral("limit"), 50}},
                 [this](bool ok, const QJsonValue& v, const QString&) {
                     m_sendQueue.clear();
                     if (ok)
                         for (const auto& m : v.toArray()) m_sendQueue.append(m.toObject());
                     sendNext();
                 });
}

void SyncEngine::sendNext() {
    if (m_sendQueue.isEmpty()) {
        m_flushing = false;
        m_outboxAttempt = 0;
        return;
    }
    sendOne(m_sendQueue.takeFirst(), 0);
}

void SyncEngine::scheduleOutboxRetry() {
    m_flushing = false;
    m_sendQueue.clear();
    const int delay = std::min(30000, 1000 * (1 << std::min(m_outboxAttempt++, 5)));
    m_outboxRetry.start(delay);
}

void SyncEngine::sendOne(const QJsonObject& msg, int attempt) {
    const QString mid = s(msg, "messaging_id");
    const QString cid = s(msg, "client_id");
    devicesFor(mid, attempt > 0, [this, msg, attempt, mid, cid](bool ok, const QList<DeviceKey>& devices) {
        if (!ok) {
            scheduleOutboxRetry();
            return;
        }
        const bool media = s(msg, "kind") == QLatin1String("media");
        QJsonObject pt{{QStringLiteral("v"), 1}, {QStringLiteral("t"), media ? QStringLiteral("media") : QStringLiteral("text")},
                       {QStringLiteral("b"), s(msg, "body")}};
        if (media) {
            QJsonObject meta = QJsonDocument::fromJson(s(msg, "meta").toUtf8()).object();
            meta.remove(QStringLiteral("path"));  // le chemin local de l'expéditeur ne quitte pas l'appareil
            pt.insert(QStringLiteral("m"), meta);
        }
        encryptToDevices(devices, QJsonDocument(pt).toJson(QJsonDocument::Compact),
                         [this, msg, attempt, mid, cid, media](bool encOk, const QJsonArray& envelopes) {
            if (!encOk) {
                m_devices.remove(mid);
                scheduleOutboxRetry();
                return;
            }
            QJsonObject req{{QStringLiteral("messaging_id"), mid}, {QStringLiteral("client_id"), cid},
                            {QStringLiteral("kind"), media ? QStringLiteral("media") : QStringLiteral("text")},
                            {QStringLiteral("envelopes"), envelopes}};
            const QString exp = s(msg, "expires_at");
            if (!exp.isEmpty()) {
                const auto created = QDateTime::fromString(s(msg, "created_at"), Qt::ISODateWithMs);
                const auto expires = QDateTime::fromString(exp, Qt::ISODateWithMs);
                req.insert(QStringLiteral("expires_in"), std::max<qint64>(5, created.secsTo(expires)));
            }
            m_api.post(QStringLiteral("sync/push"), QJsonDocument(req), [this, msg, attempt, mid, cid](const ApiReply& r) {
                if (r.ok()) {
                    const auto b = r.body.object();
                    m_store.call(QStringLiteral("msg.markSent"),
                                 {{QStringLiteral("client_id"), cid}, {QStringLiteral("messaging_id"), mid},
                                  {QStringLiteral("seq"), n(b, "seq")}, {QStringLiteral("remote_id"), s(b, "id")},
                                  {QStringLiteral("created_at"), s(b, "created_at")}},
                                 [this](bool, const QJsonValue&, const QString&) { sendNext(); });
                    return;
                }
                if (r.status == 409 && attempt < 2) {
                    sendOne(msg, attempt + 1);
                    return;
                }
                if (r.networkError() || r.status >= 500 || r.status == 429 || r.status == 409) {
                    scheduleOutboxRetry();
                    return;
                }
                m_store.call(QStringLiteral("msg.markFailed"),
                             {{QStringLiteral("client_id"), cid}, {QStringLiteral("messaging_id"), mid},
                              {QStringLiteral("permanent"), true}},
                             [this](bool, const QJsonValue&, const QString&) { sendNext(); });
                emit errorOccurred(tr("Message refusé par le serveur (%1)").arg(r.status));
            });
        });
    });
}

void SyncEngine::markRead(const QString& messagingId, qint64 seq) {
    if (seq <= 0) return;
    m_store.call(QStringLiteral("conv.setRead"), {{QStringLiteral("id"), messagingId}, {QStringLiteral("seq"), seq}});
    if (m_online)
        m_api.post(QStringLiteral("sync/ack"),
                   QJsonDocument(QJsonObject{{QStringLiteral("messaging_id"), messagingId}, {QStringLiteral("read_seq"), seq}}),
                   {});
}

}  // namespace ngoma
