from django.contrib import admin

from .models import BotProfile


@admin.register(BotProfile)
class BotProfileAdmin(admin.ModelAdmin):
    list_display = ("owner", "provider", "model_name", "active", "last_error", "updated_at")
    exclude = ("api_key_enc", "keys_enc")
