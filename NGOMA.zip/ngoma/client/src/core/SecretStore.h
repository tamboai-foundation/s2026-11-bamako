#pragma once

#include <QByteArray>
#include <QJsonObject>
#include <QString>
#include <optional>

#include "Ratchet.h"

namespace ngoma {

struct Identity {
    qint64 userId = 0;
    QString username;
    QString displayName;
    QString deviceId;
    QString token;
    ratchet::DeviceKeys keys;  // identité Ed25519 + prékeys (NGOMA Ratchet v2)

    QByteArray publicKey() const { return keys.identityPublic(); }
    bool valid() const { return userId > 0 && !token.isEmpty() && keys.valid(); }
};

/// Secrets du terminal, sur la partition de données chiffrée (LUKS, clé scellée TPM), fichiers en 0600,
/// écritures atomiques. Jamais transmis au démon de stockage.
///   <dataDir>/identity.json          jeton d'appareil + clés privées (identité, prékeys)
///   <dataDir>/sessions/<device>.json  état Double Ratchet par appareil pair
class SecretStore {
public:
    explicit SecretStore(QString dataDir);
    bool load(Identity& out) const;
    bool save(const Identity& id) const;
    bool clear() const;

    std::optional<QJsonObject> loadSession(const QString& peerDeviceId) const;
    bool saveSession(const QString& peerDeviceId, const QJsonObject& state) const;

private:
    QString path() const;
    QString sessionPath(const QString& peerDeviceId) const;
    QString m_dir;
};

}  // namespace ngoma
