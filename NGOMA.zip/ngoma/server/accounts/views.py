import hmac

from django.conf import settings
from django.contrib.auth import authenticate, get_user_model
from django.db import transaction
from django.shortcuts import get_object_or_404
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle
from rest_framework.views import APIView

from . import prekeys
from .models import Device
from .serializers import (
    DeviceEnrollSerializer,
    OwnDeviceSerializer,
    PublicDeviceSerializer,
    SignupSerializer,
    UserSerializer,
)

User = get_user_model()


class EnrollThrottle(AnonRateThrottle):
    rate = "10/min"


def _session_payload(device: Device, token: str) -> dict:
    return {
        "user": UserSerializer(device.user).data,
        "device_id": str(device.id),
        "token": token,
    }


class SignupView(APIView):
    """Création de compte + premier appareil. Fermé par défaut (provisionnement)."""

    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    throttle_classes = [EnrollThrottle]

    def post(self, request):
        cfg = settings.NGOMA
        ser = SignupSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        if not cfg["OPEN_SIGNUP"]:
            expected = cfg["PROVISIONING_CODE"]
            given = data.get("provisioning_code", "")
            if not expected or not hmac.compare_digest(expected, given):
                return Response({"detail": "Inscription soumise à un code de provisionnement"}, status=403)
        with transaction.atomic():
            user = User.objects.create_user(
                username=data["username"], password=data["password"], first_name=data.get("display_name", "")
            )
            device, token = Device.issue(user, data["device_name"], data["public_key"])
        return Response(_session_payload(device, token), status=status.HTTP_201_CREATED)


class EnrollDeviceView(APIView):
    """Connexion d'un nouvel appareil à un compte existant (identifiant + mot de passe)."""

    authentication_classes = []
    permission_classes = [permissions.AllowAny]
    throttle_classes = [EnrollThrottle]

    def post(self, request):
        ser = DeviceEnrollSerializer(data=request.data)
        ser.is_valid(raise_exception=True)
        data = ser.validated_data
        user = authenticate(request, username=data["username"], password=data["password"])
        if user is None:
            return Response({"detail": "Identifiants invalides"}, status=401)
        device, token = Device.issue(user, data["device_name"], data["public_key"])
        return Response(_session_payload(device, token), status=status.HTTP_201_CREATED)


class MeView(APIView):
    def get(self, request):
        return Response({"user": UserSerializer(request.user).data, "device_id": str(request.auth.id)})


class OwnDevicesView(APIView):
    def get(self, request):
        return Response(OwnDeviceSerializer(request.user.devices.order_by("created_at"), many=True).data)


class RevokeDeviceView(APIView):
    def post(self, request, device_id):
        device = get_object_or_404(Device, pk=device_id, user=request.user)
        device.revoke()
        from realtime.events import kick_device

        kick_device(device)
        return Response(status=204)


class UserSearchView(APIView):
    def get(self, request):
        q = request.query_params.get("q", "").strip()
        if len(q) < 2:
            return Response([])
        qs = (User.objects.filter(username__istartswith=q, is_active=True, bot_profile__isnull=True)
              .exclude(pk=request.user.pk)[:20])
        return Response(UserSerializer(qs, many=True).data)


class UserDevicesView(APIView):
    """Clés publiques des appareils actifs d'un ensemble d'utilisateurs : `?ids=1,2,3`."""

    def get(self, request):
        try:
            ids = [int(x) for x in request.query_params.get("ids", "").split(",") if x]
        except ValueError:
            return Response({"detail": "ids invalides"}, status=400)
        ids = ids[:256]
        devices = Device.objects.filter(user_id__in=ids, revoked_at__isnull=True).order_by("user_id", "created_at")
        out: dict[str, list] = {str(i): [] for i in ids}
        for d in devices:
            out[str(d.user_id)].append(PublicDeviceSerializer(d).data)
        return Response(out)


class PreKeysView(APIView):
    """POST : publication de la prékey signée et de prékeys à usage unique. GET : compteur."""

    def get(self, request):
        return Response(prekeys.count(request.auth))

    def post(self, request):
        d = request.data
        try:
            n = prekeys.publish(request.auth, d["spk_id"], d["spk"], d["spk_sig"], list(d.get("opks", []))[:200])
        except (KeyError, TypeError, ValueError, prekeys.PreKeyError) as exc:
            return Response({"detail": str(exc) or "Paquet invalide"}, status=400)
        return Response({"opk_count": n})


class ClaimPreKeysView(APIView):
    """Réserve des paquets X3DH pour des appareils avec lesquels l'appelant partage une conversation."""

    def post(self, request):
        ids = [str(i) for i in request.data.get("device_ids", [])][:256]
        from messaging.models import Membership

        peers = set(
            Membership.objects.filter(messaging__memberships__user=request.user).values_list("user_id", flat=True)
        ) | {request.user.id}
        return Response(prekeys.claim(ids, allowed_user_ids=peers))
