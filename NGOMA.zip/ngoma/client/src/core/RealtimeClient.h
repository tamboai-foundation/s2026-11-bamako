#pragma once

#include <QJsonObject>
#include <QObject>
#include <QTimer>
#include <QWebSocket>

#include "Config.h"

namespace ngoma {

/// Canal WebSocket temps réel : signaux légers (nouveau message, accusé, saisie, signalisation d'appel).
/// Reconnexion avec attente exponentielle + gigue, ping applicatif, détection de connexion morte.
class RealtimeClient : public QObject {
    Q_OBJECT
public:
    RealtimeClient(const Config& cfg, const QSslConfiguration& ssl, QObject* parent = nullptr);
    ~RealtimeClient() override;

    void start(const QString& token);
    void stop();
    bool isConnected() const { return m_connected; }
    void send(const QJsonObject& obj);

signals:
    void connectedChanged(bool connected);
    void eventReceived(const QJsonObject& evt);
    void revoked();

private:
    void openSocket();
    void scheduleReconnect();
    void onText(const QString& text);

    const Config& m_cfg;
    QSslConfiguration m_ssl;
    QWebSocket m_ws;
    QTimer m_ping;
    QTimer m_reconnect;
    QTimer m_watchdog;
    QString m_token;
    int m_attempt = 0;
    bool m_running = false;
    bool m_connected = false;
};

}  // namespace ngoma
