import QtQuick

// Pastille d'initiale avec teinte stable dérivée du nom ; icône pour les groupes et l'assistant.
Rectangle {
    id: root
    property string name: ""
    property string kind: "direct"   // direct | group | assistant
    property int size: 48

    width: size
    height: size
    radius: size / 2

    readonly property var tints: ["#2b6f68", "#6b4fa3", "#a5603a", "#3d6fb0", "#8a4569", "#5e7f2d", "#99702a"]
    function hash(s) { var h = 0; for (var i = 0; i < s.length; ++i) h = (h * 31 + s.charCodeAt(i)) % 9973; return h }
    color: kind === "assistant" ? Theme.accentSoft : tints[hash(name) % tints.length]

    Text {
        visible: root.kind === "direct"
        anchors.centerIn: parent
        text: root.name.length ? root.name.charAt(0).toUpperCase() : "?"
        color: "#ffffff"
        font.pixelSize: root.size * 0.42
        font.weight: Font.DemiBold
    }
    Image {
        visible: root.kind !== "direct"
        anchors.centerIn: parent
        source: Theme.icon(root.kind === "assistant" ? "sparkle" : "group", root.kind === "assistant" ? "accent" : "light")
        sourceSize: Qt.size(root.size * 0.5, root.size * 0.5)
    }
}
