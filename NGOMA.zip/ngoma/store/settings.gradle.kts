rootProject.name = "ngoma-store"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
