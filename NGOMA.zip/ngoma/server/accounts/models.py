import hashlib
import secrets
import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone


def hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class Device(models.Model):
    """Un terminal embarqué. Chaque appareil possède sa propre clé publique X25519 (E2EE)
    et son propre jeton d'accès (seul le hash est stocké)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="devices")
    name = models.CharField(max_length=120)
    public_key = models.CharField(max_length=64, help_text="Clé publique X25519 encodée en base64")
    token_hash = models.CharField(max_length=64, unique=True)
    created_at = models.DateTimeField(default=timezone.now)
    last_seen_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=["user", "revoked_at"])]

    @property
    def is_active(self) -> bool:
        return self.revoked_at is None

    @classmethod
    def issue(cls, user, name: str, public_key: str) -> tuple["Device", str]:
        raw = secrets.token_urlsafe(32)
        device = cls.objects.create(user=user, name=name, public_key=public_key, token_hash=hash_token(raw))
        return device, raw

    def revoke(self) -> None:
        self.revoked_at = timezone.now()
        self.save(update_fields=["revoked_at"])

    def __str__(self) -> str:
        return f"{self.user} / {self.name}"


class SignedPreKey(models.Model):
    """Prékey signée courante d'un appareil (X25519, signée par la clé d'identité Ed25519)."""

    device = models.OneToOneField(Device, on_delete=models.CASCADE, related_name="signed_prekey")
    key_id = models.PositiveIntegerField()
    public_key = models.CharField(max_length=64)
    signature = models.CharField(max_length=100)
    updated_at = models.DateTimeField(default=timezone.now)


class OneTimePreKey(models.Model):
    """Prékey à usage unique : distribuée une seule fois puis supprimée (réservation atomique)."""

    device = models.ForeignKey(Device, on_delete=models.CASCADE, related_name="one_time_prekeys")
    key_id = models.PositiveIntegerField()
    public_key = models.CharField(max_length=64)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["device", "key_id"], name="uniq_opk")]
