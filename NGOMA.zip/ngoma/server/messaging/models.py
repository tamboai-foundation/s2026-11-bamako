import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone


class Messaging(models.Model):
    """Une conversation (1:1 ou groupe). `last_seq` est le compteur de séquence de la conversation."""

    DIRECT, GROUP = "direct", "group"
    KIND_CHOICES = [(DIRECT, "Directe"), (GROUP, "Groupe")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    kind = models.CharField(max_length=8, choices=KIND_CHOICES)
    title = models.CharField(max_length=200, blank=True)
    # Clé déterministe pour garantir une seule conversation directe par paire d'utilisateurs.
    direct_key = models.CharField(max_length=64, unique=True, null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(default=timezone.now)
    last_seq = models.BigIntegerField(default=0)
    updated_at = models.DateTimeField(default=timezone.now, db_index=True)


class Membership(models.Model):
    MEMBER, ADMIN = "member", "admin"
    ROLE_CHOICES = [(MEMBER, "Membre"), (ADMIN, "Admin")]

    messaging = models.ForeignKey(Messaging, on_delete=models.CASCADE, related_name="memberships")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="memberships")
    role = models.CharField(max_length=8, choices=ROLE_CHOICES, default=MEMBER)
    joined_at = models.DateTimeField(default=timezone.now)
    # Premier seq visible par ce membre (un nouvel arrivant ne voit pas l'historique).
    visible_from_seq = models.BigIntegerField(default=1)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["messaging", "user"], name="uniq_membership")]


class Message(models.Model):
    TEXT, MEDIA, SYSTEM = "text", "media", "system"
    KIND_CHOICES = [(TEXT, "Texte"), (MEDIA, "Média"), (SYSTEM, "Système")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    messaging = models.ForeignKey(Messaging, on_delete=models.CASCADE, related_name="messages")
    seq = models.BigIntegerField()
    client_id = models.UUIDField(help_text="UUIDv7 généré par le client, clé d'idempotence")
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    sender_device = models.ForeignKey("accounts.Device", on_delete=models.SET_NULL, null=True, related_name="+")
    kind = models.CharField(max_length=8, choices=KIND_CHOICES, default=TEXT)
    created_at = models.DateTimeField(default=timezone.now)
    expires_at = models.DateTimeField(null=True, blank=True, db_index=True)
    # Métadonnées non chiffrées minimales (ex. texte système : "X a rejoint").
    system_text = models.CharField(max_length=300, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["messaging", "seq"], name="uniq_msg_seq"),
            models.UniqueConstraint(fields=["messaging", "client_id"], name="uniq_msg_client_id"),
        ]
        indexes = [models.Index(fields=["messaging", "seq"])]


class Envelope(models.Model):
    """Le contenu chiffré d'un message, une enveloppe par appareil destinataire.
    Le serveur ne voit jamais le clair."""

    message = models.ForeignKey(Message, on_delete=models.CASCADE, related_name="envelopes")
    device = models.ForeignKey("accounts.Device", on_delete=models.CASCADE, related_name="+")
    # Enveloppe NGOMA Ratchet v2 sérialisée (JSON) : {"v":2,"type","h","c","x"?}. Opaque pour le serveur.
    payload = models.TextField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=["message", "device"], name="uniq_envelope")]


class Receipt(models.Model):
    DELIVERED, READ = "delivered", "read"
    STATE_CHOICES = [(DELIVERED, "Remis"), (READ, "Lu")]

    messaging = models.ForeignKey(Messaging, on_delete=models.CASCADE, related_name="receipts")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="+")
    delivered_seq = models.BigIntegerField(default=0)
    read_seq = models.BigIntegerField(default=0)
    updated_at = models.DateTimeField(default=timezone.now)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["messaging", "user"], name="uniq_receipt")]


def media_path(instance, _filename):
    return f"media/{instance.messaging_id}/{instance.id}.bin"


class Media(models.Model):
    """Pièce jointe CHIFFRÉE côté client (clé dans l'enveloppe du message, jamais sur le serveur)."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    messaging = models.ForeignKey(Messaging, on_delete=models.CASCADE, related_name="media")
    uploader = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="+")
    size = models.PositiveIntegerField()
    blob = models.FileField(upload_to=media_path)
    created_at = models.DateTimeField(default=timezone.now, db_index=True)
