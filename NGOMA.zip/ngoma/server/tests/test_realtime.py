import base64
import os
import secrets
import uuid

import pytest
from channels.db import database_sync_to_async
from channels.testing import WebsocketCommunicator
from django.contrib.auth import get_user_model

from accounts.models import Device, SignedPreKey
from ngoma_server.asgi import application

User = get_user_model()


@database_sync_to_async
def setup_pair():
    a = User.objects.create_user("alice", password=secrets.token_urlsafe(16))
    b = User.objects.create_user("bob", password=secrets.token_urlsafe(16))
    da, ta = Device.issue(a, "ta", base64.b64encode(os.urandom(32)).decode())
    db, tb = Device.issue(b, "tb", base64.b64encode(os.urandom(32)).decode())
    for d in (da, db):
        SignedPreKey.objects.create(device=d, key_id=1, public_key="k", signature="x")
    from messaging.services import create_conversation

    conv, _ = create_conversation(a, "direct", [b.id])
    return a, b, da, db, ta, tb, conv


@database_sync_to_async
def push(a, da, db, conv):
    from messaging.services import push_message

    return push_message(
        user=a, device=da, messaging_id=conv.id, client_id=uuid.uuid4(),
        envelopes=[{"device_id": str(db.id), "payload": {"v": 2, "type": "msg",
                    "h": base64.b64encode(os.urandom(40)).decode(), "c": base64.b64encode(b"x").decode()}}],
    ).message.seq


def ws(token):
    return WebsocketCommunicator(application, "/ws/v1/realtime", headers=[(b"authorization", f"Device {token}".encode())])


@pytest.mark.django_db(transaction=True)
async def test_ws_rejects_anonymous():
    c = WebsocketCommunicator(application, "/ws/v1/realtime")
    connected, code = await c.connect()
    assert not connected and code == 4401


@pytest.mark.django_db(transaction=True)
async def test_message_signal_typing_and_call_relay():
    a, b, da, db, ta, tb, conv = await setup_pair()
    ca, cb = ws(ta), ws(tb)
    assert (await ca.connect())[0] and (await cb.connect())[0]
    assert (await ca.receive_json_from())["event"] == "hello"
    assert (await cb.receive_json_from())["event"] == "hello"

    seq = await push(a, da, db, conv)
    evt = await cb.receive_json_from(timeout=2)
    assert evt == {"event": "message", "messaging_id": str(conv.id), "seq": seq}

    await ca.send_json_to({"type": "typing", "messaging_id": str(conv.id)})
    assert (await cb.receive_json_from(timeout=2))["event"] == "typing"

    await ca.send_json_to({"type": "call.signal", "messaging_id": str(conv.id), "to_user_id": b.id,
                           "payload": {"kind": "offer", "sdp": "v=0"}})
    sig = await cb.receive_json_from(timeout=2)
    assert sig["event"] == "call.signal" and sig["payload"]["kind"] == "offer" and sig["from_user_id"] == a.id

    await ca.send_json_to({"type": "presence.query", "user_ids": [b.id]})
    pres = await ca.receive_json_from(timeout=2)
    # le signal "message" de son propre envoi arrive aussi chez Alice : on le saute
    while pres["event"] != "presence":
        pres = await ca.receive_json_from(timeout=2)
    assert pres["online"] == {str(b.id): True} or pres["online"] == {b.id: True}
    await ca.disconnect()
    await cb.disconnect()
