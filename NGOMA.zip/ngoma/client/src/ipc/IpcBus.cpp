#include "IpcBus.h"

#include <QDebug>
#include <cstring>

#ifdef NGOMA_WITH_ICEORYX2
#include "iox2/iceoryx2.hpp"
#endif

namespace ngoma {

#ifdef NGOMA_WITH_ICEORYX2
using namespace iox2;

namespace {
using VideoService = PortFactoryPublishSubscribe<ServiceType::Ipc, bb::Slice<uint8_t>, ipc::VideoFrameHeader>;
using VideoSub = Subscriber<ServiceType::Ipc, bb::Slice<uint8_t>, ipc::VideoFrameHeader>;

QImage toImage(const bb::ImmutableSlice<uint8_t>& payload, const ipc::VideoFrameHeader& h) {
    if (h.abi != ipc::kAbiVersion || h.format != ipc::PixelFormat::Rgb32) return {};
    const uint64_t need = static_cast<uint64_t>(h.stride) * h.height;
    if (h.width == 0 || h.height == 0 || payload.number_of_elements() < need) return {};
    // Une seule copie : de la mémoire partagée vers la texture Qt. Avec DMA-BUF (VPU/GPU) cette copie disparaît.
    QImage view(payload.data(), int(h.width), int(h.height), int(h.stride), QImage::Format_RGB32);
    return view.copy();
}
}  // namespace

struct IpcBus::Impl {
    std::string prefix;
    ServiceName name(const char* n) const { return ServiceName::create((prefix + n).c_str()).value(); }
    bb::Optional<Node<ServiceType::Ipc>> node;
    bb::Optional<Publisher<ServiceType::Ipc, ipc::CallControl, void>> control;
    bb::Optional<Subscriber<ServiceType::Ipc, ipc::CallState, void>> state;
    bb::Optional<Subscriber<ServiceType::Ipc, ipc::AudioLevel, void>> audio;
    bb::Optional<VideoSub> localVideo;
    bb::Optional<VideoSub> remoteVideo;
    bb::Optional<Publisher<ServiceType::Ipc, ipc::MessageEvent, void>> msgEvent;
    bool ok = false;

    template <typename T>
    auto openFixed(Node<ServiceType::Ipc>& n, const char* svc) {
        return n.service_builder(name(svc))
            .template publish_subscribe<T>()
            .history_size(1)
            .subscriber_max_buffer_size(4)
            .enable_safe_overflow(true)  // médias / état : on écrase le plus ancien, jamais de blocage
            .open_or_create();
    }

    auto openVideo(Node<ServiceType::Ipc>& n, const char* svc) {
        return n.service_builder(name(svc))
            .publish_subscribe<bb::Slice<uint8_t>>()
            .user_header<ipc::VideoFrameHeader>()
            .history_size(0)
            .subscriber_max_buffer_size(2)
            .enable_safe_overflow(true)
            .open_or_create();
    }

    void init() {
        auto n = NodeBuilder().name(NodeName::create("ngoma-ui").value()).create<ServiceType::Ipc>();
        if (!n.has_value()) {
            qWarning() << "iceoryx2 : création du nœud impossible";
            return;
        }
        node.emplace(std::move(n.value()));
        auto ctl = openFixed<ipc::CallControl>(*node, ipc::kSvcCallControl);
        auto st = openFixed<ipc::CallState>(*node, ipc::kSvcCallState);
        auto au = openFixed<ipc::AudioLevel>(*node, ipc::kSvcAudioLevel);
        auto me = openFixed<ipc::MessageEvent>(*node, ipc::kSvcMessageEvent);
        auto lv = openVideo(*node, ipc::kSvcVideoLocal);
        auto rv = openVideo(*node, ipc::kSvcVideoRemote);
        if (!ctl.has_value() || !st.has_value() || !au.has_value() || !me.has_value() || !lv.has_value() ||
            !rv.has_value()) {
            qWarning() << "iceoryx2 : ouverture des services impossible (configuration incompatible ?)";
            return;
        }
        auto p1 = ctl.value().publisher_builder().create();
        auto s1 = st.value().subscriber_builder().create();
        auto s2 = au.value().subscriber_builder().create();
        auto p2 = me.value().publisher_builder().create();
        auto v1 = lv.value().subscriber_builder().create();
        auto v2 = rv.value().subscriber_builder().create();
        if (!p1.has_value() || !s1.has_value() || !s2.has_value() || !p2.has_value() || !v1.has_value() ||
            !v2.has_value()) {
            qWarning() << "iceoryx2 : création des ports impossible";
            return;
        }
        control.emplace(std::move(p1.value()));
        state.emplace(std::move(s1.value()));
        audio.emplace(std::move(s2.value()));
        msgEvent.emplace(std::move(p2.value()));
        localVideo.emplace(std::move(v1.value()));
        remoteVideo.emplace(std::move(v2.value()));
        ok = true;
    }
};

IpcBus::IpcBus(QObject* parent, const QString& prefix) : QObject(parent), d(std::make_unique<Impl>()) {
    d->prefix = prefix.toStdString();
    d->init();
    m_timer.setInterval(16);
    m_timer.setTimerType(Qt::PreciseTimer);
    connect(&m_timer, &QTimer::timeout, this, &IpcBus::poll);
    if (d->ok) m_timer.start(200);  // état et audio à basse fréquence ; 16 ms quand la vidéo est active
}

IpcBus::~IpcBus() = default;

bool IpcBus::available() const { return d->ok; }

void IpcBus::sendCallControl(const ipc::CallControl& cmd) {
    if (!d->ok) return;
    auto sample = d->control->loan_uninit();
    if (!sample.has_value()) return;
    auto init = sample.value().write_payload(ipc::CallControl(cmd));
    if (!send(std::move(init)).has_value()) qWarning() << "iceoryx2 : envoi de commande d'appel impossible";
}

void IpcBus::publishMessageEvent(const QString& messagingId, int unreadTotal) {
    if (!d->ok) return;
    ipc::MessageEvent e;
    e.unread_total = static_cast<std::uint32_t>(qMax(0, unreadTotal));
    const QByteArray id = messagingId.toLatin1().left(sizeof(e.messaging_id) - 1);
    std::memcpy(e.messaging_id, id.constData(), size_t(id.size()));
    auto sample = d->msgEvent->loan_uninit();
    if (!sample.has_value()) return;
    send(sample.value().write_payload(std::move(e))).has_value();
}

void IpcBus::setVideoReceiving(bool on) {
    if (!d->ok) return;
    m_timer.start(on ? 16 : 200);
}

void IpcBus::poll() {
    if (!d->ok) return;
    for (auto s = d->state->receive(); s.has_value() && s.value().has_value(); s = d->state->receive()) {
        const auto& p = s.value()->payload();
        if (p.abi == ipc::kAbiVersion) emit mediaState(int(p.state), p.call_seq, p.frames_sent);
    }
    for (auto s = d->audio->receive(); s.has_value() && s.value().has_value(); s = d->audio->receive()) {
        const auto& p = s.value()->payload();
        if (p.abi == ipc::kAbiVersion) emit audioLevel(p.mic_rms, p.speaker_rms);
    }
    auto drainVideo = [](VideoSub& sub, QImage& last) {
        bool got = false;
        for (auto s = sub.receive(); s.has_value() && s.value().has_value(); s = sub.receive()) {
            QImage img = toImage(s.value()->payload(), s.value()->user_header());
            if (!img.isNull()) {
                last = std::move(img);  // on ne garde que la plus récente (pas de retard accumulé)
                got = true;
            }
        }
        return got;
    };
    QImage frame;
    if (drainVideo(*d->localVideo, frame)) emit localFrame(frame);
    if (drainVideo(*d->remoteVideo, frame)) emit remoteFrame(frame);
}

#else  // ------------------------------------------------------------ implémentation nulle

struct IpcBus::Impl {};
IpcBus::IpcBus(QObject* parent, const QString&) : QObject(parent), d(std::make_unique<Impl>()) {}
IpcBus::~IpcBus() = default;
bool IpcBus::available() const { return false; }
void IpcBus::sendCallControl(const ipc::CallControl&) {}
void IpcBus::publishMessageEvent(const QString&, int) {}
void IpcBus::setVideoReceiving(bool) {}
void IpcBus::poll() {}

#endif

}  // namespace ngoma
