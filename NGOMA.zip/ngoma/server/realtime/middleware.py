from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from channels.middleware import BaseMiddleware

from accounts.auth import device_from_token


@database_sync_to_async
def _resolve(token: str):
    return device_from_token(token)


class DeviceTokenAuthMiddleware(BaseMiddleware):
    """Authentifie la poignée de main WebSocket.

    Le jeton est lu dans l'en-tête `Authorization: Device <jeton>` (client Qt) ;
    à défaut dans le paramètre `?token=` (outils de test uniquement)."""

    async def __call__(self, scope, receive, send):
        token = ""
        for name, value in scope.get("headers", []):
            if name == b"authorization":
                parts = value.decode("latin-1").split()
                if len(parts) == 2 and parts[0] == "Device":
                    token = parts[1]
        if not token:
            token = parse_qs(scope.get("query_string", b"").decode()).get("token", [""])[0]
        device = await _resolve(token) if token else None
        scope["device"] = device
        scope["user"] = device.user if device else None
        return await super().__call__(scope, receive, send)
