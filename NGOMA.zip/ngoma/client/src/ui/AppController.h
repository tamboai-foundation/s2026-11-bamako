#pragma once

#include <QObject>
#include <QTimer>
#include <QUrl>
#include <QVariantList>
#include <QVariantMap>
#include <memory>

#include "core/Config.h"
#include "core/SecretStore.h"

namespace ngoma {

class ApiClient;
class RealtimeClient;
class StoreClient;
class SyncEngine;
class IpcBus;
class ConversationListModel;
class MessageListModel;

/// Façade unique exposée à QML (singleton « App »). QML n'exécute aucune logique métier ni entrée/sortie.
class AppController : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString state READ state NOTIFY stateChanged)
    Q_PROPERTY(bool online READ online NOTIFY onlineChanged)
    Q_PROPERTY(bool syncing READ syncing NOTIFY syncingChanged)
    Q_PROPERTY(bool storeReady READ storeReady NOTIFY storeReadyChanged)
    Q_PROPERTY(QString serverUrl READ serverUrl CONSTANT)
    Q_PROPERTY(QString myName READ myName NOTIFY identityChanged)
    Q_PROPERTY(QString mySafetyNumber READ mySafetyNumber NOTIFY identityChanged)
    Q_PROPERTY(QObject* conversations READ conversations CONSTANT)
    Q_PROPERTY(QObject* messages READ messages CONSTANT)
    Q_PROPERTY(QString currentConversationId READ currentConversationId NOTIFY currentConversationChanged)
    Q_PROPERTY(QString currentTitle READ currentTitle NOTIFY currentConversationChanged)
    Q_PROPERTY(QString typingText READ typingText NOTIFY typingTextChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)
    Q_PROPERTY(QString callState READ callState NOTIFY callStateChanged)
    Q_PROPERTY(QString callPeer READ callPeer NOTIFY callStateChanged)
    Q_PROPERTY(bool mediaAvailable READ mediaAvailable CONSTANT)
    Q_PROPERTY(bool muted READ muted NOTIFY mutedChanged)
    Q_PROPERTY(qreal micLevel READ micLevel NOTIFY micLevelChanged)
    Q_PROPERTY(QVariantMap assistant READ assistant NOTIFY assistantChanged)
    Q_PROPERTY(int maxAttachmentMb READ maxAttachmentMb CONSTANT)

public:
    explicit AppController(Config cfg, QObject* parent = nullptr);
    ~AppController() override;

    void boot();

    QString state() const { return m_state; }
    bool online() const { return m_online; }
    bool syncing() const { return m_syncing; }
    bool storeReady() const;
    QString serverUrl() const { return m_cfg.serverUrl.toString(); }
    QString myName() const { return m_id.displayName.isEmpty() ? m_id.username : m_id.displayName; }
    QString mySafetyNumber() const;
    QObject* conversations() const;
    QObject* messages() const;
    QString currentConversationId() const { return m_current; }
    QString currentTitle() const;
    QString typingText() const { return m_typing; }
    bool busy() const { return m_busy; }
    QString callState() const { return m_callState; }
    QString callPeer() const { return m_callPeerName; }
    bool mediaAvailable() const;
    bool muted() const { return m_muted; }
    qreal micLevel() const { return m_micLevel; }
    QVariantMap assistant() const { return m_assistant; }
    int maxAttachmentMb() const { return 25; }

    Q_INVOKABLE void enroll(const QString& username, const QString& password);
    Q_INVOKABLE void signup(const QString& username, const QString& password, const QString& displayName,
                            const QString& provisioningCode);
    Q_INVOKABLE void logout(bool wipeLocalData);

    Q_INVOKABLE void openConversation(const QString& id);
    Q_INVOKABLE void closeConversation();
    Q_INVOKABLE void send(const QString& text, int ephemeralSeconds = 0);
    Q_INVOKABLE void sendFile(const QUrl& fileUrl, const QString& caption);
    Q_INVOKABLE void downloadAttachment(const QString& clientId);
    Q_INVOKABLE void loadOlder();
    Q_INVOKABLE void notifyTyping();
    Q_INVOKABLE void saveDraft(const QString& text);
    Q_INVOKABLE QString draftFor(const QString& id) const;
    Q_INVOKABLE void retryFailed();

    Q_INVOKABLE void searchUsers(const QString& query);
    Q_INVOKABLE void createDirect(qint64 userId);
    Q_INVOKABLE void createGroup(const QString& title, const QVariantList& userIds);

    Q_INVOKABLE void refreshAssistant();
    Q_INVOKABLE void configureAssistant(const QString& provider, const QString& model, const QString& apiKey,
                                        const QString& baseUrl, const QString& systemPrompt);
    Q_INVOKABLE void disableAssistant();

    Q_INVOKABLE void startCall();
    Q_INVOKABLE void acceptCall();
    Q_INVOKABLE void hangup();
    Q_INVOKABLE void toggleMute();

signals:
    void stateChanged();
    void onlineChanged();
    void syncingChanged();
    void storeReadyChanged();
    void identityChanged();
    void currentConversationChanged();
    void typingTextChanged();
    void busyChanged();
    void callStateChanged();
    void mutedChanged();
    void micLevelChanged();
    void assistantChanged();
    void usersFound(const QVariantList& users);
    void conversationCreated(const QString& id);
    void errorOccurred(const QString& message);
    void notice(const QString& message);

private:
    void setState(const QString& s);
    void setBusy(bool b);
    void startSession();
    void reloadConversations();
    void reloadMessages();
    void finishEnrollment(const QJsonObject& body, const ratchet::DeviceKeys& keys);
    void upsertAndOpen(const QJsonObject& conversation);
    void onCallSignal(const QJsonObject& evt);
    void setCall(const QString& state, const QString& peerName = {});
    void sendCallSignal(const QString& kind, const QJsonObject& extra = {});
    void startMedia();
    void mediaCommand(int command);

    Config m_cfg;
    Identity m_id;
    std::unique_ptr<SecretStore> m_secrets;
    std::unique_ptr<ApiClient> m_api;
    std::unique_ptr<RealtimeClient> m_rt;
    std::unique_ptr<StoreClient> m_store;
    std::unique_ptr<SyncEngine> m_sync;
    std::unique_ptr<IpcBus> m_ipc;
    std::unique_ptr<ConversationListModel> m_convModel;
    std::unique_ptr<MessageListModel> m_msgModel;

    QString m_state = QStringLiteral("starting");
    bool m_online = false;
    bool m_syncing = false;
    bool m_busy = false;
    QString m_current;
    QString m_typing;
    QTimer m_typingClear;
    QTimer m_reloadConv;
    QTimer m_reloadMsg;
    qint64 m_lastTypingSent = 0;
    QVariantMap m_assistant;

    QString m_callState = QStringLiteral("idle");
    QString m_callId;
    QString m_callMessagingId;
    qint64 m_callPeerId = 0;
    QString m_callPeerName;
    QByteArray m_callKey;
    quint64 m_callSeq = 0;
    bool m_muted = false;
    qreal m_micLevel = 0;
};

}  // namespace ngoma
