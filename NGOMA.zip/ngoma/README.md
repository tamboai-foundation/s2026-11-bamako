# NGOMA — v1.2

Messagerie instantanée pour **terminaux Linux embarqués**. La seule interface est **Qt Quick (QML)**, en plein écran : pas de bureau, pas de client web.

| Composant | Langage | Rôle |
|---|---|---|
| `client/` → `ngoma-terminal` | C++20, Qt 6.8 (QML) | Interface, moteur de synchronisation, chiffrement de bout en bout (NGOMA Ratchet v2), pièces jointes |
| `client/` → `ngoma-media` | C++20, iceoryx2, Opus, FFmpeg, ALSA, V4L2 | Appels audio et vidéo chiffrés, trames en mémoire partagée vers l'UI |
| `relay/` → `ngoma-relay` | C++20, libsodium | Relais UDP des appels (côté serveur, aucune clé média) |
| `store/` → `ngoma-store` | Kotlin, JDK 21, T-Modeler | Base locale hors ligne, en démon sur socket Unix |
| `server/` | Django 5, DRF, Channels, PyNaCl | Comptes, prékeys, synchronisation, temps réel, médias, assistants IA |
| `deploy/` | systemd, Docker, Caddy | Terminal et serveur |
| `tools/` | Bash, Python | Démonstration, tests d'intégration, doublures (stockage, LLM, pair Ratchet), contrôle des secrets |
| `docs/` | Markdown, PNG | Protocoles, cryptographie, exploitation, captures d'écran |

## Captures d'écran

Ces captures viennent du terminal réel (`ngoma-terminal`, écran 1024×600), connecté à un serveur NGOMA. Les messages ont été chiffrés de bout en bout puis déchiffrés sur le terminal. Elles sont reproductibles avec `tools/run_demo.sh` (voir plus bas).

| | |
|---|---|
| ![Enrôlement](docs/captures/00-enrolement.png) Enrôlement d'un terminal neuf | ![Création de compte](docs/captures/00b-creation-compte.png) Création de compte (code de provisionnement) |
| ![Conversations](docs/captures/01-liste-conversations.png) Liste des conversations et non-lus | ![Conversation directe](docs/captures/02-conversation-directe.png) Conversation directe chiffrée |
| ![Groupe](docs/captures/03-groupe.png) Groupe, avec le nom de l'auteur de chaque message | ![Assistant IA](docs/captures/04-assistant-ia.png) Assistant IA (bot côté serveur) |
| ![Appel](docs/captures/05-appel.png) Appel chiffré : aperçu local via iceoryx2 (mire de test sans caméra) | ![Réglages](docs/captures/06-reglages.png) Réglages : numéro de sécurité |
| ![Assistant](docs/captures/07-reglages-assistant.png) Activation de l'assistant IA | ![Nouvelle conversation](docs/captures/08-nouvelle-conversation.png) Recherche d'un contact |
| ![Nouveau groupe](docs/captures/09-nouveau-groupe.png) Création d'un groupe | |

## Architecture

```
┌──────────────── Terminal embarqué ────────────────┐        ┌──────────────── Serveur ────────────────┐
│ ngoma-terminal (Qt Quick, eglfs)                  │ HTTPS  │ Caddy (TLS 1.3)                          │
│   QML ─ AppController ─ SyncEngine ─ ApiClient ───┼────────┼► Django API ×N ─ PostgreSQL · Redis      │
│                         (Ratchet v2) └ Realtime ──┼── WSS ─┼► Channels                                │
│                              │ socket Unix        │        │  run_bots (assistants IA) ─► LLM (HTTPS) │
│                              ▼                    │        │                                          │
│               ngoma-store (T-Modeler, LUKS)       │  UDP   │                                          │
│ IpcBus ◄═ iceoryx2 ═► ngoma-media ════════════════┼════════┼► ngoma-relay ◄═══► autre terminal       │
│                  Opus · H.264 · ChaCha20-Poly1305 │chiffré │  (HMAC, sans clé média)                  │
└───────────────────────────────────────────────────┘        └──────────────────────────────────────────┘
```

## Fonctionnalités

**V1.1**
- **Pièces jointes chiffrées de bout en bout** (25 Mo maximum) : clé aléatoire par fichier, transmise dans l'enveloppe Ratchet ; aperçu d'image chiffré ; intégrité vérifiée par SHA-256.
- **Appels audio et vidéo 1:1**, chiffrés de bout en bout par une clé propre à chaque appel :
  - Opus 20 ms avec FEC, tampon de gigue et masquage des pertes ;
  - H.264 en faible latence, avec demande d'image clé après une perte ;
  - relais UDP protégé par jeton HMAC.

**V1.2**
- **Confidentialité persistante** (NGOMA Ratchet v2, X3DH et Double Ratchet) pour les conversations 1:1 et de groupe :
  - prékeys publiées automatiquement, avec rotation hebdomadaire ;
  - épinglage TOFU des identités d'appareil.
- **Assistant IA intégré** : un bot-participant côté serveur, que chaque utilisateur active et désactive depuis ses réglages.
  - Fournisseurs : Anthropic (Claude), ou toute API compatible OpenAI.
  - Clé API chiffrée au repos ; mémoire courte effaçable par `/reset`.

**Interface**
- Thème sombre unique, avec une palette globale appliquée à tous les contrôles Qt Quick.
- Composants maison : `AppButton`, `IconButton`, `AppTextField`, `Avatar`, `PageHeader`.
- Icônes SVG embarquées, générées par `tools/gen_icons.py` : aucune dépendance aux émojis ni aux polices du système.
- Cibles tactiles d'au moins 52 px ; texte au contraste AA sur tous les fonds.

Voir `docs/CRYPTO.md`, `docs/PROTOCOL.md` et `docs/OPERATIONS.md`.

## Compiler

```bash
# Terminal + média + relais : Qt ≥ 6.8 (dont Qt SVG), libsodium, iceoryx2-cxx, opus, alsa, libavcodec/libswscale
cmake -S client -B build -DCMAKE_PREFIX_PATH=/opt/iceoryx2 -DCMAKE_BUILD_TYPE=Release
cmake --build build && ctest --test-dir build
# Démon de stockage (co.tamboai:TModeler-jvm:1.0.1, Maven Central)
cd store && gradle installDist
# Serveur
cd server && pip install -r requirements.txt && python -m pytest -q
```

Options : `-DNGOMA_QT_MIN=6.4` pour un banc de développement, `-DNGOMA_WITH_ICEORYX2=OFF` pour un client sans média.

## Démonstration

```bash
tools/run_demo.sh /tmp/ngoma-demo     # serveur, Redis, worker IA, faux LLM, données de démonstration chiffrées
# puis, dans un autre terminal, la commande ngoma-terminal affichée par le script
```

Tous les secrets de la démonstration (clé Django, secret du relais, clé du coffre des bots, mots de passe, code de provisionnement, clé du faux LLM) sont **générés à chaque lancement**. Ils restent dans le dossier de travail et ne sont jamais versionnés.

## Secrets : aucun dans le dépôt

- Le dépôt ne contient **aucun mot de passe, clé ni jeton**.
  - Les tests et les scripts génèrent leurs identifiants à l'exécution (`secrets.token_urlsafe`, `Crypto::random`).
  - Le faux LLM reçoit sa clé attendue par `NGOMA_FAKE_LLM_KEY`.
- En production, le serveur **refuse de démarrer** sans `NGOMA_SECRET_KEY` et `NGOMA_RELAY_SECRET`. Les assistants IA restent indisponibles sans `NGOMA_BOT_KEY`.
- Hors production, ces valeurs sont aléatoires et éphémères, régénérées à chaque démarrage.
- `deploy/server/server.env.example` ne contient que des emplacements à remplacer. Les fichiers réels (`server.env`, `pg_password.txt`, `identity.json`, `*.pem`…) sont exclus par `.gitignore`.
- **Contrôle CI :** `python3 tools/scan_secrets.py` échoue s'il trouve :
  - un fichier sensible, une clé privée ou un jeton de fournisseur (AWS, GitHub, Slack, Anthropic/OpenAI, Google) ;
  - une affectation littérale de mot de passe, de clé ou de jeton ;
  - une chaîne à forte entropie.

## Tests

| Suite | Commande | Couverture |
|---|---|---|
| Serveur (28) | `cd server && python -m pytest` | Ratchet Python ; prékeys (signature, réservation unique, droits) ; enveloppes v2 ; idempotence et séquences ; médias ; jetons d'appel ; bots (SSRF, cycle complet OpenAI et Anthropic, erreurs, `/reset`, désactivation) ; WebSocket |
| Client (3 suites) | `ctest --test-dir build` | Chiffrement, UUIDv7, modèles QML, **Ratchet C++ et interopérabilité C++ ↔ Python dans les deux rôles** |
| Interface | `NGOMA_QML_SELFTEST=1 QT_QPA_PLATFORM=offscreen build/ngoma-terminal` | Instanciation des 14 composants QML ; le moindre avertissement fait échouer le test |
| Bout en bout (7) | `tools/run_integration.sh build` | Serveur, worker des bots, Redis, deux terminaux C++ : Ratchet dans les deux sens, outbox hors ligne, pièce jointe, échange de clé d'appel, **assistant IA** (X3DH du bot Python vers le C++, faux LLM local) |
| Appels (5) | `tools/run_call_check.sh build` | Relais et deux `ngoma-media` : H.264 et Opus chiffrés dans les deux sens, mauvaise clé refusée, jeton falsifié refusé |
| iceoryx2 (3) | `tools/run_ipc_check.sh build` | Trames locales vers l'UI |
| Secrets | `python3 tools/scan_secrets.py` | Aucun secret ni fichier sensible dans l'arborescence |

## État et limites

| Fonction | État |
|---|---|
| Messagerie 1:1 et groupes, accusés, saisie, présence, éphémères, hors ligne | ✅ |
| Chiffrement de bout en bout avec confidentialité persistante (Ratchet v2) | ✅ (audit externe requis ; pas libsignal ni MLS, voir `CRYPTO.md`) |
| Pièces jointes chiffrées | ✅ |
| Appels audio et vidéo 1:1 chiffrés via relais | ✅ (pas WebRTC : pas d'ICE ni de contrôle de congestion, voir `OPERATIONS.md`) |
| Assistant IA (bot côté serveur, Anthropic ou compatible OpenAI) | ✅ (les messages au bot sont lus par le serveur et le fournisseur, comme l'indique l'interface) |
| Émojis en couleur dans les messages | ⚠ Dépend de Qt ≥ 6.8 et d'une police d'émojis couleur sur la cible ; sous Qt 6.4 (banc de développement), ils s'affichent en monochrome |
| Démon Kotlin `ngoma-store` | écrit d'après l'API réelle de T-Modeler ; **non compilé ici** (Maven Central inaccessible depuis l'environnement de développement) |
| Appels de groupe, vocaux enregistrés | ⏳ V1.3 / V2.0 |
