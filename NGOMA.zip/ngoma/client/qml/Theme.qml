pragma Singleton
import QtQuick

// Charte graphique NGOMA : thème sombre, contrastes WCAG AA, cibles tactiles ≥ 48 px.
QtObject {
    readonly property string brand: "NGOMA"

    // Surfaces
    readonly property color background: "#0f1419"
    readonly property color surface: "#161d24"
    readonly property color surfaceHigh: "#1f2831"
    readonly property color surfaceHover: "#27323d"
    readonly property color surfacePressed: "#2e3a46"
    readonly property color outline: "#2f3a46"
    readonly property color outlineStrong: "#3d4a57"

    // Texte (contraste ≥ 4.5:1 sur `background` et `surface`)
    readonly property color text: "#e6edf3"
    readonly property color textMuted: "#9aa7b4"
    readonly property color textDisabled: "#5f6b77"

    // Accent et états
    readonly property color accent: "#3fb6a8"
    readonly property color accentHover: "#52c4b6"
    readonly property color accentPressed: "#2f9a8e"
    readonly property color accentText: "#06201d"
    readonly property color accentSoft: "#163a37"
    readonly property color danger: "#e5534b"
    readonly property color dangerPressed: "#c7413a"
    readonly property color warning: "#d8a23a"
    readonly property color warningSoft: "#3a2e14"

    // Bulles
    readonly property color bubbleMine: "#1d5751"
    readonly property color bubbleOther: "#1f2831"

    // Géométrie
    readonly property int radius: 14
    readonly property int radiusSmall: 10
    readonly property int spacing: 12
    readonly property int touch: 52
    readonly property int headerHeight: 64

    // Typographie
    readonly property int fontSmall: 14
    readonly property int fontBody: 18
    readonly property int fontLarge: 20
    readonly property int fontTitle: 24

    function icon(name, variant) { return "icons/" + name + "-" + (variant || "light") + ".svg" }
}
