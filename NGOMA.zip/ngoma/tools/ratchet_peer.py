#!/usr/bin/env python3
"""Pair Python du protocole NGOMA Ratchet v2, piloté en JSON-lignes sur stdin/stdout.
Utilisé par le test C++ test_ratchet pour vérifier l'interopérabilité C++ ↔ Python."""
import base64
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
from fcrypto import ratchet as r  # noqa: E402

keys = r.DeviceKeys.generate()
session = None

for line in sys.stdin:
    req = json.loads(line)
    cmd = req["cmd"]
    try:
        if cmd == "bundle":
            up = keys.public_upload(keys.new_opks(1))
            out = {"identity_key": r.b64e(keys.identity_pk), "spk_id": up["spk_id"], "spk": up["spk"],
                   "spk_sig": up["spk_sig"], "opk_id": up["opks"][0]["id"], "opk": up["opks"][0]["key"]}
        elif cmd == "initiate":
            session = r.initiate(keys, req["bundle"])
            out = {"ok": True}
        elif cmd == "encrypt":
            out = r.encrypt(session, base64.b64decode(req["pt"]))
        elif cmd == "decrypt":
            pt, session = r.decrypt(keys, session, req["env"])
            out = {"pt": base64.b64encode(pt).decode()}
        else:
            out = {"error": "commande inconnue"}
    except r.CryptoError as exc:
        out = {"error": str(exc)}
    print(json.dumps(out), flush=True)
