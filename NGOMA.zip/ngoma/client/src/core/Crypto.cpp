#include "Crypto.h"

#include <sodium.h>

namespace ngoma {

bool Crypto::init() { return sodium_init() >= 0; }

bool Crypto::generateKeyPair(QByteArray& publicKey, QByteArray& secretKey) {
    publicKey.resize(crypto_box_PUBLICKEYBYTES);
    secretKey.resize(crypto_box_SECRETKEYBYTES);
    return crypto_box_keypair(reinterpret_cast<unsigned char*>(publicKey.data()),
                              reinterpret_cast<unsigned char*>(secretKey.data())) == 0;
}

std::optional<Sealed> Crypto::seal(const QByteArray& plaintext, const QByteArray& recipientPublicKey,
                                   const QByteArray& senderSecretKey) {
    if (recipientPublicKey.size() != crypto_box_PUBLICKEYBYTES || senderSecretKey.size() != crypto_box_SECRETKEYBYTES)
        return std::nullopt;
    QByteArray nonce(crypto_box_NONCEBYTES, Qt::Uninitialized);
    randombytes_buf(nonce.data(), size_t(nonce.size()));
    QByteArray ct(plaintext.size() + int(crypto_box_MACBYTES), Qt::Uninitialized);
    if (crypto_box_easy(reinterpret_cast<unsigned char*>(ct.data()),
                        reinterpret_cast<const unsigned char*>(plaintext.constData()),
                        static_cast<unsigned long long>(plaintext.size()),
                        reinterpret_cast<const unsigned char*>(nonce.constData()),
                        reinterpret_cast<const unsigned char*>(recipientPublicKey.constData()),
                        reinterpret_cast<const unsigned char*>(senderSecretKey.constData())) != 0)
        return std::nullopt;
    return Sealed{QString::fromLatin1(nonce.toBase64()), QString::fromLatin1(ct.toBase64())};
}

std::optional<QByteArray> Crypto::open(const QString& nonceB64, const QString& ciphertextB64,
                                       const QByteArray& senderPublicKey, const QByteArray& recipientSecretKey) {
    const QByteArray nonce = QByteArray::fromBase64(nonceB64.toLatin1());
    const QByteArray ct = QByteArray::fromBase64(ciphertextB64.toLatin1());
    if (nonce.size() != crypto_box_NONCEBYTES || ct.size() < int(crypto_box_MACBYTES) ||
        senderPublicKey.size() != crypto_box_PUBLICKEYBYTES || recipientSecretKey.size() != crypto_box_SECRETKEYBYTES)
        return std::nullopt;
    QByteArray pt(ct.size() - int(crypto_box_MACBYTES), Qt::Uninitialized);
    if (crypto_box_open_easy(reinterpret_cast<unsigned char*>(pt.data()),
                             reinterpret_cast<const unsigned char*>(ct.constData()),
                             static_cast<unsigned long long>(ct.size()),
                             reinterpret_cast<const unsigned char*>(nonce.constData()),
                             reinterpret_cast<const unsigned char*>(senderPublicKey.constData()),
                             reinterpret_cast<const unsigned char*>(recipientSecretKey.constData())) != 0)
        return std::nullopt;
    return pt;
}

QString Crypto::fingerprint(const QByteArray& publicKey) {
    unsigned char h[16];
    crypto_generichash(h, sizeof h, reinterpret_cast<const unsigned char*>(publicKey.constData()),
                       size_t(publicKey.size()), nullptr, 0);
    QString out;
    for (size_t i = 0; i < sizeof h; i += 2) {
        if (!out.isEmpty()) out.append(QLatin1Char(' '));
        out.append(QString::number((h[i] << 8 | h[i + 1]) % 100000).rightJustified(5, QLatin1Char('0')));
    }
    return out;
}

QByteArray Crypto::sealBlob(const QByteArray& plaintext, QByteArray& key, QByteArray& nonce) {
    key = random(crypto_aead_xchacha20poly1305_ietf_KEYBYTES);
    nonce = random(crypto_aead_xchacha20poly1305_ietf_NPUBBYTES);
    QByteArray ct(plaintext.size() + int(crypto_aead_xchacha20poly1305_ietf_ABYTES), Qt::Uninitialized);
    unsigned long long len = 0;
    crypto_aead_xchacha20poly1305_ietf_encrypt(reinterpret_cast<unsigned char*>(ct.data()), &len,
                                               reinterpret_cast<const unsigned char*>(plaintext.constData()),
                                               size_t(plaintext.size()), nullptr, 0, nullptr,
                                               reinterpret_cast<const unsigned char*>(nonce.constData()),
                                               reinterpret_cast<const unsigned char*>(key.constData()));
    ct.resize(int(len));
    return ct;
}

std::optional<QByteArray> Crypto::openBlob(const QByteArray& ct, const QByteArray& key, const QByteArray& nonce) {
    if (key.size() != crypto_aead_xchacha20poly1305_ietf_KEYBYTES || nonce.size() != crypto_aead_xchacha20poly1305_ietf_NPUBBYTES ||
        ct.size() < int(crypto_aead_xchacha20poly1305_ietf_ABYTES))
        return std::nullopt;
    QByteArray pt(ct.size(), Qt::Uninitialized);
    unsigned long long len = 0;
    if (crypto_aead_xchacha20poly1305_ietf_decrypt(reinterpret_cast<unsigned char*>(pt.data()), &len, nullptr,
                                                   reinterpret_cast<const unsigned char*>(ct.constData()), size_t(ct.size()),
                                                   nullptr, 0, reinterpret_cast<const unsigned char*>(nonce.constData()),
                                                   reinterpret_cast<const unsigned char*>(key.constData())) != 0)
        return std::nullopt;
    pt.resize(int(len));
    return pt;
}

QByteArray Crypto::sha256(const QByteArray& data) {
    QByteArray out(crypto_hash_sha256_BYTES, Qt::Uninitialized);
    crypto_hash_sha256(reinterpret_cast<unsigned char*>(out.data()), reinterpret_cast<const unsigned char*>(data.constData()),
                       static_cast<unsigned long long>(data.size()));
    return out;
}

QByteArray Crypto::random(int n) {
    QByteArray out(n, Qt::Uninitialized);
    randombytes_buf(out.data(), size_t(n));
    return out;
}

void Crypto::wipe(QByteArray& secret) {
    if (!secret.isEmpty()) sodium_memzero(secret.data(), size_t(secret.size()));
    secret.clear();
}

}  // namespace ngoma
