#include "StoreClient.h"

#include <QDebug>
#include <QJsonDocument>

namespace ngoma {

StoreClient::StoreClient(QString socketPath, QObject* parent) : QObject(parent), m_path(std::move(socketPath)) {
    m_retry.setInterval(1000);
    m_retry.setSingleShot(true);
    connect(&m_retry, &QTimer::timeout, this, &StoreClient::connectToDaemon);
    connect(&m_sock, &QLocalSocket::connected, this, [this] {
        emit readyChanged(true);
        flushQueue();
    });
    connect(&m_sock, &QLocalSocket::disconnected, this, [this] {
        // Les réponses en attente sont perdues : on les signale en échec, l'appelant réessaiera.
        const auto pending = std::exchange(m_pending, {});
        for (const auto& cb : pending)
            if (cb) cb(false, {}, QStringLiteral("démon de stockage déconnecté"));
        m_buffer.clear();
        emit readyChanged(false);
        m_retry.start();
    });
    connect(&m_sock, &QLocalSocket::errorOccurred, this, [this](QLocalSocket::LocalSocketError) {
        if (m_sock.state() != QLocalSocket::ConnectedState && !m_retry.isActive()) m_retry.start();
    });
    connect(&m_sock, &QLocalSocket::readyRead, this, &StoreClient::onReadyRead);
}

StoreClient::~StoreClient() {
    // Les rappels en attente peuvent référencer des objets déjà détruits : ils ne sont pas invoqués.
    m_sock.disconnect(this);
    m_pending.clear();
    m_sock.abort();
}

void StoreClient::connectToDaemon() {
    if (m_sock.state() == QLocalSocket::UnconnectedState) m_sock.connectToServer(m_path);
}

void StoreClient::call(const QString& op, const QJsonObject& args, Callback cb) {
    const qint64 id = m_nextId++;
    QJsonObject req{{QStringLiteral("id"), id}, {QStringLiteral("op"), op}, {QStringLiteral("args"), args}};
    QByteArray line = QJsonDocument(req).toJson(QJsonDocument::Compact);
    line.append('\n');
    m_pending.insert(id, std::move(cb));
    if (isReady())
        m_sock.write(line);
    else
        m_queue.append(line);
}

void StoreClient::flushQueue() {
    for (const auto& line : std::as_const(m_queue)) m_sock.write(line);
    m_queue.clear();
}

void StoreClient::onReadyRead() {
    m_buffer.append(m_sock.readAll());
    if (m_buffer.size() > (8 << 20)) {  // garde-fou mémoire
        qWarning() << "ngoma-store : trame trop longue, reconnexion";
        m_sock.abort();
        return;
    }
    qsizetype nl;
    while ((nl = m_buffer.indexOf('\n')) >= 0) {
        const QByteArray line = m_buffer.left(nl);
        m_buffer.remove(0, nl + 1);
        const auto obj = QJsonDocument::fromJson(line).object();
        if (obj.contains(QStringLiteral("event"))) {
            emit changed(obj.value(QStringLiteral("scope")).toString(), obj.value(QStringLiteral("messaging_id")).toString());
            continue;
        }
        const qint64 id = obj.value(QStringLiteral("id")).toInteger();
        auto cb = m_pending.take(id);
        if (cb)
            cb(obj.value(QStringLiteral("ok")).toBool(), obj.value(QStringLiteral("result")),
               obj.value(QStringLiteral("error")).toString());
    }
}

}  // namespace ngoma
