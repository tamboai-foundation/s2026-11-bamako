#include "Ratchet.h"

#include <QDateTime>
#include <sodium.h>

#include <array>

namespace ngoma::ratchet {

namespace {

constexpr int kMaxSkip = 1000;
constexpr int kMaxSkippedStored = 2000;
const QByteArray kSpkPrefix = QByteArrayLiteral("NGM-SPK1");

using u8 = unsigned char;
inline const u8* U(const QByteArray& b) { return reinterpret_cast<const u8*>(b.constData()); }
inline u8* W(QByteArray& b) { return reinterpret_cast<u8*>(b.data()); }

QString b64e(const QByteArray& b) { return QString::fromLatin1(b.toBase64()); }
QByteArray b64d(const QJsonValue& v) { return QByteArray::fromBase64(v.toString().toLatin1()); }

QByteArray hmac(const QByteArray& key, const QByteArray& data) {
    QByteArray out(crypto_auth_hmacsha256_BYTES, Qt::Uninitialized);
    crypto_auth_hmacsha256_state st;
    crypto_auth_hmacsha256_init(&st, U(key), size_t(key.size()));
    crypto_auth_hmacsha256_update(&st, U(data), size_t(data.size()));
    crypto_auth_hmacsha256_final(&st, W(out));
    return out;
}

QByteArray hkdf(const QByteArray& salt, const QByteArray& ikm, const QByteArray& info, int length) {
    const QByteArray prk = hmac(salt, ikm);
    QByteArray out, t;
    for (int i = 1; out.size() < length; ++i) {
        t = hmac(prk, t + info + QByteArray(1, char(i)));
        out += t;
    }
    return out.left(length);
}

QByteArray dh(const QByteArray& sk, const QByteArray& pk) {
    QByteArray out(crypto_scalarmult_BYTES, Qt::Uninitialized);
    if (sk.size() != 32 || pk.size() != 32 || crypto_scalarmult(W(out), U(sk), U(pk)) != 0) return {};
    return out;
}

std::pair<QByteArray, QByteArray> x25519Keypair() {
    QByteArray pk(32, Qt::Uninitialized), sk(32, Qt::Uninitialized);
    crypto_box_keypair(W(pk), W(sk));
    return {sk, pk};
}

QByteArray edToXPk(const QByteArray& ed) {
    QByteArray out(32, Qt::Uninitialized);
    if (ed.size() != 32 || crypto_sign_ed25519_pk_to_curve25519(W(out), U(ed)) != 0) return {};
    return out;
}

QByteArray edToXSk(const QByteArray& ed64) {
    QByteArray out(32, Qt::Uninitialized);
    if (ed64.size() != 64 || crypto_sign_ed25519_sk_to_curve25519(W(out), U(ed64)) != 0) return {};
    return out;
}

std::pair<QByteArray, QByteArray> kdfRk(const QByteArray& rk, const QByteArray& dhOut) {
    const QByteArray o = hkdf(rk, dhOut, QByteArrayLiteral("NgomaRatchet"), 64);
    return {o.left(32), o.mid(32)};
}

std::pair<QByteArray, QByteArray> kdfCk(const QByteArray& ck) {
    return {hmac(ck, QByteArray(1, '\x02')), hmac(ck, QByteArray(1, '\x01'))};
}

std::pair<QByteArray, QByteArray> msgKeyNonce(const QByteArray& mk) {
    const QByteArray o = hkdf(QByteArray(32, '\0'), mk, QByteArrayLiteral("NgomaMsg"), 56);
    return {o.left(32), o.mid(32)};
}

QByteArray headerBytes(const QByteArray& dhPub, quint32 pn, quint32 n) {
    QByteArray h = dhPub;
    for (quint32 v : {pn, n})
        for (int s = 24; s >= 0; s -= 8) h.append(char((v >> s) & 0xFF));
    return h;
}

quint32 be32(const QByteArray& b, int off) {
    return (quint32(u8(b[off])) << 24) | (quint32(u8(b[off + 1])) << 16) | (quint32(u8(b[off + 2])) << 8) | quint32(u8(b[off + 3]));
}

QByteArray x3dhSk(const QList<QByteArray>& parts) {
    QByteArray ikm(32, '\xff');
    for (const auto& p : parts) ikm += p;
    return hkdf(QByteArray(32, '\0'), ikm, QByteArrayLiteral("NgomaX3DH"), 32);
}

QByteArray aeadEncrypt(const QByteArray& pt, const QByteArray& ad, const QByteArray& nonce, const QByteArray& key) {
    QByteArray ct(pt.size() + int(crypto_aead_xchacha20poly1305_ietf_ABYTES), Qt::Uninitialized);
    unsigned long long len = 0;
    crypto_aead_xchacha20poly1305_ietf_encrypt(W(ct), &len, U(pt), size_t(pt.size()), U(ad), size_t(ad.size()), nullptr,
                                               U(nonce), U(key));
    ct.resize(int(len));
    return ct;
}

std::optional<QByteArray> aeadDecrypt(const QByteArray& ct, const QByteArray& ad, const QByteArray& nonce, const QByteArray& key) {
    if (ct.size() < int(crypto_aead_xchacha20poly1305_ietf_ABYTES)) return std::nullopt;
    QByteArray pt(ct.size(), Qt::Uninitialized);
    unsigned long long len = 0;
    if (crypto_aead_xchacha20poly1305_ietf_decrypt(W(pt), &len, nullptr, U(ct), size_t(ct.size()), U(ad), size_t(ad.size()),
                                                   U(nonce), U(key)) != 0)
        return std::nullopt;
    pt.resize(int(len));
    return pt;
}

void setErr(QString* e, const QString& m) {
    if (e) *e = m;
}

bool skip(QJsonObject& s, qint64 until, QString* err) {
    if (s.value(QStringLiteral("ckr")).isNull() || s.value(QStringLiteral("ckr")).isUndefined()) return true;
    qint64 nr = s.value(QStringLiteral("nr")).toInteger();
    if (until - nr > kMaxSkip) {
        setErr(err, QStringLiteral("trop de messages sautés"));
        return false;
    }
    QByteArray ck = b64d(s.value(QStringLiteral("ckr")));
    QJsonObject skipped = s.value(QStringLiteral("skipped")).toObject();
    const QString dhr = s.value(QStringLiteral("dhr")).toString();
    while (nr < until) {
        auto [next, mk] = kdfCk(ck);
        skipped.insert(dhr + QLatin1Char(':') + QString::number(nr), b64e(mk));
        ck = next;
        ++nr;
    }
    while (skipped.size() > kMaxSkippedStored) skipped.erase(skipped.begin());
    s.insert(QStringLiteral("skipped"), skipped);
    s.insert(QStringLiteral("ckr"), b64e(ck));
    s.insert(QStringLiteral("nr"), nr);
    return true;
}

std::optional<std::pair<QByteArray, QJsonObject>> ratchetDecrypt(QJsonObject s, const QJsonObject& env, QString* err) {
    const QByteArray h = b64d(env.value(QStringLiteral("h")));
    if (h.size() != 40) {
        setErr(err, QStringLiteral("en-tête invalide"));
        return std::nullopt;
    }
    const QByteArray dhPub = h.left(32);
    const quint32 pn = be32(h, 32), n = be32(h, 36);
    const QString dhB64 = b64e(dhPub);
    const QString keyId = dhB64 + QLatin1Char(':') + QString::number(n);
    QJsonObject skipped = s.value(QStringLiteral("skipped")).toObject();
    QByteArray mk;
    if (skipped.contains(keyId)) {
        mk = b64d(skipped.take(keyId));
        s.insert(QStringLiteral("skipped"), skipped);
    } else {
        if (dhB64 != s.value(QStringLiteral("dhr")).toString()) {
            if (!skip(s, pn, err)) return std::nullopt;
            s.insert(QStringLiteral("pn"), s.value(QStringLiteral("ns")).toInteger());
            s.insert(QStringLiteral("ns"), 0);
            s.insert(QStringLiteral("nr"), 0);
            s.insert(QStringLiteral("dhr"), dhB64);
            const QByteArray d1 = dh(b64d(s.value(QStringLiteral("dhs_sk"))), dhPub);
            if (d1.isEmpty()) {
                setErr(err, QStringLiteral("clé DH invalide"));
                return std::nullopt;
            }
            auto [rk1, ckr] = kdfRk(b64d(s.value(QStringLiteral("rk"))), d1);
            auto [dhsSk, dhsPk] = x25519Keypair();
            auto [rk2, cks] = kdfRk(rk1, dh(dhsSk, dhPub));
            s.insert(QStringLiteral("rk"), b64e(rk2));
            s.insert(QStringLiteral("ckr"), b64e(ckr));
            s.insert(QStringLiteral("cks"), b64e(cks));
            s.insert(QStringLiteral("dhs_sk"), b64e(dhsSk));
            s.insert(QStringLiteral("dhs_pk"), b64e(dhsPk));
        }
        if (!skip(s, n, err)) return std::nullopt;
        auto [ck, k] = kdfCk(b64d(s.value(QStringLiteral("ckr"))));
        mk = k;
        s.insert(QStringLiteral("ckr"), b64e(ck));
        s.insert(QStringLiteral("nr"), s.value(QStringLiteral("nr")).toInteger() + 1);
    }
    auto [key, nonce] = msgKeyNonce(mk);
    auto pt = aeadDecrypt(b64d(env.value(QStringLiteral("c"))), b64d(s.value(QStringLiteral("ad"))) + h, nonce, key);
    if (!pt) {
        setErr(err, QStringLiteral("authentification du message impossible"));
        return std::nullopt;
    }
    const bool hasInitEk = !s.value(QStringLiteral("init_ek")).toString().isEmpty();
    if (env.value(QStringLiteral("type")).toString() == QLatin1String("msg") || hasInitEk)
        s.insert(QStringLiteral("pending"), QJsonValue::Null);
    return std::make_pair(*pt, s);
}

}  // namespace

// ------------------------------------------------------------------ DeviceKeys

DeviceKeys DeviceKeys::generate() {
    QByteArray pk(crypto_sign_PUBLICKEYBYTES, Qt::Uninitialized), sk(crypto_sign_SECRETKEYBYTES, Qt::Uninitialized);
    crypto_sign_keypair(W(pk), W(sk));
    DeviceKeys k(QJsonObject{{QStringLiteral("ik_sk"), b64e(sk)}, {QStringLiteral("ik_pk"), b64e(pk)},
                             {QStringLiteral("spk"), QJsonValue::Null}, {QStringLiteral("spk_prev"), QJsonValue::Null},
                             {QStringLiteral("opks"), QJsonObject{}}, {QStringLiteral("next_opk_id"), 1},
                             {QStringLiteral("next_spk_id"), 1}});
    sodium_memzero(sk.data(), size_t(sk.size()));
    k.rotateSignedPrekey();
    return k;
}

QByteArray DeviceKeys::identityPublic() const { return b64d(m_d.value(QStringLiteral("ik_pk"))); }
QByteArray DeviceKeys::identitySecret64() const { return b64d(m_d.value(QStringLiteral("ik_sk"))); }

qint64 DeviceKeys::signedPrekeyCreatedAt() const {
    return m_d.value(QStringLiteral("spk")).toObject().value(QStringLiteral("created")).toInteger();
}

QJsonObject DeviceKeys::rotateSignedPrekey() {
    auto [sk, pk] = x25519Keypair();
    const int id = int(m_d.value(QStringLiteral("next_spk_id")).toInteger(1));
    m_d.insert(QStringLiteral("next_spk_id"), id + 1);
    const QByteArray msg = kSpkPrefix + pk;
    QByteArray sig(crypto_sign_BYTES, Qt::Uninitialized);
    const QByteArray isk = identitySecret64();
    crypto_sign_detached(W(sig), nullptr, U(msg), size_t(msg.size()), U(isk));
    const QJsonObject spk{{QStringLiteral("id"), id}, {QStringLiteral("sk"), b64e(sk)}, {QStringLiteral("pk"), b64e(pk)},
                          {QStringLiteral("sig"), b64e(sig)}, {QStringLiteral("created"), QDateTime::currentSecsSinceEpoch()}};
    m_d.insert(QStringLiteral("spk_prev"), m_d.value(QStringLiteral("spk")));
    m_d.insert(QStringLiteral("spk"), spk);
    return spk;
}

QJsonArray DeviceKeys::newOneTimePrekeys(int count) {
    QJsonObject opks = m_d.value(QStringLiteral("opks")).toObject();
    int next = int(m_d.value(QStringLiteral("next_opk_id")).toInteger(1));
    QJsonArray out;
    for (int i = 0; i < count; ++i) {
        auto [sk, pk] = x25519Keypair();
        opks.insert(QString::number(next), b64e(sk));
        out.append(QJsonObject{{QStringLiteral("id"), next}, {QStringLiteral("key"), b64e(pk)}});
        ++next;
    }
    m_d.insert(QStringLiteral("opks"), opks);
    m_d.insert(QStringLiteral("next_opk_id"), next);
    return out;
}

QJsonObject DeviceKeys::publicUpload(const QJsonArray& opks) const {
    const auto spk = m_d.value(QStringLiteral("spk")).toObject();
    return {{QStringLiteral("spk_id"), spk.value(QStringLiteral("id"))}, {QStringLiteral("spk"), spk.value(QStringLiteral("pk"))},
            {QStringLiteral("spk_sig"), spk.value(QStringLiteral("sig"))}, {QStringLiteral("opks"), opks}};
}

std::optional<QByteArray> DeviceKeys::signedPrekeySecret(int id) const {
    for (const char* k : {"spk", "spk_prev"}) {
        const auto s = m_d.value(QLatin1String(k)).toObject();
        if (!s.isEmpty() && s.value(QStringLiteral("id")).toInt() == id) return b64d(s.value(QStringLiteral("sk")));
    }
    return std::nullopt;
}

std::optional<QByteArray> DeviceKeys::oneTimePrekeySecret(int id) const {
    const auto opks = m_d.value(QStringLiteral("opks")).toObject();
    const auto it = opks.constFind(QString::number(id));
    if (it == opks.constEnd()) return std::nullopt;
    return b64d(*it);
}

void DeviceKeys::dropOneTimePrekey(int id) {
    QJsonObject opks = m_d.value(QStringLiteral("opks")).toObject();
    opks.remove(QString::number(id));
    m_d.insert(QStringLiteral("opks"), opks);
}

// ------------------------------------------------------------------ sessions

bool verifyBundle(const QJsonObject& bundle) {
    const QByteArray ik = b64d(bundle.value(QStringLiteral("identity_key")));
    const QByteArray spk = b64d(bundle.value(QStringLiteral("spk")));
    const QByteArray sig = b64d(bundle.value(QStringLiteral("spk_sig")));
    if (ik.size() != 32 || spk.size() != 32 || sig.size() != crypto_sign_BYTES) return false;
    const QByteArray msg = kSpkPrefix + spk;
    return crypto_sign_verify_detached(U(sig), U(msg), size_t(msg.size()), U(ik)) == 0;
}

std::optional<QJsonObject> initiate(const DeviceKeys& me, const QJsonObject& bundle, QString* error) {
    if (!verifyBundle(bundle)) {
        setErr(error, QStringLiteral("signature de prékey invalide"));
        return std::nullopt;
    }
    const QByteArray theirIk = b64d(bundle.value(QStringLiteral("identity_key")));
    const QByteArray theirSpk = b64d(bundle.value(QStringLiteral("spk")));
    auto [ekSk, ekPk] = x25519Keypair();
    QList<QByteArray> parts{dh(edToXSk(me.identitySecret64()), theirSpk), dh(ekSk, edToXPk(theirIk)), dh(ekSk, theirSpk)};
    const QJsonValue opkId = bundle.value(QStringLiteral("opk_id"));
    const bool hasOpk = !opkId.isNull() && !opkId.isUndefined();
    if (hasOpk) parts.append(dh(ekSk, b64d(bundle.value(QStringLiteral("opk")))));
    for (const auto& p : parts)
        if (p.isEmpty()) {
            setErr(error, QStringLiteral("clé invalide dans le paquet"));
            return std::nullopt;
        }
    const QByteArray sk = x3dhSk(parts);
    auto [dhsSk, dhsPk] = x25519Keypair();
    auto [rk, cks] = kdfRk(sk, dh(dhsSk, theirSpk));
    QJsonObject pending{{QStringLiteral("ik"), b64e(me.identityPublic())}, {QStringLiteral("ek"), b64e(ekPk)},
                        {QStringLiteral("spk"), bundle.value(QStringLiteral("spk_id"))},
                        {QStringLiteral("opk"), hasOpk ? opkId : QJsonValue(QJsonValue::Null)}};
    return QJsonObject{{QStringLiteral("rk"), b64e(rk)},
                       {QStringLiteral("dhs_sk"), b64e(dhsSk)},
                       {QStringLiteral("dhs_pk"), b64e(dhsPk)},
                       {QStringLiteral("dhr"), b64e(theirSpk)},
                       {QStringLiteral("cks"), b64e(cks)},
                       {QStringLiteral("ckr"), QJsonValue::Null},
                       {QStringLiteral("ns"), 0},
                       {QStringLiteral("nr"), 0},
                       {QStringLiteral("pn"), 0},
                       {QStringLiteral("skipped"), QJsonObject{}},
                       {QStringLiteral("ad"), b64e(me.identityPublic() + theirIk)},
                       {QStringLiteral("peer_ik"), b64e(theirIk)},
                       {QStringLiteral("pending"), pending},
                       {QStringLiteral("init_ek"), QJsonValue::Null}};
}

std::optional<QJsonObject> encrypt(QJsonObject& s, const QByteArray& plaintext) {
    const QByteArray cks = b64d(s.value(QStringLiteral("cks")));
    if (cks.size() != 32) return std::nullopt;
    auto [ck, mk] = kdfCk(cks);
    s.insert(QStringLiteral("cks"), b64e(ck));
    const QByteArray h = headerBytes(b64d(s.value(QStringLiteral("dhs_pk"))), quint32(s.value(QStringLiteral("pn")).toInteger()),
                                     quint32(s.value(QStringLiteral("ns")).toInteger()));
    s.insert(QStringLiteral("ns"), s.value(QStringLiteral("ns")).toInteger() + 1);
    auto [key, nonce] = msgKeyNonce(mk);
    const QByteArray ct = aeadEncrypt(plaintext, b64d(s.value(QStringLiteral("ad"))) + h, nonce, key);
    const QJsonValue pending = s.value(QStringLiteral("pending"));
    const bool pre = pending.isObject();
    QJsonObject env{{QStringLiteral("v"), 2}, {QStringLiteral("type"), pre ? QStringLiteral("prekey") : QStringLiteral("msg")},
                    {QStringLiteral("h"), b64e(h)}, {QStringLiteral("c"), b64e(ct)}};
    if (pre) env.insert(QStringLiteral("x"), pending);
    return env;
}

std::optional<Decrypted> decrypt(const DeviceKeys& me, const QJsonObject& session, const QJsonObject& env, QString* error) {
    if (env.value(QStringLiteral("v")).toInt() != 2) {
        setErr(error, QStringLiteral("version d'enveloppe non prise en charge"));
        return std::nullopt;
    }
    if (env.value(QStringLiteral("type")).toString() == QLatin1String("prekey")) {
        const auto x = env.value(QStringLiteral("x")).toObject();
        if (!session.isEmpty() && session.value(QStringLiteral("init_ek")).toString() == x.value(QStringLiteral("ek")).toString()) {
            auto r = ratchetDecrypt(session, env, error);
            if (!r) return std::nullopt;
            return Decrypted{r->first, r->second};
        }
        const QByteArray theirIk = b64d(x.value(QStringLiteral("ik")));
        const QByteArray ek = b64d(x.value(QStringLiteral("ek")));
        const auto spkSk = me.signedPrekeySecret(x.value(QStringLiteral("spk")).toInt());
        if (!spkSk) {
            setErr(error, QStringLiteral("prékey signée inconnue"));
            return std::nullopt;
        }
        const QByteArray ikSk = edToXSk(me.identitySecret64());
        QList<QByteArray> parts{dh(*spkSk, edToXPk(theirIk)), dh(ikSk, ek), dh(*spkSk, ek)};
        const QJsonValue opk = x.value(QStringLiteral("opk"));
        int opkId = -1;
        if (!opk.isNull() && !opk.isUndefined()) {
            opkId = opk.toInt();
            const auto opkSk = me.oneTimePrekeySecret(opkId);
            if (!opkSk) {
                setErr(error, QStringLiteral("prékey à usage unique inconnue ou déjà utilisée"));
                return std::nullopt;
            }
            parts.append(dh(*opkSk, ek));
        }
        for (const auto& p : parts)
            if (p.isEmpty()) {
                setErr(error, QStringLiteral("clé invalide"));
                return std::nullopt;
            }
        QByteArray spkPk(32, Qt::Uninitialized);
        crypto_scalarmult_base(W(spkPk), U(*spkSk));
        QJsonObject fresh{{QStringLiteral("rk"), b64e(x3dhSk(parts))},
                          {QStringLiteral("dhs_sk"), b64e(*spkSk)},
                          {QStringLiteral("dhs_pk"), b64e(spkPk)},
                          {QStringLiteral("dhr"), QJsonValue::Null},
                          {QStringLiteral("cks"), QJsonValue::Null},
                          {QStringLiteral("ckr"), QJsonValue::Null},
                          {QStringLiteral("ns"), 0},
                          {QStringLiteral("nr"), 0},
                          {QStringLiteral("pn"), 0},
                          {QStringLiteral("skipped"), QJsonObject{}},
                          {QStringLiteral("ad"), b64e(theirIk + me.identityPublic())},
                          {QStringLiteral("peer_ik"), b64e(theirIk)},
                          {QStringLiteral("pending"), QJsonValue::Null},
                          {QStringLiteral("init_ek"), x.value(QStringLiteral("ek"))}};
        auto r = ratchetDecrypt(fresh, env, error);
        if (!r) return std::nullopt;
        return Decrypted{r->first, r->second, opkId >= 0, opkId};
    }
    if (session.isEmpty()) {
        setErr(error, QStringLiteral("aucune session pour cet appareil"));
        return std::nullopt;
    }
    auto r = ratchetDecrypt(session, env, error);
    if (!r) return std::nullopt;
    return Decrypted{r->first, r->second};
}

QByteArray peerIdentity(const QJsonObject& session) { return b64d(session.value(QStringLiteral("peer_ik"))); }

}  // namespace ngoma::ratchet
