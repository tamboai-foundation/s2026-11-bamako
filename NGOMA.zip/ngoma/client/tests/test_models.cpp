#include <QJsonArray>
#include <QJsonObject>
#include <QSignalSpy>
#include <QtTest>

#include "ui/ConversationListModel.h"
#include "ui/MessageListModel.h"

using namespace ngoma;

namespace {
QJsonObject msg(const char* cid, qint64 seq, qint64 sender, const char* state = "received") {
    return {{"client_id", cid}, {"seq", seq}, {"sender_id", sender}, {"body", QString("m%1").arg(seq)},
            {"state", state}, {"created_at", "2026-11-18T10:00:00.000Z"}};
}
}  // namespace

class TestModels : public QObject {
    Q_OBJECT
private slots:
    void mergeIsIncremental() {
        MessageListModel m;
        m.setContext(1, {});
        m.mergeLatest(QJsonArray{msg("a", 1, 2), msg("b", 2, 2)});
        QCOMPARE(m.rowCount(), 2);
        QSignalSpy inserted(&m, &QAbstractItemModel::rowsInserted);
        QSignalSpy reset(&m, &QAbstractItemModel::modelReset);
        m.mergeLatest(QJsonArray{msg("a", 1, 2), msg("b", 2, 2), msg("c", 3, 2)});
        QCOMPARE(m.rowCount(), 3);
        QCOMPARE(inserted.count(), 1);
        QCOMPARE(reset.count(), 0);
    }

    void pendingBecomesSentInPlace() {
        MessageListModel m;
        m.setContext(1, {});
        m.mergeLatest(QJsonArray{msg("a", 1, 2), msg("p", 0, 1, "pending")});
        QCOMPARE(m.data(m.index(1), MessageListModel::StateRole).toString(), QString("pending"));
        QSignalSpy changed(&m, &QAbstractItemModel::dataChanged);
        m.mergeLatest(QJsonArray{msg("a", 1, 2), msg("p", 2, 1, "sent")});
        QCOMPARE(m.rowCount(), 2);
        QCOMPARE(changed.count(), 1);
        QCOMPARE(m.data(m.index(1), MessageListModel::StateRole).toString(), QString("sent"));
        QVERIFY(m.data(m.index(1), MessageListModel::MineRole).toBool());
        m.setPeerReadSeq(2);
        QVERIFY(m.data(m.index(1), MessageListModel::ReadRole).toBool());
    }

    void prependOlderDeduplicates() {
        MessageListModel m;
        m.setContext(1, {});
        m.mergeLatest(QJsonArray{msg("c", 3, 2), msg("d", 4, 2)});
        m.prependOlder(QJsonArray{msg("a", 1, 2), msg("b", 2, 2), msg("c", 3, 2)});
        QCOMPARE(m.rowCount(), 4);
        QCOMPARE(m.oldestSeq(), 1);
        QCOMPARE(m.newestSeq(), 4);
    }

    void conversationTitleAndUnread() {
        ConversationListModel c;
        c.setMyUserId(1);
        QJsonArray members{QJsonObject{{"id", 1}, {"username", "moi"}},
                           QJsonObject{{"id", 2}, {"username", "bob"}, {"display_name", "Bob"}}};
        c.replace(QJsonArray{QJsonObject{{"id", "x"}, {"kind", "direct"}, {"title", ""}, {"members", members}, {"unread", 3}}});
        QCOMPARE(c.data(c.index(0), ConversationListModel::TitleRole).toString(), QString("Bob"));
        QCOMPARE(c.unreadTotal(), 3);
    }
};

QTEST_GUILESS_MAIN(TestModels)
#include "test_models.moc"
