import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Ngoma.Core

Page {
    id: page
    background: Rectangle { color: Theme.background }
    header: PageHeader { showBack: true; title: qsTr("Réglages"); onBack: page.StackView.view.pop() }

    Component.onCompleted: App.refreshAssistant()

    // Carte de section
    component Section: Rectangle {
        default property alias content: inner.data
        property string title
        property string iconName
        Layout.fillWidth: true
        implicitHeight: inner.implicitHeight + 40
        radius: Theme.radius
        color: Theme.surface
        border.color: Theme.outline
        ColumnLayout {
            id: inner
            anchors.fill: parent; anchors.margins: 20; spacing: 14
            RowLayout {
                spacing: 10
                Image { source: Theme.icon(iconName, "accent"); sourceSize: Qt.size(22, 22) }
                Text { text: title; color: Theme.text; font.pixelSize: Theme.fontLarge; font.weight: Font.DemiBold; Layout.fillWidth: true }
            }
        }
    }
    component FieldLabel: Text { color: Theme.textMuted; font.pixelSize: Theme.fontSmall; Layout.preferredWidth: 150 }

    Flickable {
        anchors.fill: parent
        contentHeight: column.implicitHeight + 48
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        ScrollIndicator.vertical: ScrollIndicator {}

        ColumnLayout {
            id: column
            width: Math.min(parent.width - 48, 860)
            x: (parent.width - width) / 2
            y: 24
            spacing: 18

            Section {
                title: qsTr("Ce terminal"); iconName: "lock"
                RowLayout {
                    spacing: 14
                    Avatar { name: App.myName; size: 48 }
                    ColumnLayout {
                        spacing: 2
                        Text { text: App.myName; color: Theme.text; font.pixelSize: Theme.fontBody; font.weight: Font.DemiBold }
                        Text { text: App.serverUrl; color: Theme.textMuted; font.pixelSize: Theme.fontSmall }
                    }
                }
                Text { text: qsTr("Numéro de sécurité"); color: Theme.textMuted; font.pixelSize: Theme.fontSmall }
                Rectangle {
                    Layout.fillWidth: true; height: 52; radius: Theme.radiusSmall; color: Theme.surfaceHigh
                    Text { anchors.centerIn: parent; text: App.mySafetyNumber; color: Theme.accent; font.pixelSize: 22; font.family: "monospace"; font.letterSpacing: 1 }
                }
                Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.textMuted; font.pixelSize: Theme.fontSmall
                       text: qsTr("Comparez ce numéro de vive voix avec vos contacts pour vérifier qu'aucun intermédiaire ne s'est interposé.") }
                Text { text: qsTr("Médias locaux (iceoryx2) : %1").arg(App.mediaAvailable ? qsTr("actifs") : qsTr("indisponibles"))
                       color: App.mediaAvailable ? Theme.accent : Theme.warning; font.pixelSize: Theme.fontSmall }
            }

            Section {
                title: qsTr("Assistant IA"); iconName: "sparkle"
                RowLayout {
                    Layout.fillWidth: true
                    Text { text: App.assistant.active ? qsTr("Activé") : qsTr("Désactivé"); color: App.assistant.active ? Theme.accent : Theme.textMuted; font.pixelSize: Theme.fontBody; Layout.fillWidth: true }
                }
                Rectangle {
                    Layout.fillWidth: true; radius: Theme.radiusSmall; color: Theme.warningSoft
                    implicitHeight: warnRow.implicitHeight + 24
                    RowLayout {
                        id: warnRow
                        anchors.fill: parent; anchors.margins: 12; spacing: 10
                        Image { source: Theme.icon("alert", "light"); sourceSize: Qt.size(20, 20); Layout.alignment: Qt.AlignTop }
                        Text { Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.text; font.pixelSize: Theme.fontSmall
                               text: qsTr("Les messages envoyés à l'assistant sont déchiffrés sur le serveur NGOMA puis transmis au fournisseur d'IA choisi. Vos autres conversations restent chiffrées de bout en bout.") }
                    }
                }
                GridLayout {
                    columns: 2; columnSpacing: 16; rowSpacing: 10; Layout.fillWidth: true
                    FieldLabel { text: qsTr("Fournisseur") }
                    ComboBox {
                        id: provider; Layout.fillWidth: true; implicitHeight: Theme.touch
                        model: [{ text: "Anthropic (Claude)", value: "anthropic" }, { text: qsTr("Compatible OpenAI"), value: "openai" }]
                        textRole: "text"; valueRole: "value"
                        font.pixelSize: Theme.fontBody
                        Component.onCompleted: currentIndex = Math.max(0, indexOfValue(App.assistant.provider || "anthropic"))
                        background: Rectangle { radius: Theme.radiusSmall; color: Theme.surfaceHigh; border.color: provider.activeFocus ? Theme.accent : Theme.outline; border.width: provider.activeFocus ? 2 : 1 }
                        contentItem: Text { leftPadding: 16; text: provider.displayText; color: Theme.text; font: provider.font; verticalAlignment: Text.AlignVCenter }
                    }
                    FieldLabel { text: qsTr("Modèle") }
                    AppTextField { id: modelField; Layout.fillWidth: true; text: App.assistant.model || ""
                                   placeholderText: provider.currentValue === "anthropic" ? "claude-sonnet-5-5" : qsTr("nom du modèle") }
                    FieldLabel { text: qsTr("Clé API") }
                    AppTextField { id: apiKey; Layout.fillWidth: true; echoMode: TextInput.Password
                                   placeholderText: App.assistant.api_key_set ? qsTr("•••• enregistrée (laisser vide pour conserver)") : qsTr("obligatoire") }
                    FieldLabel { text: qsTr("URL (optionnelle)") }
                    AppTextField { id: baseUrl; Layout.fillWidth: true; text: App.assistant.base_url || ""; placeholderText: "https://…"
                                   inputMethodHints: Qt.ImhUrlCharactersOnly }
                    FieldLabel { text: qsTr("Consignes") }
                    AppTextField { id: prompt; Layout.fillWidth: true; text: App.assistant.system_prompt || ""; placeholderText: qsTr("ex. Réponds en français, brièvement.") }
                }
                Text { visible: (App.assistant.last_error || "").length > 0; text: qsTr("Dernière erreur : %1").arg(App.assistant.last_error || ""); color: Theme.danger; font.pixelSize: Theme.fontSmall }
                RowLayout {
                    Layout.fillWidth: true; spacing: 12
                    AppButton {
                        Layout.fillWidth: true; variant: "primary"
                        text: App.assistant.active ? qsTr("Enregistrer") : qsTr("Activer l'assistant")
                        enabled: !App.busy && modelField.text.trim().length > 0 && (apiKey.text.length > 0 || App.assistant.api_key_set)
                        onClicked: { App.configureAssistant(provider.currentValue, modelField.text, apiKey.text, baseUrl.text, prompt.text); apiKey.text = "" }
                    }
                    AppButton { visible: App.assistant.active === true; variant: "secondary"; text: qsTr("Désactiver"); onClicked: App.disableAssistant() }
                }
            }

            AppButton { Layout.fillWidth: true; variant: "danger"; text: qsTr("Déconnecter ce terminal"); onClicked: confirm.open() }
        }
    }

    Dialog {
        id: confirm
        anchors.centerIn: parent
        modal: true
        width: Math.min(page.width - 64, 520)
        padding: 24
        background: Rectangle { radius: Theme.radius; color: Theme.surface; border.color: Theme.outlineStrong }
        header: Text { text: qsTr("Déconnecter ce terminal ?"); color: Theme.text; font.pixelSize: Theme.fontLarge; font.weight: Font.DemiBold; padding: 24; bottomPadding: 0 }
        Overlay.modal: Rectangle { color: "#b3000000" }
        ColumnLayout {
            anchors.fill: parent; spacing: 12
            Text { text: qsTr("Le jeton et les clés privées seront effacés. Effacer aussi l'historique local ?"); color: Theme.textMuted; wrapMode: Text.Wrap; Layout.fillWidth: true; font.pixelSize: Theme.fontSmall + 1 }
            AppButton { text: qsTr("Déconnecter et effacer l'historique"); variant: "danger"; Layout.fillWidth: true; onClicked: { confirm.close(); App.logout(true) } }
            AppButton { text: qsTr("Déconnecter, garder l'historique"); variant: "secondary"; Layout.fillWidth: true; onClicked: { confirm.close(); App.logout(false) } }
            AppButton { text: qsTr("Annuler"); variant: "ghost"; Layout.fillWidth: true; onClicked: confirm.close() }
        }
    }
}
