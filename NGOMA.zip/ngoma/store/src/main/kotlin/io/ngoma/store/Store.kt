package io.ngoma.store

import ai.tambo.tmodeler.field.operation.*
import ai.tambo.tmodeler.ms.ext.*
import ai.tambo.tmodeler.scheduler.TGate
import ai.tambo.tmodeler.scheduler.TmsScope
import io.ngoma.store.models.ChatMessage
import io.ngoma.store.models.Conversation
import io.ngoma.store.models.Setting
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.*

/** Exécute [block] dans le contexte de données T-Modeler et attend le résultat (même schéma que les tests T-Modeler). */
fun <R> inData(block: suspend context(TmsScope) () -> R): R = runBlocking {
    TGate.dataResult { relay(block) }
}

context(TmsScope)
private suspend fun <R> relay(block: suspend context(TmsScope) () -> R): R = block(this@TmsScope)

/** Toutes les opérations métier sur la base locale. Chaque fonction exige le contexte de données. */
object Store {

    fun commitSchema() = inData {
        Conversation.tms.commit()
        ChatMessage.tms.commit()
        Setting.tms.commit()
    }

    // ------------------------------------------------------------ réglages
    context(TmsScope)
    fun getSetting(key: String): String? =
        Setting.tms.build { filter(it.key eq key) }.firstOrNull()?.value_

    context(TmsScope)
    fun setSetting(key: String, value: String) {
        val s = Setting.tms.build { filter(it.key eq key) }.firstOrNull() ?: Setting().also { it.key_ = key }
        s.value_ = value
        s.save()
    }

    // ------------------------------------------------------------ conversations
    context(TmsScope)
    fun findConversation(remoteId: String): Conversation? =
        Conversation.tms.build { filter(it.remoteId eq remoteId) }.firstOrNull()

    context(TmsScope)
    fun upsertConversations(items: JsonArray): Int {
        var n = 0
        for (el in items) {
            val o = el.jsonObject
            val rid = o.str("id") ?: continue
            val c = findConversation(rid) ?: Conversation().also { it.remoteId_ = rid }
            c.kind_ = o.str("kind") ?: c.kind_
            c.title_ = o.str("title") ?: c.title_
            o["members"]?.let { c.membersJson_ = it.toString() }
            o.long("last_seq")?.let { if (it > c.serverSeq_) c.serverSeq_ = it }
            c.updatedAt_ = o.str("updated_at") ?: c.updatedAt_
            c.save()
            n++
        }
        return n
    }

    context(TmsScope)
    fun setServerSeq(remoteId: String, seq: Long): Boolean {
        val c = findConversation(remoteId) ?: return false
        if (seq > c.serverSeq_) { c.serverSeq_ = seq; c.save() }
        return true
    }

    context(TmsScope)
    fun setPulled(remoteId: String, seq: Long, updatedAt: String?) {
        val c = findConversation(remoteId) ?: return
        if (seq > c.pulledSeq_) c.pulledSeq_ = seq
        if (seq > c.serverSeq_) c.serverSeq_ = seq
        if (!updatedAt.isNullOrEmpty()) c.updatedAt_ = updatedAt
        c.save()
    }

    context(TmsScope)
    fun setRead(remoteId: String, seq: Long) {
        val c = findConversation(remoteId) ?: return
        if (seq > c.readSeq_) { c.readSeq_ = seq; c.save() }
    }

    context(TmsScope)
    fun setPeerRead(remoteId: String, seq: Long) {
        val c = findConversation(remoteId) ?: return
        if (seq > c.peerReadSeq_) { c.peerReadSeq_ = seq; c.save() }
    }

    context(TmsScope)
    fun setDraft(remoteId: String, text: String) {
        val c = findConversation(remoteId) ?: return
        c.draft_ = text
        c.save()
    }

    context(TmsScope)
    fun listConversations(): JsonArray {
        val t = Conversation.tms.lambda
        val rows = Conversation.tms.with(t).lazy().order(-t.updatedAt).build()
        return JsonArray(rows.map { c ->
            val last = lastMessage(c.remoteId_)
            buildJsonObject {
                put("id", c.remoteId_)
                put("kind", c.kind_)
                put("title", c.title_)
                put("members", runCatching { Json.parseToJsonElement(c.membersJson_) }.getOrDefault(JsonArray(emptyList())))
                put("server_seq", c.serverSeq_)
                put("pulled_seq", c.pulledSeq_)
                put("read_seq", c.readSeq_)
                put("peer_read_seq", c.peerReadSeq_)
                put("unread", maxOf(0L, c.pulledSeq_ - c.readSeq_))
                put("updated_at", c.updatedAt_)
                put("draft", c.draft_)
                put("last_body", last?.body_ ?: "")
                put("last_at", last?.createdAt_ ?: "")
            }
        })
    }

    // ------------------------------------------------------------ messages
    context(TmsScope)
    private fun byClientId(clientId: String): ChatMessage? =
        ChatMessage.tms.build { filter(it.clientId eq clientId) }.firstOrNull()

    context(TmsScope)
    private fun lastMessage(messagingId: String): ChatMessage? {
        val t = ChatMessage.tms.lambda
        return ChatMessage.tms.with(t).lazy().filter(t.messagingId eq messagingId).order(-t._id).sub(1, 0).build()
            .firstOrNull()
    }

    context(TmsScope)
    fun insertOutgoing(o: JsonObject): JsonObject {
        val cid = o.str("client_id") ?: error("client_id requis")
        byClientId(cid)?.let { return it.toJson() }
        val m = ChatMessage().also {
            it.clientId_ = cid
            it.messagingId_ = o.str("messaging_id") ?: error("messaging_id requis")
            it.senderId_ = o.long("sender_id") ?: 0L
            it.kind_ = o.str("kind") ?: "text"
            it.body_ = o.str("body") ?: ""
            it.state_ = "pending"
            it.createdAt_ = o.str("created_at") ?: ""
            it.expiresAt_ = o.str("expires_at") ?: ""
            it.meta_ = o.str("meta") ?: ""
        }
        m.save()
        return m.toJson()
    }

    context(TmsScope)
    fun markSent(o: JsonObject): Boolean {
        val m = byClientId(o.str("client_id") ?: return false) ?: return false
        m.state_ = "sent"
        m.seq_ = o.long("seq") ?: m.seq_
        m.remoteId_ = o.str("remote_id") ?: m.remoteId_
        o.str("created_at")?.let { m.createdAt_ = it }
        m.save()
        return true
    }

    /** Métadonnées locales d'une pièce jointe (ex. chemin du fichier déchiffré après téléchargement). */
    context(TmsScope)
    fun setMeta(clientId: String, meta: String): Boolean {
        val m = byClientId(clientId) ?: return false
        m.meta_ = meta
        m.save()
        return true
    }

    context(TmsScope)
    fun markFailed(clientId: String, permanent: Boolean): Boolean {
        val m = byClientId(clientId) ?: return false
        m.attempts_ = m.attempts_ + 1
        if (permanent) m.state_ = "failed"
        m.save()
        return true
    }

    /** Messages reçus via pull, déjà déchiffrés par le cœur C++. Idempotent sur client_id. */
    context(TmsScope)
    fun upsertReceived(messagingId: String, items: JsonArray, myUserId: Long): Int {
        var n = 0
        for (el in items) {
            val o = el.jsonObject
            val cid = o.str("client_id") ?: continue
            val m = byClientId(cid) ?: ChatMessage().also { it.clientId_ = cid }
            m.messagingId_ = messagingId
            m.remoteId_ = o.str("remote_id") ?: m.remoteId_
            m.seq_ = o.long("seq") ?: m.seq_
            m.senderId_ = o.long("sender_id") ?: m.senderId_
            m.kind_ = o.str("kind") ?: "text"
            if (m.body_.isEmpty() || m.state_ == "received") {
                m.body_ = o.str("body") ?: ""
                o.str("meta")?.takeIf { it.isNotEmpty() }?.let { m.meta_ = it }
            }
            m.state_ = if (m.senderId_ == myUserId) "sent" else "received"
            m.createdAt_ = o.str("created_at") ?: m.createdAt_
            m.expiresAt_ = o.str("expires_at") ?: ""
            m.save()
            n++
        }
        return n
    }

    /** Page de messages en ordre chronologique. beforeSeq = 0 → la fin de la conversation (+ messages en attente). */
    context(TmsScope)
    fun listMessages(messagingId: String, beforeSeq: Long, limit: Int): JsonArray {
        val t = ChatMessage.tms.lambda
        val cond = if (beforeSeq > 0) (t.messagingId eq messagingId) and (t.seq gt 0L) and (t.seq lt beforeSeq)
        else (t.messagingId eq messagingId) and (t.seq gt 0L)
        val page = ChatMessage.tms.with(t).lazy().filter(cond).order(-t.seq).sub(limit, 0).build().reversed()
        val pending = if (beforeSeq > 0) emptyList() else {
            val p = ChatMessage.tms.lambda
            ChatMessage.tms.with(p).lazy().filter((p.messagingId eq messagingId) and (p.seq eq 0L)).order(+p._id).build()
        }
        return JsonArray((page + pending).map { it.toJson() })
    }

    context(TmsScope)
    fun pendingOutbox(limit: Int): JsonArray {
        val t = ChatMessage.tms.lambda
        val rows = ChatMessage.tms.with(t).lazy().filter(t.state eq "pending").order(+t._id).sub(limit, 0).build()
        return JsonArray(rows.map { it.toJson() })
    }

    context(TmsScope)
    fun search(q: String, limit: Int): JsonArray {
        if (q.length < 2) return JsonArray(emptyList())
        val pattern = "%" + q.replace("%", "").replace("_", "") + "%"
        val t = ChatMessage.tms.lambda
        val rows = ChatMessage.tms.with(t).lazy().filter(t.body like pattern).order(-t._id).sub(limit, 0).build()
        return JsonArray(rows.map { it.toJson() })
    }

    /** Supprime les messages éphémères expirés (ISO-8601 UTC : comparaison lexicographique valide). */
    context(TmsScope)
    fun purgeExpired(nowIso: String): Int {
        val t = ChatMessage.tms.lambda
        val rows = ChatMessage.tms.with(t).lazy().filter((t.expiresAt ne "") and (t.expiresAt lt nowIso)).build()
        rows.forEach { it.delete() }
        return rows.size
    }

    context(TmsScope)
    fun wipe() {
        ChatMessage.tms.clear()
        Conversation.tms.clear()
        Setting.tms.clear()
    }
}

// ------------------------------------------------------------ utilitaires JSON
internal fun JsonObject.str(k: String): String? = (this[k] as? JsonPrimitive)?.takeIf { it !is JsonNull }?.contentOrNull
internal fun JsonObject.long(k: String): Long? = (this[k] as? JsonPrimitive)?.takeIf { it !is JsonNull }?.longOrNull

internal fun ChatMessage.toJson() = buildJsonObject {
    put("client_id", clientId_)
    put("remote_id", remoteId_)
    put("messaging_id", messagingId_)
    put("seq", seq_)
    put("sender_id", senderId_)
    put("kind", kind_)
    put("body", body_)
    put("state", state_)
    put("created_at", createdAt_)
    put("expires_at", expiresAt_)
    put("meta", meta_)
}
