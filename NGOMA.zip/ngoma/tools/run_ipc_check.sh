#!/usr/bin/env bash
# Vérifie le bus iceoryx2 : lance ngoma-media puis le test integration_ipc.
set -euo pipefail
BUILD="${1:?dossier de build du client}"
NGOMA_CAMERA="${NGOMA_CAMERA:-/dev/null-no-camera}" "$BUILD/ngoma-media" &
MEDIA=$!
trap 'kill $MEDIA 2>/dev/null || true' EXIT
sleep 0.5
"$BUILD/integration_ipc"
