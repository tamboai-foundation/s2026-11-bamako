// Ngoma — format des paquets média (terminal ↔ ngoma-relay ↔ terminal). Partagé par le relais.
//
// En-tête visible du relais (20 octets) : 'F' 'R' | version (1) | type (1) | call_id (16)
//   JOIN      (1) : + user_id (8, BE) + device_id (16) + exp (8, BE) + jeton HMAC-SHA256 (32)
//   DATA      (2) : + device_id émetteur (16) + charge chiffrée de bout en bout (opaque pour le relais)
//   LEAVE     (3) : + device_id (16)
//   KEEPALIVE (4) : + device_id (16)
//   JOIN_ACK  (5) : + nombre de membres (1)                      (relais → terminal)
//   JOIN_NACK (6) : + raison (1)                                 (relais → terminal)
//
// Charge DATA (chiffrée, clé d'appel E2EE) : seq (8, BE) | kind (1) | ChaCha20-Poly1305-IETF(clair)
//   nonce (12) = kind | 0 0 0 | seq (8, BE) ; AD = en-tête (20) + device_id (16) + seq (8) + kind (1)
//   clé d'émission = HKDF-SHA256(clé d'appel, sel nul, info = "NGM-media-v1" || device_id émetteur, 32)
#pragma once

#include <array>
#include <cstdint>
#include <cstring>

namespace ngoma::wire {

constexpr std::uint8_t kMagic0 = 'F', kMagic1 = 'R', kVersion = 1;
constexpr std::size_t kHeader = 20;
constexpr std::size_t kMaxPacket = 1400;
constexpr std::size_t kMaxMembers = 8;

enum Type : std::uint8_t { Join = 1, Data = 2, Leave = 3, Keepalive = 4, JoinAck = 5, JoinNack = 6 };
enum Kind : std::uint8_t { Audio = 1, Video = 2, Control = 3 };
enum Control : std::uint8_t { KeyframeRequest = 1 };

using Uuid = std::array<std::uint8_t, 16>;

inline void putBe(std::uint8_t* p, std::uint64_t v, int bytes) {
    for (int i = bytes - 1; i >= 0; --i) {
        p[i] = std::uint8_t(v & 0xFF);
        v >>= 8;
    }
}
inline std::uint64_t getBe(const std::uint8_t* p, int bytes) {
    std::uint64_t v = 0;
    for (int i = 0; i < bytes; ++i) v = (v << 8) | p[i];
    return v;
}

inline bool parseUuid(const char* text, Uuid& out) {
    int n = 0;
    for (const char* c = text; *c && n < 32; ++c) {
        int v;
        if (*c >= '0' && *c <= '9') v = *c - '0';
        else if (*c >= 'a' && *c <= 'f') v = *c - 'a' + 10;
        else if (*c >= 'A' && *c <= 'F') v = *c - 'A' + 10;
        else if (*c == '-') continue;
        else return false;
        if (n % 2 == 0) out[size_t(n / 2)] = std::uint8_t(v << 4);
        else out[size_t(n / 2)] |= std::uint8_t(v);
        ++n;
    }
    return n == 32;
}

inline void header(std::uint8_t* p, Type t, const Uuid& call) {
    p[0] = kMagic0;
    p[1] = kMagic1;
    p[2] = kVersion;
    p[3] = t;
    std::memcpy(p + 4, call.data(), 16);
}

inline bool validHeader(const std::uint8_t* p, std::size_t len) {
    return len >= kHeader && p[0] == kMagic0 && p[1] == kMagic1 && p[2] == kVersion;
}

}  // namespace ngoma::wire
