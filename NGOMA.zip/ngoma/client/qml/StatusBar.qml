import QtQuick
import QtQuick.Layouts
import Ngoma.Core

Rectangle {
    height: 32
    color: Theme.background

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 20
        anchors.rightMargin: 20
        spacing: 10
        Text { text: Theme.brand; color: Theme.textMuted; font.pixelSize: Theme.fontSmall; font.weight: Font.Bold; font.letterSpacing: 2 }
        Item { Layout.fillWidth: true }
        Image { visible: App.state === "ready"; source: Theme.icon("lock", "muted"); sourceSize: Qt.size(14, 14) }
        Text {
            visible: App.state === "ready"
            text: !App.storeReady ? qsTr("Stockage local indisponible")
                 : App.syncing ? qsTr("Synchronisation…")
                 : App.online ? qsTr("En ligne") : qsTr("Hors ligne · envoi à la reconnexion")
            color: !App.storeReady ? Theme.danger : (App.online ? Theme.accent : Theme.warning)
            font.pixelSize: Theme.fontSmall
        }
        Rectangle { width: 8; height: 8; radius: 4; color: App.online ? Theme.accent : Theme.warning; visible: App.state === "ready" }
        Text {
            id: clock
            color: Theme.textMuted; font.pixelSize: Theme.fontSmall
            Timer { interval: 10000; running: true; repeat: true; triggeredOnStart: true
                    onTriggered: clock.text = Qt.formatTime(new Date(), "HH:mm") }
        }
    }
}
