#include "RealtimeClient.h"

#include <QDateTime>
#include <QJsonDocument>
#include <QNetworkRequest>
#include <QRandomGenerator>
#include <algorithm>

namespace ngoma {

namespace {
constexpr int kPingMs = 25000;
constexpr int kDeadMs = 70000;  // aucun trafic depuis 70 s → connexion considérée morte
constexpr int kMaxBackoffMs = 30000;
}  // namespace

RealtimeClient::RealtimeClient(const Config& cfg, const QSslConfiguration& ssl, QObject* parent)
    : QObject(parent), m_cfg(cfg), m_ssl(ssl) {
    m_ws.setMaxAllowedIncomingMessageSize(256 * 1024);
    m_ping.setInterval(kPingMs);
    m_watchdog.setInterval(kDeadMs);
    m_watchdog.setSingleShot(true);
    m_reconnect.setSingleShot(true);

    connect(&m_ws, &QWebSocket::connected, this, [this] {
        m_attempt = 0;
        m_connected = true;
        m_ping.start();
        m_watchdog.start();
        emit connectedChanged(true);
    });
    connect(&m_ws, &QWebSocket::disconnected, this, [this] {
        const auto code = m_ws.closeCode();
        const bool was = m_connected;
        m_connected = false;
        m_ping.stop();
        m_watchdog.stop();
        if (was) emit connectedChanged(false);
        if (int(code) == 4401 || int(code) == 4403) {
            emit revoked();
            m_running = false;
            return;
        }
        scheduleReconnect();
    });
    connect(&m_ws, &QWebSocket::textMessageReceived, this, &RealtimeClient::onText);
    connect(&m_ws, &QWebSocket::pong, this, [this](quint64, const QByteArray&) { m_watchdog.start(); });
    connect(&m_ping, &QTimer::timeout, this, [this] {
        m_ws.ping();
        send({{QStringLiteral("type"), QStringLiteral("ping")}, {QStringLiteral("t"), QDateTime::currentMSecsSinceEpoch()}});
    });
    connect(&m_watchdog, &QTimer::timeout, this, [this] { m_ws.abort(); });
    connect(&m_reconnect, &QTimer::timeout, this, &RealtimeClient::openSocket);
}

RealtimeClient::~RealtimeClient() {
    // La destruction du socket émet « disconnected » : on coupe d'abord nos connexions pour que les
    // gestionnaires ne touchent pas des minuteurs déjà détruits.
    m_running = false;
    m_ws.disconnect(this);
    m_ws.abort();
}

void RealtimeClient::start(const QString& token) {
    m_token = token;
    m_running = true;
    m_attempt = 0;
    openSocket();
}

void RealtimeClient::stop() {
    m_running = false;
    m_reconnect.stop();
    m_ws.close();
}

void RealtimeClient::openSocket() {
    if (!m_running) return;
    QNetworkRequest req(m_cfg.realtimeUrl());
    req.setRawHeader("Authorization", "Device " + m_token.toLatin1());
    if (req.url().scheme() == QLatin1String("wss")) m_ws.setSslConfiguration(m_ssl);
    m_ws.open(req);
}

void RealtimeClient::scheduleReconnect() {
    if (!m_running) return;
    const int base = std::min(kMaxBackoffMs, 1000 * (1 << std::min(m_attempt, 5)));
    const int jitter = int(QRandomGenerator::global()->bounded(base / 2 + 1));
    ++m_attempt;
    m_reconnect.start(base / 2 + jitter);
}

void RealtimeClient::send(const QJsonObject& obj) {
    if (m_connected) m_ws.sendTextMessage(QString::fromUtf8(QJsonDocument(obj).toJson(QJsonDocument::Compact)));
}

void RealtimeClient::onText(const QString& text) {
    m_watchdog.start();
    const auto doc = QJsonDocument::fromJson(text.toUtf8());
    if (doc.isObject()) emit eventReceived(doc.object());
}

}  // namespace ngoma
