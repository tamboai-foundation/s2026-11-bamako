from django.contrib import admin

from .models import Membership, Message, Messaging


class MembershipInline(admin.TabularInline):
    model = Membership
    extra = 0


@admin.register(Messaging)
class MessagingAdmin(admin.ModelAdmin):
    list_display = ("id", "kind", "title", "last_seq", "updated_at")
    list_filter = ("kind",)
    inlines = [MembershipInline]


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    # Le contenu est chiffré : l'admin ne voit que les métadonnées.
    list_display = ("messaging", "seq", "sender", "kind", "created_at", "expires_at")
    readonly_fields = [f.name for f in Message._meta.fields]
