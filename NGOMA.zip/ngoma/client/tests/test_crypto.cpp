#include <QRegularExpression>
#include <QSet>
#include <QtTest>

#include "core/Crypto.h"
#include "core/Uuid7.h"

using namespace ngoma;

class TestCrypto : public QObject {
    Q_OBJECT
private slots:
    void initTestCase() { QVERIFY(Crypto::init()); }

    void roundTrip() {
        QByteArray apk, ask, bpk, bsk;
        QVERIFY(Crypto::generateKeyPair(apk, ask));
        QVERIFY(Crypto::generateKeyPair(bpk, bsk));
        const QByteArray msg = QStringLiteral("Bonjour, ceci est chiffré ✓").toUtf8();
        const auto sealed = Crypto::seal(msg, bpk, ask);
        QVERIFY(sealed.has_value());
        const auto opened = Crypto::open(sealed->nonceB64, sealed->ciphertextB64, apk, bsk);
        QVERIFY(opened.has_value());
        QCOMPARE(*opened, msg);
    }

    void rejectsWrongSenderOrTamper() {
        QByteArray apk, ask, bpk, bsk, mpk, msk;
        Crypto::generateKeyPair(apk, ask);
        Crypto::generateKeyPair(bpk, bsk);
        Crypto::generateKeyPair(mpk, msk);
        const auto sealed = Crypto::seal("secret", bpk, ask);
        QVERIFY(!Crypto::open(sealed->nonceB64, sealed->ciphertextB64, mpk, bsk).has_value());  // usurpation
        QByteArray ct = QByteArray::fromBase64(sealed->ciphertextB64.toLatin1());
        ct[0] = char(ct[0] ^ 0x01);
        QVERIFY(!Crypto::open(sealed->nonceB64, QString::fromLatin1(ct.toBase64()), apk, bsk).has_value());  // altération
        QVERIFY(!Crypto::open(QStringLiteral("AAAA"), sealed->ciphertextB64, apk, bsk).has_value());           // nonce invalide
    }

    void fingerprintStable() {
        QByteArray pk, sk;
        Crypto::generateKeyPair(pk, sk);
        QCOMPARE(Crypto::fingerprint(pk), Crypto::fingerprint(pk));
        QCOMPARE(Crypto::fingerprint(pk).split(QLatin1Char(' ')).size(), 8);
    }

    void uuid7FormatAndOrder() {
        static const QRegularExpression re(QStringLiteral("^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"));
        QSet<QString> seen;
        QString prev;
        for (int i = 0; i < 2000; ++i) {
            const QString u = uuid7();
            QVERIFY2(re.match(u).hasMatch(), qPrintable(u));
            QVERIFY(!seen.contains(u));
            seen.insert(u);
            QVERIFY(u.left(13) >= prev.left(13));  // préfixe temporel non décroissant
            prev = u;
        }
    }
};

QTEST_GUILESS_MAIN(TestCrypto)
#include "test_crypto.moc"
