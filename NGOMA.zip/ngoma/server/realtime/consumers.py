"""Canal temps réel d'un appareil.

Serveur → client (`{"event": ...}`) :
  hello, message, conversation, receipt, typing, presence, call.signal, pong
Client → serveur (`{"type": ...}`) :
  ping, typing, presence.query, call.signal

Aucune donnée de message ne transite ici : seulement des signaux (le client relit via /sync/pull).
La signalisation d'appel (offre/réponse SDP, candidats ICE) est relayée telle quelle entre membres
d'une même conversation ; le contenu SDP est opaque pour le serveur.
"""
import json
import time

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from django.conf import settings
from django.core.cache import cache

from messaging.models import Membership

from .events import device_group, user_group

MAX_FRAME = 64 * 1024


def presence_key(user_id: int) -> str:
    return f"presence:{user_id}"


@database_sync_to_async
def member_ids(messaging_id, user_id):
    ids = list(Membership.objects.filter(messaging_id=messaging_id).values_list("user_id", flat=True))
    return ids if user_id in ids else None


class RealtimeConsumer(AsyncJsonWebsocketConsumer):
    async def connect(self):
        self.device = self.scope.get("device")
        if self.device is None:
            await self.close(code=4401)
            return
        self.user_id = self.device.user_id
        self.groups_joined = [user_group(self.user_id), device_group(self.device.pk)]
        for g in self.groups_joined:
            await self.channel_layer.group_add(g, self.channel_name)
        self._typing_last = {}
        await self.accept()
        await self._touch_presence()
        await self.send_json({"event": "hello", "user_id": self.user_id, "device_id": str(self.device.pk),
                              "server_time": time.time()})

    async def disconnect(self, code):
        for g in getattr(self, "groups_joined", []):
            await self.channel_layer.group_discard(g, self.channel_name)

    async def receive(self, text_data=None, bytes_data=None, **kwargs):
        if text_data is None or len(text_data) > MAX_FRAME:
            await self.close(code=4413)
            return
        try:
            content = json.loads(text_data)
        except ValueError:
            return
        if isinstance(content, dict):
            await self.receive_json(content)

    async def receive_json(self, content, **kwargs):
        kind = content.get("type")
        await self._touch_presence()
        if kind == "ping":
            await self.send_json({"event": "pong", "t": content.get("t")})
        elif kind == "typing":
            await self._typing(content)
        elif kind == "presence.query":
            await self._presence(content)
        elif kind == "call.signal":
            await self._call_signal(content)

    # ---- actions client
    async def _typing(self, content):
        mid = content.get("messaging_id")
        now = time.monotonic()
        if not mid or now - self._typing_last.get(mid, 0) < 2.0:  # anti-rafale
            return
        self._typing_last[mid] = now
        ids = await member_ids(mid, self.user_id)
        if ids is None:
            return
        data = {"event": "typing", "messaging_id": mid, "user_id": self.user_id}
        for uid in ids:
            if uid != self.user_id:
                await self.channel_layer.group_send(user_group(uid), {"type": "ngoma.event", "data": data})

    async def _presence(self, content):
        ids = [int(i) for i in content.get("user_ids", [])[:200] if str(i).isdigit()]
        values = await cache.aget_many([presence_key(i) for i in ids])
        online = {i: presence_key(i) in values for i in ids}
        await self.send_json({"event": "presence", "online": online})

    async def _call_signal(self, content):
        mid = content.get("messaging_id")
        to_user = content.get("to_user_id")
        payload = content.get("payload")
        if not mid or not isinstance(to_user, int) or not isinstance(payload, dict):
            return
        ids = await member_ids(mid, self.user_id)
        if ids is None or to_user not in ids:
            return
        data = {"event": "call.signal", "messaging_id": mid, "from_user_id": self.user_id,
                "from_device_id": str(self.device.pk), "payload": payload}
        await self.channel_layer.group_send(user_group(to_user), {"type": "ngoma.event", "data": data})

    async def _touch_presence(self):
        await cache.aset(presence_key(self.user_id), 1, timeout=settings.NGOMA["PRESENCE_TTL_SECONDS"])

    # ---- événements du channel layer
    async def ngoma_event(self, message):
        await self.send_json(message["data"])

    async def ngoma_kick(self, _message):
        await self.close(code=4403)
