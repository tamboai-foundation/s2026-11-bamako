import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Ngoma.Core

Page {
    background: Rectangle { color: Theme.background }
    property bool creating: false

    Rectangle {
        anchors.centerIn: parent
        width: Math.min(parent.width - 64, 520)
        height: form.implicitHeight + 64
        radius: Theme.radius + 4
        color: Theme.surface
        border.color: Theme.outline

        ColumnLayout {
            id: form
            anchors.fill: parent
            anchors.margins: 32
            spacing: 14

            RowLayout {
                spacing: 12
                Rectangle {
                    width: 44; height: 44; radius: 12; color: Theme.accentSoft
                    Image { anchors.centerIn: parent; source: Theme.icon("lock", "accent"); sourceSize: Qt.size(24, 24) }
                }
                ColumnLayout {
                    spacing: 2
                    Text { text: creating ? qsTr("Créer un compte") : qsTr("Enrôler ce terminal"); color: Theme.text; font.pixelSize: Theme.fontTitle; font.weight: Font.DemiBold }
                    Text { text: App.serverUrl; color: Theme.textMuted; font.pixelSize: Theme.fontSmall; elide: Text.ElideMiddle; Layout.maximumWidth: 380 }
                }
            }

            AppTextField { id: user; placeholderText: qsTr("Identifiant"); Layout.fillWidth: true
                           inputMethodHints: Qt.ImhNoAutoUppercase | Qt.ImhNoPredictiveText }
            AppTextField { id: display; visible: creating; placeholderText: qsTr("Nom affiché"); Layout.fillWidth: true }
            AppTextField { id: pass; placeholderText: qsTr("Mot de passe"); echoMode: TextInput.Password; Layout.fillWidth: true
                           onAccepted: submit.clicked() }
            AppTextField { id: code; visible: creating; placeholderText: qsTr("Code de provisionnement"); Layout.fillWidth: true }

            AppButton {
                id: submit
                variant: "primary"
                Layout.fillWidth: true
                enabled: !App.busy && user.text.length > 0 && pass.text.length > 0
                text: App.busy ? qsTr("Connexion…") : (creating ? qsTr("Créer et enrôler") : qsTr("Enrôler"))
                onClicked: creating ? App.signup(user.text, pass.text, display.text, code.text) : App.enroll(user.text, pass.text)
            }
            AppButton {
                variant: "ghost"
                Layout.fillWidth: true
                text: creating ? qsTr("J'ai déjà un compte") : qsTr("Nouveau compte (code requis)")
                onClicked: creating = !creating
            }
            RowLayout {
                spacing: 8
                Layout.fillWidth: true
                Image { source: Theme.icon("lock", "muted"); sourceSize: Qt.size(16, 16); Layout.alignment: Qt.AlignTop; Layout.topMargin: 2 }
                Text {
                    Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.textMuted; font.pixelSize: Theme.fontSmall
                    text: qsTr("Une paire de clés propre à ce terminal est générée localement. La clé privée ne quitte jamais l'appareil.")
                }
            }
        }
    }
}
