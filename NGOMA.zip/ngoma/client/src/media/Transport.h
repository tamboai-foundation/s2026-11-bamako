// Transport média sécurisé de ngoma-media : UDP vers ngoma-relay, chiffrement de bout en bout.
#pragma once

#include <netinet/in.h>

#include <chrono>
#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>

#include "ipc/IpcTypes.h"
#include "media/MediaWire.h"

namespace ngoma::media {

class SecureTransport {
public:
    using Clock = std::chrono::steady_clock;
    using Handler = std::function<void(const wire::Uuid& sender, wire::Kind kind, const std::uint8_t* data, std::size_t len)>;

    ~SecureTransport() { close(); }

    /// Ouvre le socket, résout le relais, dérive la clé d'émission. Faux si la commande est incomplète.
    bool open(const ipc::CallControl& c, std::string& error);
    void close();
    bool isOpen() const { return m_fd >= 0; }
    bool joined() const { return m_joined; }

    /// Inscription (répétée jusqu'à accusé) puis maintien de la session ; à appeler souvent.
    void tick();
    void send(wire::Kind kind, const std::uint8_t* data, std::size_t len);
    /// Lit tous les paquets disponibles et appelle `h` pour chaque charge authentifiée.
    void poll(const Handler& h);

    std::uint64_t sent() const { return m_sent; }
    std::uint64_t received() const { return m_received; }
    std::uint64_t dropped() const { return m_dropped; }

private:
    struct Peer {
        std::uint8_t key[32];
        std::uint64_t highest = 0;
        std::uint64_t window = 0;  // bitmap des 64 derniers seq reçus (anti-rejeu)
        bool any = false;
    };
    static void deriveKey(const std::uint8_t callKey[32], const wire::Uuid& device, std::uint8_t out[32]);
    bool acceptSeq(Peer& p, std::uint64_t seq);
    void sendRaw(const std::uint8_t* p, std::size_t len);

    int m_fd = -1;
    sockaddr_in m_relay{};
    wire::Uuid m_call{}, m_device{};
    std::uint64_t m_user = 0, m_exp = 0;
    std::uint8_t m_token[32]{};
    std::uint8_t m_callKey[32]{};
    std::uint8_t m_sendKey[32]{};
    std::uint64_t m_seq = 0;
    bool m_joined = false;
    Clock::time_point m_lastJoin{}, m_lastKeepalive{};
    std::map<wire::Uuid, Peer> m_peers;
    std::uint64_t m_sent = 0, m_received = 0, m_dropped = 0;
};

}  // namespace ngoma::media
