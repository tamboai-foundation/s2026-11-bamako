import QtQuick
import QtQuick.Layouts

Item {
    id: root
    property string body
    property bool mine
    property string state
    property string time
    property string senderName
    property bool readByPeer
    property bool showSender: false
    property string kind: "text"
    property string fileName
    property string fileSize
    property string thumbnail
    property string localPath
    property bool isImage: false
    signal retry()
    signal download()

    readonly property bool isSystem: kind === "system"
    readonly property real maxBubble: Math.min(root.width * 0.72, 620)

    implicitHeight: isSystem ? systemPill.height + 12 : bubble.height + 6

    // Message système (ex. assistant désactivé)
    Rectangle {
        id: systemPill
        visible: root.isSystem
        anchors.horizontalCenter: parent.horizontalCenter
        width: Math.min(systemText.implicitWidth + 28, root.width - 48)
        height: systemText.implicitHeight + 12
        radius: height / 2
        color: Theme.surface
        border.color: Theme.outline
        Text { id: systemText; anchors.centerIn: parent; width: parent.width - 28; text: root.body; color: Theme.textMuted; font.pixelSize: Theme.fontSmall; wrapMode: Text.Wrap; horizontalAlignment: Text.AlignHCenter }
    }

    Rectangle {
        id: bubble
        visible: !root.isSystem
        anchors.right: mine ? parent.right : undefined
        anchors.left: mine ? undefined : parent.left
        anchors.rightMargin: 16
        anchors.leftMargin: 16
        width: Math.min(root.maxBubble, Math.max(content.implicitWidth, meta.implicitWidth, sender.implicitWidth, attachment.visible ? 280 : 0) + 32)
        height: col.implicitHeight + 18
        radius: Theme.radius
        color: state === "failed" ? "#3b1a19" : (mine ? Theme.bubbleMine : Theme.bubbleOther)
        border.width: state === "failed" ? 1 : 0
        border.color: Theme.danger

        ColumnLayout {
            id: col
            anchors.fill: parent; anchors.margins: 9; anchors.leftMargin: 14; anchors.rightMargin: 14
            spacing: 4
            Text { id: sender; visible: root.showSender && !mine && senderName.length; text: senderName; color: Theme.accent; font.pixelSize: Theme.fontSmall; font.weight: Font.DemiBold }

            Item {
                id: attachment
                visible: kind === "media"
                Layout.fillWidth: true
                Layout.preferredHeight: visible ? (preview.visible ? 180 : 56) : 0
                Image {
                    id: preview
                    visible: isImage && (localPath.length > 0 || thumbnail.length > 0)
                    anchors.fill: parent
                    fillMode: Image.PreserveAspectFit
                    horizontalAlignment: Image.AlignLeft
                    source: localPath.length > 0 ? localPath : thumbnail
                    asynchronous: true
                }
                Rectangle {
                    visible: !preview.visible || localPath.length === 0
                    anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom
                    height: 52; radius: Theme.radiusSmall
                    color: Qt.rgba(0, 0, 0, 0.22)
                    RowLayout {
                        anchors.fill: parent; anchors.leftMargin: 10; anchors.rightMargin: 6; spacing: 10
                        Image { source: Theme.icon(isImage ? "image" : "file", "light"); sourceSize: Qt.size(24, 24) }
                        ColumnLayout {
                            Layout.fillWidth: true; spacing: 0
                            Text { text: fileName; color: Theme.text; elide: Text.ElideMiddle; Layout.fillWidth: true; font.pixelSize: Theme.fontSmall + 1 }
                            Text { text: fileSize; color: Theme.textMuted; font.pixelSize: 12 }
                        }
                        IconButton { visible: localPath.length === 0; iconName: "download"; implicitWidth: 44; implicitHeight: 44; tip: qsTr("Télécharger"); onClicked: root.download() }
                    }
                }
            }

            Text { id: content; visible: body.length > 0; text: body; color: Theme.text; wrapMode: Text.Wrap; font.pixelSize: Theme.fontBody
                   textFormat: Text.PlainText; Layout.fillWidth: true; Layout.maximumWidth: root.maxBubble - 32 }

            RowLayout {
                id: meta
                Layout.alignment: Qt.AlignRight
                spacing: 4
                Text { text: time; color: mine ? "#a9d8d2" : Theme.textMuted; font.pixelSize: 12 }
                Image {
                    visible: mine && state !== "failed"
                    source: Theme.icon(state === "pending" ? "clock" : (readByPeer ? "check-double" : "check"), readByPeer ? "accent" : "muted")
                    sourceSize: Qt.size(16, 16)
                }
                Text { visible: state === "failed"; text: qsTr("Échec · toucher pour réessayer"); color: Theme.danger; font.pixelSize: 12 }
            }
        }
        MouseArea { anchors.fill: parent; enabled: state === "failed"; onClicked: root.retry() }
    }
}
