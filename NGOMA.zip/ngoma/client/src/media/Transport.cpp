#include "media/Transport.h"

#include <arpa/inet.h>
#include <netdb.h>
#include <sodium.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstring>

namespace ngoma::media {

namespace w = wire;

void SecureTransport::deriveKey(const std::uint8_t callKey[32], const w::Uuid& device, std::uint8_t out[32]) {
    // HKDF-SHA256 (sel nul) : PRK = HMAC(0^32, clé d'appel) ; OKM = HMAC(PRK, info || 0x01)
    std::uint8_t zero[32] = {}, prk[32];
    crypto_auth_hmacsha256_state st;
    crypto_auth_hmacsha256_init(&st, zero, sizeof zero);
    crypto_auth_hmacsha256_update(&st, callKey, 32);
    crypto_auth_hmacsha256_final(&st, prk);
    static const char kInfo[] = "NGM-media-v1";
    const std::uint8_t one = 1;
    crypto_auth_hmacsha256_init(&st, prk, sizeof prk);
    crypto_auth_hmacsha256_update(&st, reinterpret_cast<const unsigned char*>(kInfo), sizeof kInfo - 1);
    crypto_auth_hmacsha256_update(&st, device.data(), device.size());
    crypto_auth_hmacsha256_update(&st, &one, 1);
    crypto_auth_hmacsha256_final(&st, out);
    sodium_memzero(prk, sizeof prk);
}

bool SecureTransport::open(const ipc::CallControl& c, std::string& error) {
    close();
    if (c.relay_port == 0 || !c.relay_host[0]) {
        error = "relais non configuré";
        return false;
    }
    if (!w::parseUuid(c.call_id, m_call) || !w::parseUuid(c.device_id, m_device)) {
        error = "identifiants d'appel invalides";
        return false;
    }
    if (std::strlen(c.token) != 64 || sodium_hex2bin(m_token, sizeof m_token, c.token, 64, nullptr, nullptr, nullptr) != 0) {
        error = "jeton de relais invalide";
        return false;
    }
    addrinfo hints{}, *res = nullptr;
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;
    if (getaddrinfo(c.relay_host, std::to_string(c.relay_port).c_str(), &hints, &res) != 0 || !res) {
        error = "relais introuvable";
        return false;
    }
    std::memcpy(&m_relay, res->ai_addr, sizeof m_relay);
    freeaddrinfo(res);
    m_fd = socket(AF_INET, SOCK_DGRAM | SOCK_NONBLOCK, 0);
    if (m_fd < 0) {
        error = "socket UDP impossible";
        return false;
    }
    int buf = 1 << 20;
    setsockopt(m_fd, SOL_SOCKET, SO_RCVBUF, &buf, sizeof buf);
    int tos = 0xB8;  // DSCP EF : priorité réseau pour le temps réel
    setsockopt(m_fd, IPPROTO_IP, IP_TOS, &tos, sizeof tos);
    m_user = c.user_id;
    m_exp = c.exp;
    std::memcpy(m_callKey, c.call_key, 32);
    deriveKey(m_callKey, m_device, m_sendKey);
    randombytes_buf(&m_seq, sizeof m_seq);
    m_seq >>= 16;  // départ aléatoire, loin du débordement
    m_joined = false;
    m_peers.clear();
    m_lastJoin = {};
    tick();
    return true;
}

void SecureTransport::close() {
    if (m_fd < 0) return;
    std::uint8_t p[w::kHeader + 16];
    w::header(p, w::Leave, m_call);
    std::memcpy(p + w::kHeader, m_device.data(), 16);
    sendRaw(p, sizeof p);
    ::close(m_fd);
    m_fd = -1;
    m_joined = false;
    sodium_memzero(m_callKey, sizeof m_callKey);
    sodium_memzero(m_sendKey, sizeof m_sendKey);
    for (auto& kv : m_peers) sodium_memzero(kv.second.key, sizeof kv.second.key);
    m_peers.clear();
}

void SecureTransport::sendRaw(const std::uint8_t* p, std::size_t len) {
    if (m_fd >= 0) sendto(m_fd, p, len, 0, reinterpret_cast<const sockaddr*>(&m_relay), sizeof m_relay);
}

void SecureTransport::tick() {
    if (m_fd < 0) return;
    const auto now = Clock::now();
    if (!m_joined && now - m_lastJoin > std::chrono::milliseconds(500)) {
        std::uint8_t p[w::kHeader + 64];
        w::header(p, w::Join, m_call);
        w::putBe(p + 20, m_user, 8);
        std::memcpy(p + 28, m_device.data(), 16);
        w::putBe(p + 44, m_exp, 8);
        std::memcpy(p + 52, m_token, 32);
        sendRaw(p, sizeof p);
        m_lastJoin = now;
    } else if (m_joined && now - m_lastKeepalive > std::chrono::seconds(5)) {
        std::uint8_t p[w::kHeader + 16];
        w::header(p, w::Keepalive, m_call);
        std::memcpy(p + w::kHeader, m_device.data(), 16);
        sendRaw(p, sizeof p);
        m_lastKeepalive = now;
    }
}

void SecureTransport::send(w::Kind kind, const std::uint8_t* data, std::size_t len) {
    if (m_fd < 0 || !m_joined) return;
    std::uint8_t p[w::kMaxPacket];
    const std::size_t head = w::kHeader + 16 + 8 + 1;
    if (head + len + crypto_aead_chacha20poly1305_ietf_ABYTES > sizeof p) return;
    w::header(p, w::Data, m_call);
    std::memcpy(p + w::kHeader, m_device.data(), 16);
    const std::uint64_t seq = ++m_seq;
    w::putBe(p + w::kHeader + 16, seq, 8);
    p[w::kHeader + 24] = kind;
    std::uint8_t nonce[12] = {};
    nonce[0] = kind;
    w::putBe(nonce + 4, seq, 8);
    unsigned long long clen = 0;
    crypto_aead_chacha20poly1305_ietf_encrypt(p + head, &clen, data, len, p, head, nullptr, nonce, m_sendKey);
    sendRaw(p, head + std::size_t(clen));
    ++m_sent;
}

bool SecureTransport::acceptSeq(Peer& p, std::uint64_t seq) {
    if (!p.any) {
        p.any = true;
        p.highest = seq;
        p.window = 1;
        return true;
    }
    if (seq > p.highest) {
        const std::uint64_t shift = seq - p.highest;
        p.window = shift >= 64 ? 1 : (p.window << shift) | 1;
        p.highest = seq;
        return true;
    }
    const std::uint64_t back = p.highest - seq;
    if (back >= 64) return false;
    const std::uint64_t bit = 1ULL << back;
    if (p.window & bit) return false;  // rejeu
    p.window |= bit;
    return true;
}

void SecureTransport::poll(const Handler& h) {
    if (m_fd < 0) return;
    std::uint8_t p[2048], plain[2048];
    for (;;) {
        sockaddr_in from{};
        socklen_t fl = sizeof from;
        const ssize_t n = recvfrom(m_fd, p, sizeof p, 0, reinterpret_cast<sockaddr*>(&from), &fl);
        if (n <= 0) return;
        if (from.sin_addr.s_addr != m_relay.sin_addr.s_addr || from.sin_port != m_relay.sin_port) continue;
        const std::size_t len = std::size_t(n);
        if (!w::validHeader(p, len) || std::memcmp(p + 4, m_call.data(), 16) != 0) continue;
        if (p[3] == w::JoinAck) {
            m_joined = true;
            m_lastKeepalive = Clock::now();
            continue;
        }
        if (p[3] == w::JoinNack) {
            m_lastJoin = Clock::now() + std::chrono::seconds(2);  // jeton refusé : nouvel essai espacé
            continue;
        }
        const std::size_t head = w::kHeader + 16 + 8 + 1;
        if (p[3] != w::Data || len < head + crypto_aead_chacha20poly1305_ietf_ABYTES) continue;
        w::Uuid sender;
        std::memcpy(sender.data(), p + w::kHeader, 16);
        if (sender == m_device) continue;
        auto it = m_peers.find(sender);
        if (it == m_peers.end()) {
            Peer peer;
            deriveKey(m_callKey, sender, peer.key);
            it = m_peers.emplace(sender, peer).first;
        }
        const std::uint64_t seq = w::getBe(p + w::kHeader + 16, 8);
        const auto kind = w::Kind(p[w::kHeader + 24]);
        std::uint8_t nonce[12] = {};
        nonce[0] = kind;
        w::putBe(nonce + 4, seq, 8);
        unsigned long long plen = 0;
        if (crypto_aead_chacha20poly1305_ietf_decrypt(plain, &plen, nullptr, p + head, len - head, p, head, nonce,
                                                      it->second.key) != 0) {
            ++m_dropped;  // clé d'appel différente ou paquet altéré
            continue;
        }
        if (!acceptSeq(it->second, seq)) {
            ++m_dropped;
            continue;
        }
        ++m_received;
        h(sender, kind, plain, std::size_t(plen));
    }
}

}  // namespace ngoma::media
