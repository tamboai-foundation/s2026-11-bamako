# Protocoles NGOMA (v1.2)

## 1. API REST du serveur (`/api/v1`, JSON)

Authentification : `Authorization: Device <jeton>`. Le jeton est émis à l'enrôlement, et le serveur n'en garde que le hash SHA-256.

### Comptes et appareils

| Méthode | Chemin | Corps / paramètres | Réponse |
|---|---|---|---|
| POST | `auth/signup` | `username, password, display_name, device_name, public_key (Ed25519), provisioning_code` | `201 {user, device_id, token}`, ou `403` sans code valide |
| POST | `auth/enroll` | `username, password, device_name, public_key` | `201 {user, device_id, token}` |
| GET | `me`, `me/devices` | — | identité, appareils |
| POST | `me/devices/{id}/revoke` | — | `204`, et fermeture du WebSocket de l'appareil (code 4403) |
| GET | `users/search?q=` | au moins 2 caractères ; les bots sont exclus | `[{id, username, display_name}]` |

### Prékeys (NGOMA Ratchet v2, voir `CRYPTO.md`)

| Méthode | Chemin | Corps | Réponse |
|---|---|---|---|
| POST | `keys/prekeys` | `spk_id, spk, spk_sig, opks[{id, key}]` | `{opk_count}`. Signature vérifiée, au plus 200 OPK |
| GET | `keys/prekeys` | — | `{opk_count, spk_id}` |
| POST | `keys/claim` | `device_ids[]`, limité aux appareils partageant une conversation avec l'appelant | `{device_id: {identity_key, spk_id, spk, spk_sig, opk_id, opk}}`. L'OPK est réservée une seule fois |

### Conversations et synchronisation

| Méthode | Chemin | Corps / paramètres | Réponse |
|---|---|---|---|
| GET / POST | `conversations` | `kind: direct\|group, member_ids, title?` | `201`, ou `200` si la conversation directe existe déjà |
| GET | `conversations/{id}/devices` | — | appareils **joignables** (SPK publiée) : `[{device_id, user_id, public_key}]` |
| GET | `sync/state` | — | `{conversations: [{messaging_id, last_seq}]}` |
| POST | `sync/push` | `messaging_id, client_id (UUIDv7), kind, envelopes[{device_id, payload}], expires_in?` | `201 {id, seq}`, `200 {duplicate: true}` ou `409 {devices}` |
| GET | `sync/pull` | `messaging_id, after_seq, limit ≤ 200` | `{items[…, envelope], has_more, last_seq}` |
| POST | `sync/ack` | `messaging_id, delivered_seq?, read_seq?` | valeurs bornées au `last_seq` |

`payload` est une enveloppe v2 `{v:2, type, h, c, x?}` dont le serveur ne contrôle que la forme. Messages de type `system` : texte en clair dans `system_text` (par exemple « assistant désactivé »).

Invariants côté serveur :
- `seq` est strictement croissant et sans trou par conversation ;
- unicité sur `(messaging, client_id)` (idempotence) et sur `(messaging, seq)` ;
- l'ensemble des enveloppes doit couvrir exactement les appareils joignables des membres (l'appareil émetteur est facultatif), sinon le serveur répond `409` ;
- `pull` ne renvoie que l'enveloppe destinée à l'appareil appelant.

### Pièces jointes et appels (V1.1)

| Méthode | Chemin | Corps | Réponse |
|---|---|---|---|
| POST | `media` | multipart : `messaging_id`, `file` (chiffré par le client, 25 Mo maximum) | `201 {media_id, size}` |
| GET | `media/{id}` | réservé aux membres de la conversation | octets chiffrés (`application/octet-stream`) |
| POST | `calls/token` | `messaging_id, call_id` | `{relay_host, relay_port, user_id, device_id, exp, token}` |

`token = hex(HMAC-SHA256(RELAY_SECRET, call_id(16) ‖ user_id(8 BE) ‖ device_id(16) ‖ exp(8 BE)))`.

### Assistant IA (V1.2)

| Méthode | Chemin | Corps | Réponse |
|---|---|---|---|
| GET | `bots/me` | — | `{active, provider, model, base_url, system_prompt, api_key_set, conversation_id, bot_user_id, last_error}` |
| POST | `bots/me` | `provider: anthropic\|openai, model, api_key?, base_url?, system_prompt?` | activation ou reconfiguration. La clé API n'est jamais renvoyée |
| DELETE | `bots/me` | — | désactivation : appareil du bot révoqué, clé API, clés, sessions et historique effacés |

- `base_url` doit être en `https://` et désigner un hôte public. Le serveur refuse les adresses privées, de bouclage et link-local (protection SSRF).
- `anthropic` utilise `POST {base}/v1/messages` (`x-api-key`, `anthropic-version: 2023-06-01`).
- `openai` utilise `POST {base}/v1/chat/completions` (`Authorization: Bearer`). Cela couvre aussi Mistral, vLLM, Ollama et les autres API compatibles.

## 2. Temps réel (`wss://…/ws/v1/realtime`)

- Du serveur vers le client : `hello`, `message {messaging_id, seq}`, `conversation`, `receipt`, `typing`, `presence`, `call.signal {from_user_id, from_device_id, payload}`, `pong`.
- Du client vers le serveur : `ping`, `typing`, `presence.query`, `call.signal {messaging_id, to_user_id, payload}`.

Aucune donnée de message ne passe sur ce canal. En complément, le client resynchronise toutes les 60 s : un signal perdu ne bloque jamais un message.

Signalisation d'appel (`payload`) :
- `invite {call_id, keys: {device_id: enveloppe v2 de {"t":"callkey","call_id","k"}}}` ;
- `accept`, `reject`, `busy`, `hangup`.

## 3. IPC local `ngoma-store` (socket Unix, JSON-lignes)

Requête `{"id", "op", "args"}`, réponse `{"id", "ok", "result" | "error"}`. Le démon émet aussi des événements `{"event":"changed","scope","messaging_id"}`.

Opérations :
- `ping`
- `setting.get|set`
- `conv.upsert|list|setServerSeq|setPulled|setRead|setPeerRead|setDraft`
- `msg.insertOutgoing|markSent|markFailed|upsertReceived|setMeta|list|pending|search|purgeExpired`
- `wipe`

Les messages portent un champ `meta` (JSON de la pièce jointe, plus le chemin local `path`, qui n'est jamais transmis).

## 4. IPC média (iceoryx2, `client/src/ipc/IpcTypes.h`, ABI v2)

| Service | Charge utile | Sens |
|---|---|---|
| `ngoma/call/control` | `CallControl` (Start : relais, jeton, device, **clé d'appel**) | cœur → média |
| `ngoma/call/state` | `CallState` | média → cœur |
| `ngoma/media/video/local` | `Slice<u8>` + `VideoFrameHeader` | média → UI |
| `ngoma/media/video/remote` | idem (trames distantes décodées) | média → UI |
| `ngoma/media/audio/level` | `AudioLevel` (micro, haut-parleur) | média → UI |
| `ngoma/events/message` | `MessageEvent` | cœur → services locaux |

`NGOMA_IPC_PREFIX` préfixe les noms de services. Il sert aux bancs d'essai qui simulent plusieurs terminaux sur une même machine ; il est vide en production.

## 5. Paquets média (UDP, `client/src/media/MediaWire.h`)

En-tête visible du relais : `'F' 'R' | version | type | call_id(16)`.

Types :
- `JOIN` (+ user, device, exp, HMAC) ;
- `DATA` (+ device émetteur et charge chiffrée) ;
- `KEEPALIVE`, `LEAVE` ;
- `JOIN_ACK`, `JOIN_NACK`.

Charge `DATA` : `seq | kind | AEAD(clair)`. Contenu du clair selon le type :
- audio : `ts(4) | Opus` ;
- vidéo : `frame_id(4) | idx(2) | count(2) | flags(1) | w(2) | h(2) | H.264 Annex-B (fragment ≤ 1100 o)` ;
- contrôle : `1` = demande d'image clé.
