"""Fournisseurs LLM : API Anthropic Messages et API « chat completions » compatible OpenAI
(OpenAI, Mistral, vLLM, Ollama… via base_url)."""
from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlparse

import httpx
from django.conf import settings

DEFAULT_BASE = {"anthropic": "https://api.anthropic.com", "openai": "https://api.openai.com"}
TIMEOUT = httpx.Timeout(60.0, connect=10.0)


class LLMError(Exception):
    pass


def validate_base_url(provider: str, base_url: str) -> str:
    """Protection SSRF : HTTPS obligatoire et hôte public (sauf autorisation explicite du serveur)."""
    url = (base_url or DEFAULT_BASE[provider]).rstrip("/")
    u = urlparse(url)
    if settings.NGOMA["BOT_ALLOW_PRIVATE_BASE_URL"]:
        if u.scheme not in ("http", "https") or not u.hostname:
            raise LLMError("URL du fournisseur invalide")
        return url
    if u.scheme != "https" or not u.hostname or u.username or u.password:
        raise LLMError("L'URL du fournisseur doit être en https://")
    try:
        infos = socket.getaddrinfo(u.hostname, u.port or 443, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise LLMError("Hôte du fournisseur introuvable") from exc
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            raise LLMError("Adresse du fournisseur non autorisée (réseau privé)")
    return url


def _merge(history: list[dict]) -> list[dict]:
    """Fusionne les tours consécutifs de même rôle et garantit un premier tour « user »."""
    out: list[dict] = []
    for t in history:
        if out and out[-1]["role"] == t["role"]:
            out[-1] = {"role": t["role"], "content": out[-1]["content"] + "\n\n" + t["content"]}
        else:
            out.append(dict(t))
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out


def complete(*, provider: str, base_url: str, model: str, api_key: str, system_prompt: str,
             history: list[dict], client: httpx.Client | None = None) -> str:
    messages = _merge(history)
    if not messages:
        raise LLMError("historique vide")
    own = client is None
    client = client or httpx.Client(timeout=TIMEOUT, follow_redirects=False)
    try:
        if provider == "anthropic":
            body = {"model": model, "max_tokens": 1024, "messages": messages}
            if system_prompt:
                body["system"] = system_prompt
            r = client.post(f"{base_url}/v1/messages", json=body,
                            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01"})
            if r.status_code != 200:
                raise LLMError(f"fournisseur : HTTP {r.status_code}")
            data = r.json()
            text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        elif provider == "openai":
            msgs = ([{"role": "system", "content": system_prompt}] if system_prompt else []) + messages
            r = client.post(f"{base_url}/v1/chat/completions", json={"model": model, "messages": msgs},
                            headers={"Authorization": f"Bearer {api_key}"})
            if r.status_code != 200:
                raise LLMError(f"fournisseur : HTTP {r.status_code}")
            text = r.json()["choices"][0]["message"]["content"] or ""
        else:
            raise LLMError("fournisseur inconnu")
    except httpx.HTTPError as exc:
        raise LLMError(f"fournisseur injoignable : {exc.__class__.__name__}") from exc
    except (KeyError, IndexError, ValueError) as exc:
        raise LLMError("réponse du fournisseur illisible") from exc
    finally:
        if own:
            client.close()
    return text.strip() or "…"
