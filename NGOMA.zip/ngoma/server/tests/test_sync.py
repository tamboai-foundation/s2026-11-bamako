import base64
import os
import secrets
import uuid

import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

from accounts.models import Device, SignedPreKey

pytestmark = pytest.mark.django_db
PASSWORD = secrets.token_urlsafe(16)
CODE = secrets.token_urlsafe(12)
API_KEY = secrets.token_urlsafe(24)
User = get_user_model()


def key() -> str:
    return base64.b64encode(os.urandom(32)).decode()


def nonce() -> str:
    return base64.b64encode(os.urandom(24)).decode()


def ct(n=32) -> str:
    return base64.b64encode(os.urandom(n)).decode()


def payload() -> dict:
    return {"v": 2, "type": "msg", "h": base64.b64encode(os.urandom(40)).decode(), "c": ct()}


@pytest.fixture
def make_device():
    def _make(username: str, device_name: str = "terminal"):
        user = User.objects.filter(username=username).first() or User.objects.create_user(username, password=secrets.token_urlsafe(16))
        device, token = Device.issue(user, device_name, key())
        SignedPreKey.objects.create(device=device, key_id=1, public_key=key(), signature="x")
        client = APIClient()
        client.credentials(HTTP_AUTHORIZATION=f"Device {token}")
        return user, device, client, token

    return _make


def envelopes_for(client, conv_id, exclude=None):
    devices = client.get(f"/api/v1/conversations/{conv_id}/devices").json()
    return [
        {"device_id": d["device_id"], "payload": payload()}
        for d in devices
        if d["device_id"] != exclude
    ]


def test_signup_closed_by_default():
    r = APIClient().post(
        "/api/v1/auth/signup",
        {"username": "alice", "password": PASSWORD, "device_name": "t1", "public_key": key()},
        format="json",
    )
    assert r.status_code == 403


def test_signup_with_provisioning_and_enroll(settings):
    settings.NGOMA = {**settings.NGOMA, "PROVISIONING_CODE": CODE}
    c = APIClient()
    r = c.post(
        "/api/v1/auth/signup",
        {"username": "alice", "password": PASSWORD, "device_name": "t1", "public_key": key(),
         "provisioning_code": CODE},
        format="json",
    )
    assert r.status_code == 201, r.content
    token = r.json()["token"]
    c.credentials(HTTP_AUTHORIZATION=f"Device {token}")
    assert c.get("/api/v1/me").json()["user"]["username"] == "alice"
    r2 = APIClient().post(
        "/api/v1/auth/enroll",
        {"username": "alice", "password": PASSWORD, "device_name": "t2", "public_key": key()},
        format="json",
    )
    assert r2.status_code == 201
    assert Device.objects.filter(user__username="alice").count() == 2


def test_rejects_bad_token():
    c = APIClient()
    c.credentials(HTTP_AUTHORIZATION="Device faux")
    assert c.get("/api/v1/me").status_code == 401


def test_direct_conversation_is_unique(make_device):
    a, _, ca, _ = make_device("alice")
    b, _, cb, _ = make_device("bob")
    r1 = ca.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.id]}, format="json")
    r2 = cb.post("/api/v1/conversations", {"kind": "direct", "member_ids": [a.id]}, format="json")
    assert r1.status_code == 201 and r2.status_code == 200
    assert r1.json()["id"] == r2.json()["id"]


def test_push_pull_idempotent_and_per_device(make_device):
    a, da, ca, _ = make_device("alice")
    _, da2, ca2, _ = make_device("alice", "t-cuisine")
    b, db, cb, _ = make_device("bob")
    conv = ca.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.id]}, format="json").json()

    envs = envelopes_for(ca, conv["id"], exclude=str(da.id))
    assert {e["device_id"] for e in envs} == {str(da2.id), str(db.id)}
    cid = str(uuid.uuid4())
    body = {"messaging_id": conv["id"], "client_id": cid, "envelopes": envs}
    r1 = ca.post("/api/v1/sync/push", body, format="json")
    r2 = ca.post("/api/v1/sync/push", body, format="json")
    assert r1.status_code == 201 and r1.json()["seq"] == 1
    assert r2.status_code == 200 and r2.json()["duplicate"] is True and r2.json()["seq"] == 1

    # Bob reçoit uniquement son enveloppe.
    pulled = cb.get(f"/api/v1/sync/pull?messaging_id={conv['id']}&after_seq=0").json()
    assert pulled["last_seq"] == 1 and len(pulled["items"]) == 1
    item = pulled["items"][0]
    mine = next(e for e in envs if e["device_id"] == str(db.id))
    assert item["envelope"] == mine["payload"]
    assert item["sender_public_key"] == da.public_key

    # Curseur : rien après seq 1.
    assert cb.get(f"/api/v1/sync/pull?messaging_id={conv['id']}&after_seq=1").json()["items"] == []


def test_push_rejects_stale_device_set(make_device):
    a, da, ca, _ = make_device("alice")
    b, db, cb, _ = make_device("bob")
    conv = ca.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.id]}, format="json").json()
    envs = envelopes_for(ca, conv["id"], exclude=str(da.id))
    _, db2, _, _ = make_device("bob", "t2")  # Bob ajoute un appareil entre-temps
    r = ca.post(
        "/api/v1/sync/push", {"messaging_id": conv["id"], "client_id": str(uuid.uuid4()), "envelopes": envs},
        format="json",
    )
    assert r.status_code == 409
    assert str(db2.id) in r.json()["devices"]


def test_non_member_cannot_read(make_device):
    a, da, ca, _ = make_device("alice")
    b, _, _, _ = make_device("bob")
    _, _, cm, _ = make_device("mallory")
    conv = ca.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.id]}, format="json").json()
    assert cm.get(f"/api/v1/sync/pull?messaging_id={conv['id']}").status_code == 404
    assert cm.get(f"/api/v1/conversations/{conv['id']}/devices").status_code == 404


def test_sequence_is_gapless_and_ack(make_device):
    a, da, ca, _ = make_device("alice")
    b, db, cb, _ = make_device("bob")
    conv = ca.post("/api/v1/conversations", {"kind": "group", "member_ids": [b.id], "title": "Équipe"},
                   format="json").json()
    for _ in range(5):
        ca.post("/api/v1/sync/push", {"messaging_id": conv["id"], "client_id": str(uuid.uuid4()),
                                      "envelopes": envelopes_for(ca, conv["id"], exclude=str(da.id))}, format="json")
    seqs = [i["seq"] for i in cb.get(f"/api/v1/sync/pull?messaging_id={conv['id']}&limit=3").json()["items"]]
    assert seqs == [1, 2, 3]
    r = cb.post("/api/v1/sync/ack", {"messaging_id": conv["id"], "read_seq": 99}, format="json").json()
    assert r == {"delivered_seq": 5, "read_seq": 5}  # borné au dernier seq
    state = cb.get("/api/v1/sync/state").json()["conversations"]
    assert state[0]["last_seq"] == 5


def test_revoked_device_loses_access(make_device):
    a, da, ca, _ = make_device("alice")
    _, da2, ca2, _ = make_device("alice", "t2")
    assert ca.post(f"/api/v1/me/devices/{da2.id}/revoke").status_code == 204
    assert ca2.get("/api/v1/me").status_code == 401


def test_ephemeral_purge(make_device):
    from datetime import timedelta

    from django.utils import timezone

    from messaging.models import Message
    from messaging.services import purge_expired

    a, da, ca, _ = make_device("alice")
    b, db, cb, _ = make_device("bob")
    conv = ca.post("/api/v1/conversations", {"kind": "direct", "member_ids": [b.id]}, format="json").json()
    ca.post("/api/v1/sync/push", {"messaging_id": conv["id"], "client_id": str(uuid.uuid4()), "expires_in": 30,
                                  "envelopes": envelopes_for(ca, conv["id"], exclude=str(da.id))}, format="json")
    Message.objects.update(expires_at=timezone.now() - timedelta(seconds=1))
    assert cb.get(f"/api/v1/sync/pull?messaging_id={conv['id']}").json()["items"] == []
    assert purge_expired() == 1
