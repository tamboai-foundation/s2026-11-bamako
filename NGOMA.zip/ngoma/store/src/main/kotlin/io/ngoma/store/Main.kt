package io.ngoma.store

import ai.tambo.tmodeler.db.Tdb
import ai.tambo.tmodeler.extension.synchronization.core.TServerConfigBase
import ai.tambo.tmodeler.modeler.TModeler
import io.ngoma.store.ipc.StoreServer
import io.ngoma.store.models.Conversation
import java.io.File
import java.nio.file.Path
import kotlin.system.exitProcess

/**
 * Point d'entrée du démon `ngoma-store`.
 *
 * Variables d'environnement :
 *   NGOMA_DATA_DIR    dossier de la base (défaut /var/lib/ngoma)  — doit être sur la partition chiffrée
 *   NGOMA_STORE_SOCK  chemin du socket (défaut /run/ngoma/store.sock)
 */
fun main() {
    val dataDir = File(System.getenv("NGOMA_DATA_DIR") ?: "/var/lib/ngoma").apply { mkdirs() }
    val sock = Path.of(System.getenv("NGOMA_STORE_SOCK") ?: "/run/ngoma/store.sock")

    // Base 100 % locale : aucun moteur de synchronisation T-Modeler n'est branché.
    // La synchronisation est faite par le moteur interne du cœur C++ (ngoma-core).
    val db = Tdb.Builder()
        .type(Tdb.Type.SQLITE)
        .dbDir(dataDir.path)
        .dbName(File(dataDir, "ngoma-local-1").path)
        .server(TServerConfigBase())
        .accept(Conversation().clazz().getPackage())
        .start()
    if (db == null) {
        System.err.println("ngoma-store : impossible d'ouvrir la base dans $dataDir")
        exitProcess(2)
    }
    TModeler.start().connect(db)
    Store.commitSchema()

    StoreServer(sock).serve()
}
