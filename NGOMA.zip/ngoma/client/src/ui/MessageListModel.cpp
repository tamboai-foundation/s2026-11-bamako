#include "MessageListModel.h"

#include <QDateTime>
#include <QLocale>
#include <QJsonDocument>
#include <QSet>
#include <QUrl>

namespace ngoma {

namespace {
QString cid(const QJsonObject& o) { return o.value(QStringLiteral("client_id")).toString(); }
qint64 seqOf(const QJsonObject& o) { return o.value(QStringLiteral("seq")).toInteger(); }
}  // namespace

MessageListModel::MessageListModel(QObject* parent) : QAbstractListModel(parent) {}

int MessageListModel::rowCount(const QModelIndex& parent) const { return parent.isValid() ? 0 : int(m_items.size()); }

QHash<int, QByteArray> MessageListModel::roleNames() const {
    return {{ClientIdRole, "clientId"}, {SeqRole, "seq"},       {BodyRole, "body"},
            {MineRole, "mine"},         {StateRole, "state"},   {TimeRole, "time"},
            {SenderRole, "senderName"}, {ReadRole, "readByPeer"}, {DayRole, "day"},
            {KindRole, "kind"},         {FileNameRole, "fileName"}, {FileSizeRole, "fileSize"},
            {ThumbRole, "thumbnail"},   {LocalPathRole, "localPath"}, {IsImageRole, "isImage"}};
}

QVariant MessageListModel::data(const QModelIndex& index, int role) const {
    if (!index.isValid() || index.row() >= m_items.size()) return {};
    const auto& m = m_items.at(index.row());
    const qint64 sender = m.value(QStringLiteral("sender_id")).toInteger();
    const auto dt = QDateTime::fromString(m.value(QStringLiteral("created_at")).toString(), Qt::ISODateWithMs).toLocalTime();
    switch (role) {
    case ClientIdRole: return cid(m);
    case SeqRole: return seqOf(m);
    case BodyRole: return m.value(QStringLiteral("body")).toString();
    case MineRole: return sender == m_me;
    case StateRole: return m.value(QStringLiteral("state")).toString();
    case TimeRole: return dt.isValid() ? dt.toString(QStringLiteral("HH:mm")) : QString();
    case SenderRole: return m_names.value(sender);
    case ReadRole: return sender == m_me && seqOf(m) > 0 && seqOf(m) <= m_peerRead;
    case DayRole: return dt.isValid() ? QLocale().toString(dt.date(), QLocale::LongFormat) : QString();
    case KindRole: return m.value(QStringLiteral("kind")).toString();
    default: break;
    }
    if (role >= FileNameRole && role <= IsImageRole) {
        const auto meta = QJsonDocument::fromJson(m.value(QStringLiteral("meta")).toString().toUtf8()).object();
        switch (role) {
        case FileNameRole: return meta.value(QStringLiteral("name")).toString();
        case FileSizeRole: return QLocale().formattedDataSize(meta.value(QStringLiteral("size")).toInteger());
        case ThumbRole: {
            const QString t = meta.value(QStringLiteral("thumb")).toString();
            return t.isEmpty() ? QString() : QStringLiteral("data:image/jpeg;base64,") + t;
        }
        case LocalPathRole: {
            const QString p = meta.value(QStringLiteral("path")).toString();
            return p.isEmpty() ? QString() : QUrl::fromLocalFile(p).toString();
        }
        case IsImageRole: return meta.value(QStringLiteral("mime")).toString().startsWith(QLatin1String("image/"));
        }
    }
    return {};
}

void MessageListModel::setPeerReadSeq(qint64 seq) {
    if (seq == m_peerRead) return;
    m_peerRead = seq;
    if (!m_items.isEmpty()) emit dataChanged(index(0), index(int(m_items.size()) - 1), {ReadRole});
}

void MessageListModel::clear() {
    beginResetModel();
    m_items.clear();
    m_peerRead = 0;
    endResetModel();
    emit countChanged();
}

void MessageListModel::mergeLatest(const QJsonArray& items) {
    QHash<QString, int> pos;
    for (int i = 0; i < m_items.size(); ++i) pos.insert(cid(m_items[i]), i);

    QList<QJsonObject> append;
    for (const auto& v : items) {
        const auto o = v.toObject();
        const auto it = pos.constFind(cid(o));
        if (it != pos.constEnd()) {
            if (m_items[*it] != o) {  // changement d'état (pending → sent, accusé…)
                m_items[*it] = o;
                emit dataChanged(index(*it), index(*it));
            }
        } else {
            append.append(o);
        }
    }
    if (append.isEmpty()) return;
    // Les nouveaux éléments les plus récents sont ajoutés en fin ; si l'un d'eux s'intercale (rare : seq attribué
    // après un message reçu), on retrie l'ensemble.
    const qint64 newest = newestSeq();
    bool ordered = true;
    for (const auto& o : append)
        if (seqOf(o) > 0 && seqOf(o) < newest) ordered = false;
    if (ordered) {
        beginInsertRows({}, int(m_items.size()), int(m_items.size() + append.size()) - 1);
        m_items.append(append);
        endInsertRows();
    } else {
        beginResetModel();
        m_items.append(append);
        std::stable_sort(m_items.begin(), m_items.end(), [](const QJsonObject& a, const QJsonObject& b) {
            const qint64 sa = seqOf(a), sb = seqOf(b);
            if (sa == 0 || sb == 0) return sa != 0 && sb == 0;  // en attente en dernier
            return sa < sb;
        });
        endResetModel();
    }
    emit countChanged();
}

void MessageListModel::prependOlder(const QJsonArray& items) {
    QSet<QString> known;
    for (const auto& m : m_items) known.insert(cid(m));
    QList<QJsonObject> older;
    for (const auto& v : items)
        if (!known.contains(cid(v.toObject()))) older.append(v.toObject());
    if (older.isEmpty()) return;
    beginInsertRows({}, 0, int(older.size()) - 1);
    m_items = older + m_items;
    endInsertRows();
    emit countChanged();
}

QJsonObject MessageListModel::metaOf(const QString& clientId) const {
    for (const auto& m : m_items)
        if (cid(m) == clientId) return QJsonDocument::fromJson(m.value(QStringLiteral("meta")).toString().toUtf8()).object();
    return {};
}

qint64 MessageListModel::oldestSeq() const {
    for (const auto& m : m_items)
        if (seqOf(m) > 0) return seqOf(m);
    return 0;
}

qint64 MessageListModel::newestSeq() const {
    for (auto it = m_items.crbegin(); it != m_items.crend(); ++it)
        if (seqOf(*it) > 0) return seqOf(*it);
    return 0;
}

}  // namespace ngoma
