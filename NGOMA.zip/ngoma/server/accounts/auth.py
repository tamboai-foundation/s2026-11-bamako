from django.utils import timezone
from rest_framework import authentication, exceptions

from .models import Device, hash_token

SCHEME = "Device"


def device_from_token(raw: str):
    if not raw:
        return None
    try:
        device = Device.objects.select_related("user").get(token_hash=hash_token(raw), revoked_at__isnull=True)
    except Device.DoesNotExist:
        return None
    if not device.user.is_active:
        return None
    return device


class DeviceTokenAuthentication(authentication.BaseAuthentication):
    """En-tête : `Authorization: Device <jeton>`. request.auth contient l'objet Device."""

    def authenticate(self, request):
        header = authentication.get_authorization_header(request).decode("latin-1")
        if not header:
            return None
        parts = header.split()
        if len(parts) != 2 or parts[0] != SCHEME:
            return None
        device = device_from_token(parts[1])
        if device is None:
            raise exceptions.AuthenticationFailed("Jeton d'appareil invalide ou révoqué")
        now = timezone.now()
        if device.last_seen_at is None or (now - device.last_seen_at).total_seconds() > 60:
            Device.objects.filter(pk=device.pk).update(last_seen_at=now)
        return device.user, device

    def authenticate_header(self, request):
        return SCHEME
