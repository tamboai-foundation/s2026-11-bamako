// Ngoma — terminal embarqué de messagerie instantanée.
// Interface unique : Qt Quick (QML), plein écran, sans bureau ni navigateur.
#include <QFontDatabase>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlComponent>
#include <QQmlContext>
#include <QQuickStyle>
#include <QTranslator>
#include <QtQml>

#include "core/Config.h"
#include "ui/AppController.h"

int main(int argc, char* argv[]) {
    // Embarqué : rendu plein écran KMS/DRM sans compositeur si aucune plateforme n'est imposée.
    if (qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM") && qEnvironmentVariableIsEmpty("WAYLAND_DISPLAY") &&
        qEnvironmentVariableIsEmpty("DISPLAY"))
        qputenv("QT_QPA_PLATFORM", "eglfs");
    if (qEnvironmentVariableIsEmpty("QT_IM_MODULE")) qputenv("QT_IM_MODULE", "qtvirtualkeyboard");

    QGuiApplication app(argc, argv);
    QGuiApplication::setApplicationName(QStringLiteral("Ngoma"));
    QGuiApplication::setOrganizationName(QStringLiteral("Ngoma"));
    QGuiApplication::setApplicationVersion(QStringLiteral(NGOMA_VERSION));
    QQuickStyle::setStyle(QStringLiteral("Basic"));

    QTranslator translator;
    if (translator.load(QLocale(), QStringLiteral("ngoma"), QStringLiteral("_"), QStringLiteral(":/i18n")))
        QGuiApplication::installTranslator(&translator);

    ngoma::AppController controller(ngoma::Config::load());
    qmlRegisterSingletonInstance("Ngoma.Core", 1, 0, "App", &controller);

    QQmlApplicationEngine engine;

    // Auto-test d'intégration QML (CI) : instancie chaque page et échoue sur la moindre erreur ou avertissement.
    if (qEnvironmentVariableIsSet("NGOMA_QML_SELFTEST")) {
        int problems = 0;
        QObject::connect(&engine, &QQmlEngine::warnings, [&](const QList<QQmlError>& ws) {
            for (const auto& w : ws) {
                qCritical().noquote() << "QML :" << w.toString();
                ++problems;
            }
        });
        for (const char* page : {"Main", "EnrollPage", "ConversationsPage", "ChatPage", "NewConversationPage",
                                 "SettingsPage", "CallOverlay", "MessageBubble", "StatusBar", "AppButton",
                                 "IconButton", "AppTextField", "Avatar", "PageHeader"}) {
            QQmlComponent c(&engine, QUrl(QStringLiteral("qrc:/qt/qml/Ngoma/%1.qml").arg(QLatin1String(page))));
            std::unique_ptr<QObject> obj(c.create());
            if (!obj) {
                qCritical().noquote() << page << ":" << c.errorString();
                ++problems;
            }
            QCoreApplication::processEvents();
        }
        qInfo("auto-test QML : %d problème(s)", problems);
        return problems == 0 ? 0 : 1;
    }
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed, &app, [] { QCoreApplication::exit(1); },
                     Qt::QueuedConnection);
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    engine.loadFromModule("Ngoma", "Main");
#else
    engine.load(QUrl(QStringLiteral("qrc:/qt/qml/Ngoma/Main.qml")));
#endif
    controller.boot();
    return app.exec();
}
