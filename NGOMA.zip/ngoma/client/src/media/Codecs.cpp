#include "media/Codecs.h"

#include <alsa/asoundlib.h>
#include <opus/opus.h>

#include <cmath>
#include <cstdlib>
#include <cstring>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/opt.h>
#include <libswscale/swscale.h>
}

namespace ngoma::media {

namespace {
_snd_pcm* openPcm(snd_pcm_stream_t dir) {
    if (std::getenv("NGOMA_AUDIO_TEST")) return nullptr;
    snd_pcm_t* pcm = nullptr;
    const char* dev = std::getenv("NGOMA_ALSA_DEVICE") ? std::getenv("NGOMA_ALSA_DEVICE") : "default";
    if (snd_pcm_open(&pcm, dev, dir, SND_PCM_NONBLOCK) < 0) return nullptr;
    if (snd_pcm_set_params(pcm, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, 1, kSampleRate, 1, 60000) < 0) {
        snd_pcm_close(pcm);
        return nullptr;
    }
    return pcm;
}
}  // namespace

float rms(const std::int16_t* pcm, int n) {
    double acc = 0;
    for (int i = 0; i < n; ++i) acc += double(pcm[i]) * pcm[i];
    return float(std::sqrt(acc / std::max(1, n)) / 32768.0);
}

// ------------------------------------------------------------------ capture / restitution

bool AudioCapture::open() {
    m_pcm = openPcm(SND_PCM_STREAM_CAPTURE);
    m_test = m_pcm == nullptr;
    const char* t = std::getenv("NGOMA_AUDIO_TEST");
    m_sine = t && std::strcmp(t, "sine") == 0;
    if (m_pcm) snd_pcm_start(m_pcm);
    return true;  // une source de test remplace toujours un micro absent
}

void AudioCapture::close() {
    if (m_pcm) snd_pcm_close(m_pcm);
    m_pcm = nullptr;
    m_ring.clear();
}

bool AudioCapture::read(std::int16_t* out) {
    if (m_test) {
        for (int i = 0; i < kFrameSamples; ++i) {
            out[i] = m_sine ? std::int16_t(8000 * std::sin(m_phase)) : 0;
            m_phase += 2 * M_PI * 440.0 / kSampleRate;
        }
        return true;
    }
    std::int16_t buf[kFrameSamples * 2];
    for (;;) {
        const snd_pcm_sframes_t n = snd_pcm_readi(m_pcm, buf, kFrameSamples);
        if (n == -EAGAIN) break;
        if (n < 0) {
            snd_pcm_recover(m_pcm, int(n), 1);
            break;
        }
        m_ring.insert(m_ring.end(), buf, buf + n);
    }
    if (m_ring.size() < size_t(kFrameSamples)) return false;
    std::memcpy(out, m_ring.data(), kFrameSamples * sizeof(std::int16_t));
    m_ring.erase(m_ring.begin(), m_ring.begin() + kFrameSamples);
    if (m_ring.size() > size_t(kFrameSamples * 5)) m_ring.clear();  // dérive d'horloge : on rattrape
    return true;
}

bool AudioPlayback::open() {
    m_pcm = openPcm(SND_PCM_STREAM_PLAYBACK);
    return true;
}

void AudioPlayback::close() {
    if (m_pcm) {
        snd_pcm_drop(m_pcm);
        snd_pcm_close(m_pcm);
    }
    m_pcm = nullptr;
}

void AudioPlayback::write(const std::int16_t* pcm) {
    if (!m_pcm) return;
    const snd_pcm_sframes_t n = snd_pcm_writei(m_pcm, pcm, kFrameSamples);
    if (n < 0) snd_pcm_recover(m_pcm, int(n), 1);
}

// ------------------------------------------------------------------ Opus

OpusCodec::~OpusCodec() {
    if (m_enc) opus_encoder_destroy(m_enc);
    if (m_dec) opus_decoder_destroy(m_dec);
}

bool OpusCodec::init() {
    int err = 0;
    m_enc = opus_encoder_create(kSampleRate, 1, OPUS_APPLICATION_VOIP, &err);
    if (err != OPUS_OK) return false;
    opus_encoder_ctl(m_enc, OPUS_SET_BITRATE(24000));
    opus_encoder_ctl(m_enc, OPUS_SET_INBAND_FEC(1));
    opus_encoder_ctl(m_enc, OPUS_SET_PACKET_LOSS_PERC(10));
    opus_encoder_ctl(m_enc, OPUS_SET_DTX(0));
    m_dec = opus_decoder_create(kSampleRate, 1, &err);
    return err == OPUS_OK;
}

int OpusCodec::encode(const std::int16_t* pcm, std::uint8_t* out, int maxBytes) {
    return opus_encode(m_enc, pcm, kFrameSamples, out, maxBytes);
}

int OpusCodec::decode(const std::uint8_t* data, int len, std::int16_t* pcm) {
    return opus_decode(m_dec, data, data ? len : 0, pcm, kFrameSamples, 0);
}

void JitterBuffer::push(std::uint32_t ts, const std::uint8_t* data, std::size_t len) {
    if (m_started && std::int32_t(ts - m_next) < 0) return;  // trop tard
    m_q[ts].assign(data, data + len);
    while (m_q.size() > 50) m_q.erase(m_q.begin());
}

bool JitterBuffer::pop(std::vector<std::uint8_t>& out) {
    if (!m_started) {
        if (m_q.size() < 3) return false;
        m_started = true;
        m_next = m_q.begin()->first;
    }
    auto it = m_q.find(m_next);
    m_next += kFrameSamples;
    if (it != m_q.end()) {
        out = std::move(it->second);
        m_q.erase(m_q.begin(), std::next(it));
        m_misses = 0;
        return true;
    }
    out.clear();
    if (++m_misses > 25) {  // flux interrompu (> 0,5 s) : réamorçage
        m_started = false;
        m_misses = 0;
        return false;
    }
    return true;
}

// ------------------------------------------------------------------ vidéo

VideoEncoder::~VideoEncoder() {
    sws_freeContext(m_sws);
    av_packet_free(&m_pkt);
    av_frame_free(&m_frame);
    avcodec_free_context(&m_ctx);
}

bool VideoEncoder::open(int width, int height, int fps, int bitrateKbps, std::string& name) {
    std::vector<const char*> candidates;
    if (const char* forced = std::getenv("NGOMA_H264_ENCODER")) candidates.push_back(forced);
    for (const char* n : {"h264_v4l2m2m", "libx264", "libopenh264"}) candidates.push_back(n);
    for (const char* n : candidates) {
        const AVCodec* codec = avcodec_find_encoder_by_name(n);
        if (!codec) continue;
        AVCodecContext* ctx = avcodec_alloc_context3(codec);
        ctx->width = width;
        ctx->height = height;
        ctx->time_base = {1, fps};
        ctx->framerate = {fps, 1};
        ctx->pix_fmt = AV_PIX_FMT_YUV420P;
        ctx->bit_rate = std::int64_t(bitrateKbps) * 1000;
        ctx->gop_size = fps * 2;
        ctx->max_b_frames = 0;
        ctx->flags |= AV_CODEC_FLAG_LOW_DELAY;
        if (std::strcmp(n, "libx264") == 0) {
            av_opt_set(ctx->priv_data, "preset", "ultrafast", 0);
            av_opt_set(ctx->priv_data, "tune", "zerolatency", 0);
            av_opt_set(ctx->priv_data, "profile", "baseline", 0);
        }
        if (avcodec_open2(ctx, codec, nullptr) == 0) {
            m_ctx = ctx;
            name = n;
            break;
        }
        avcodec_free_context(&ctx);
    }
    if (!m_ctx) return false;
    m_frame = av_frame_alloc();
    m_frame->format = AV_PIX_FMT_YUV420P;
    m_frame->width = width;
    m_frame->height = height;
    av_frame_get_buffer(m_frame, 0);
    m_pkt = av_packet_alloc();
    m_sws = sws_getContext(width, height, AV_PIX_FMT_BGR0, width, height, AV_PIX_FMT_YUV420P, SWS_FAST_BILINEAR, nullptr,
                           nullptr, nullptr);
    return m_sws != nullptr;
}

std::vector<std::uint8_t> VideoEncoder::encode(const std::uint8_t* bgrx, bool forceKeyframe, bool& isKey) {
    std::vector<std::uint8_t> out;
    isKey = false;
    if (!m_ctx) return out;
    av_frame_make_writable(m_frame);
    const std::uint8_t* src[1] = {bgrx};
    const int srcStride[1] = {m_ctx->width * 4};
    sws_scale(m_sws, src, srcStride, 0, m_ctx->height, m_frame->data, m_frame->linesize);
    m_frame->pts = m_pts++;
    m_frame->pict_type = forceKeyframe ? AV_PICTURE_TYPE_I : AV_PICTURE_TYPE_NONE;
#if LIBAVUTIL_VERSION_INT >= AV_VERSION_INT(58, 7, 100)
    if (forceKeyframe) m_frame->flags |= AV_FRAME_FLAG_KEY;
    else m_frame->flags &= ~AV_FRAME_FLAG_KEY;
#else
    m_frame->key_frame = forceKeyframe ? 1 : 0;
#endif
    if (avcodec_send_frame(m_ctx, m_frame) < 0) return out;
    while (avcodec_receive_packet(m_ctx, m_pkt) == 0) {
        out.insert(out.end(), m_pkt->data, m_pkt->data + m_pkt->size);
        if (m_pkt->flags & AV_PKT_FLAG_KEY) isKey = true;
        av_packet_unref(m_pkt);
    }
    return out;
}

VideoDecoder::~VideoDecoder() {
    sws_freeContext(m_sws);
    av_packet_free(&m_pkt);
    av_frame_free(&m_frame);
    avcodec_free_context(&m_ctx);
}

bool VideoDecoder::open() {
    const AVCodec* codec = avcodec_find_decoder(AV_CODEC_ID_H264);
    if (!codec) return false;
    m_ctx = avcodec_alloc_context3(codec);
    m_ctx->flags |= AV_CODEC_FLAG_LOW_DELAY;
    m_ctx->thread_count = 1;  // pas de file de trames : latence minimale
    if (avcodec_open2(m_ctx, codec, nullptr) != 0) return false;
    m_frame = av_frame_alloc();
    m_pkt = av_packet_alloc();
    return true;
}

bool VideoDecoder::decode(const std::uint8_t* data, std::size_t len, std::vector<std::uint8_t>& out, int& width, int& height) {
    if (!m_ctx) return false;
    if (av_new_packet(m_pkt, int(len)) < 0) return false;
    std::memcpy(m_pkt->data, data, len);
    const int sent = avcodec_send_packet(m_ctx, m_pkt);
    av_packet_unref(m_pkt);
    if (sent < 0) return false;
    bool got = false;
    while (avcodec_receive_frame(m_ctx, m_frame) == 0) {
        width = m_frame->width;
        height = m_frame->height;
        if (!m_sws || m_swsW != width || m_swsH != height) {
            sws_freeContext(m_sws);
            m_sws = sws_getContext(width, height, AVPixelFormat(m_frame->format), width, height, AV_PIX_FMT_BGR0,
                                   SWS_FAST_BILINEAR, nullptr, nullptr, nullptr);
            m_swsW = width;
            m_swsH = height;
        }
        out.resize(size_t(width) * size_t(height) * 4);
        std::uint8_t* dst[1] = {out.data()};
        const int dstStride[1] = {width * 4};
        sws_scale(m_sws, m_frame->data, m_frame->linesize, 0, height, dst, dstStride);
        got = true;
    }
    return got;
}

bool FrameAssembler::add(std::uint32_t frameId, std::uint16_t idx, std::uint16_t count, bool key, const std::uint8_t* data,
                         std::size_t len, std::vector<std::uint8_t>& frame, bool& isKey) {
    if (count == 0 || idx >= count || count > 512) return false;
    if (m_active && std::int32_t(frameId - m_id) < 0) return false;  // fragment d'une trame déjà dépassée
    if (!m_active || frameId != m_id) {
        if (m_active && m_have < m_count) m_needKey = true;  // trame précédente incomplète : perte
        if (m_active && frameId != m_lastComplete + 1 && !key) m_needKey = true;
        m_id = frameId;
        m_count = count;
        m_key = key;
        m_parts.assign(count, {});
        m_have = 0;
        m_active = true;
    }
    if (count != m_count || !m_parts[idx].empty()) return false;
    m_parts[idx].assign(data, data + len);
    if (++m_have < m_count) return false;
    frame.clear();
    for (auto& p : m_parts) frame.insert(frame.end(), p.begin(), p.end());
    isKey = m_key;
    m_lastComplete = m_id;
    m_active = false;
    if (m_needKey && !isKey) return false;  // attente d'une image clé après une perte
    if (isKey) m_needKey = false;
    return true;
}

}  // namespace ngoma::media
