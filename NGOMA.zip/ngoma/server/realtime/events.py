"""Diffusion des signaux temps réel vers les groupes Channels."""
import logging

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

log = logging.getLogger(__name__)


def user_group(user_id: int) -> str:
    return f"user.{user_id}"


def device_group(device_id) -> str:
    return f"device.{device_id}"


def send_to_users(user_ids, data: dict) -> None:
    layer = get_channel_layer()
    if layer is None:
        return
    send = async_to_sync(layer.group_send)
    for uid in set(user_ids):
        try:
            send(user_group(uid), {"type": "ngoma.event", "data": data})
        except Exception:  # une couche de canaux saturée ne doit jamais faire échouer une écriture déjà validée
            log.exception("diffusion impossible vers l'utilisateur %s", uid)


def kick_device(device) -> None:
    layer = get_channel_layer()
    if layer is None:
        return
    async_to_sync(layer.group_send)(device_group(device.pk), {"type": "ngoma.kick"})
