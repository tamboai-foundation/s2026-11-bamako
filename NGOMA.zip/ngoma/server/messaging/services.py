"""Moteur de synchronisation interne de Ngoma (côté serveur).

Contrat :
  * Chaque conversation possède un compteur `last_seq` strictement croissant.
  * `push` est idempotent sur (messaging, client_id) : un renvoi retourne le même seq.
  * Le contenu est chiffré de bout en bout : le client fournit une enveloppe par appareil
    actif de chaque membre (y compris ses autres appareils). Si l'ensemble ne correspond pas,
    le serveur répond 409 avec la liste des appareils attendus ; le client rafraîchit ses clés et renvoie.
  * Après commit, un signal léger `sync.changed {messaging, seq}` est diffusé aux membres ;
    le client relit avec `pull(after_seq)`. Le signal ne transporte jamais de données.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
from dataclasses import dataclass
from datetime import timedelta

from django.conf import settings
from django.db import IntegrityError, transaction
from django.utils import timezone

from accounts.models import Device

from .models import Envelope, Membership, Message, Messaging, Receipt


class SyncError(Exception):
    status = 400

    def __init__(self, detail: str, **extra):
        super().__init__(detail)
        self.detail = detail
        self.extra = extra


class Forbidden(SyncError):
    status = 403


class NotFound(SyncError):
    status = 404


class DeviceSetMismatch(SyncError):
    status = 409


@dataclass(frozen=True)
class PushResult:
    message: Message
    created: bool


# ---------------------------------------------------------------- conversations

def _direct_key(a: int, b: int) -> str:
    lo, hi = sorted((a, b))
    return hashlib.sha256(f"{lo}:{hi}".encode()).hexdigest()


def membership_or_raise(user, messaging_id) -> Membership:
    try:
        return Membership.objects.select_related("messaging").get(messaging_id=messaging_id, user=user)
    except Membership.DoesNotExist as exc:
        raise NotFound("Conversation inconnue") from exc


@transaction.atomic
def create_conversation(creator, kind: str, member_ids: list[int], title: str = "") -> tuple[Messaging, bool]:
    from django.contrib.auth import get_user_model

    User = get_user_model()
    member_ids = sorted({int(i) for i in member_ids} - {creator.id})
    if not member_ids:
        raise SyncError("Au moins un autre membre est requis")
    if len(member_ids) + 1 > settings.NGOMA["MAX_GROUP_MEMBERS"]:
        raise SyncError("Trop de membres")
    users = list(User.objects.filter(pk__in=member_ids, is_active=True))
    if len(users) != len(member_ids):
        raise SyncError("Membre inconnu")

    if kind == Messaging.DIRECT:
        if len(users) != 1:
            raise SyncError("Une conversation directe a exactement deux membres")
        key = _direct_key(creator.id, users[0].id)
        existing = Messaging.objects.filter(direct_key=key).first()
        if existing:
            return existing, False
        conv = Messaging.objects.create(kind=kind, created_by=creator, direct_key=key)
    elif kind == Messaging.GROUP:
        conv = Messaging.objects.create(kind=kind, created_by=creator, title=title[:200])
    else:
        raise SyncError("Type de conversation inconnu")

    Membership.objects.create(messaging=conv, user=creator, role=Membership.ADMIN)
    Membership.objects.bulk_create([Membership(messaging=conv, user=u) for u in users])
    _notify_after_commit(conv, [creator.id, *member_ids], event="conversation")
    return conv, True


def conversations_for(user):
    return (
        Messaging.objects.filter(memberships__user=user)
        .prefetch_related("memberships__user")
        .order_by("-updated_at")
    )


# ---------------------------------------------------------------- push

def validate_payload(payload) -> str:
    """Contrôle de forme d'une enveloppe v2 (le serveur ne peut pas en vérifier le contenu). Renvoie le JSON compact."""
    limit = settings.NGOMA["MAX_CIPHERTEXT_BYTES"]
    try:
        if not isinstance(payload, dict) or payload.get("v") != 2 or payload.get("type") not in ("prekey", "msg"):
            raise ValueError("forme")
        if len(base64.b64decode(payload["h"], validate=True)) != 40:
            raise ValueError("en-tête")
        if len(base64.b64decode(payload["c"], validate=True)) > limit:
            raise SyncError("Message trop volumineux")
        if payload["type"] == "prekey":
            x = payload["x"]
            for k in ("ik", "ek"):
                if len(base64.b64decode(x[k], validate=True)) != 32:
                    raise ValueError(k)
            int(x["spk"])
        allowed = {"v", "type", "h", "c", "x"}
        if set(payload) - allowed:
            raise ValueError("champ inconnu")
    except (KeyError, TypeError, ValueError, binascii.Error) as exc:
        raise SyncError("Enveloppe invalide") from exc
    return json.dumps(payload, separators=(",", ":"))


def _validate_envelopes(envelopes: list[dict]) -> dict[str, str]:
    if not isinstance(envelopes, list):
        raise SyncError("Enveloppes manquantes")
    by_device: dict[str, str] = {}
    for env in envelopes:
        if not isinstance(env, dict) or "device_id" not in env:
            raise SyncError("Enveloppe invalide")
        by_device[str(env["device_id"])] = validate_payload(env.get("payload"))
    return by_device


def expected_devices(messaging: Messaging, exclude_device: Device | None = None) -> list[Device]:
    # Seuls les appareils ayant publié une prékey signée sont joignables (X3DH impossible sinon).
    qs = Device.objects.filter(
        user__memberships__messaging=messaging, revoked_at__isnull=True, user__is_active=True,
        signed_prekey__isnull=False,
    )
    if exclude_device is not None:
        qs = qs.exclude(pk=exclude_device.pk)
    return list(qs.order_by("user_id", "created_at"))


def push_message(
    *, user, device: Device, messaging_id, client_id, envelopes: list[dict], kind: str = Message.TEXT,
    expires_in: int | None = None,
) -> PushResult:
    membership = membership_or_raise(user, messaging_id)
    messaging = membership.messaging

    # Idempotence : un renvoi après une coupure réseau retourne le message déjà enregistré.
    existing = Message.objects.filter(messaging=messaging, client_id=client_id).first()
    if existing:
        return PushResult(existing, False)

    if kind not in {Message.TEXT, Message.MEDIA}:
        raise SyncError("Type de message invalide")
    by_device = _validate_envelopes(envelopes)
    expected = expected_devices(messaging, exclude_device=device)
    expected_ids = {str(d.pk) for d in expected}
    given_ids = set(by_device) - {str(device.pk)}
    if given_ids != expected_ids:
        raise DeviceSetMismatch(
            "Liste d'appareils obsolète",
            devices={
                str(d.pk): {"user_id": d.user_id, "public_key": d.public_key} for d in expected
            },
        )

    expires_at = None
    if expires_in:
        expires_in = int(expires_in)
        if not 5 <= expires_in <= 7 * 24 * 3600:
            raise SyncError("Durée éphémère hors bornes")
        expires_at = timezone.now() + timedelta(seconds=expires_in)

    try:
        with transaction.atomic():
            # Verrou de ligne sur la conversation : attribution séquentielle sans trou.
            locked = Messaging.objects.select_for_update().get(pk=messaging.pk)
            seq = locked.last_seq + 1
            now = timezone.now()
            Messaging.objects.filter(pk=locked.pk).update(last_seq=seq, updated_at=now)
            msg = Message.objects.create(
                messaging=locked, seq=seq, client_id=client_id, sender=user, sender_device=device,
                kind=kind, expires_at=expires_at, created_at=now,
            )
            targets = {str(d.pk): d for d in expected}
            if str(device.pk) in by_device:
                targets[str(device.pk)] = device
            Envelope.objects.bulk_create(
                [
                    Envelope(message=msg, device=d, payload=by_device[k])
                    for k, d in targets.items()
                ]
            )
            _notify_after_commit(locked, _member_ids(locked), event="message", seq=seq)
    except IntegrityError:
        # Course entre deux renvois simultanés du même client_id.
        msg = Message.objects.get(messaging=messaging, client_id=client_id)
        return PushResult(msg, False)
    return PushResult(msg, True)


def add_system_message(messaging_id, sender, text: str) -> Message:
    """Message système non chiffré (ex. « assistant désactivé »), visible par tous les membres."""
    import uuid as _uuid

    with transaction.atomic():
        locked = Messaging.objects.select_for_update().get(pk=messaging_id)
        seq = locked.last_seq + 1
        Messaging.objects.filter(pk=locked.pk).update(last_seq=seq, updated_at=timezone.now())
        msg = Message.objects.create(messaging=locked, seq=seq, client_id=_uuid.uuid4(), sender=sender,
                                     kind=Message.SYSTEM, system_text=text[:300])
        _notify_after_commit(locked, _member_ids(locked), event="message", seq=seq)
    return msg


# ---------------------------------------------------------------- pull

def pull_messages(*, user, device: Device, messaging_id, after_seq: int, limit: int):
    membership = membership_or_raise(user, messaging_id)
    limit = max(1, min(int(limit), settings.NGOMA["PULL_PAGE_MAX"]))
    start = max(int(after_seq), membership.visible_from_seq - 1)
    now = timezone.now()
    msgs = list(
        Message.objects.filter(messaging_id=messaging_id, seq__gt=start)
        .exclude(expires_at__lt=now)
        .select_related("sender_device")
        .order_by("seq")[: limit + 1]
    )
    has_more = len(msgs) > limit
    msgs = msgs[:limit]
    envs = {
        e.message_id: e
        for e in Envelope.objects.filter(message__in=msgs, device=device)
    }
    items = []
    for m in msgs:
        env = envs.get(m.id)
        items.append(
            {
                "id": str(m.id),
                "seq": m.seq,
                "client_id": str(m.client_id),
                "sender_id": m.sender_id,
                "sender_device_id": str(m.sender_device_id) if m.sender_device_id else None,
                "sender_public_key": m.sender_device.public_key if m.sender_device else None,
                "kind": m.kind,
                "system_text": m.system_text,
                "created_at": m.created_at.isoformat(),
                "expires_at": m.expires_at.isoformat() if m.expires_at else None,
                "envelope": json.loads(env.payload) if env else None,
            }
        )
    last_seq = membership.messaging.last_seq
    return {"messaging_id": str(messaging_id), "items": items, "has_more": has_more, "last_seq": last_seq}


def sync_state(user) -> list[dict]:
    """Curseurs serveur de toutes les conversations : utilisé au démarrage et après reconnexion."""
    rows = Messaging.objects.filter(memberships__user=user).values("id", "last_seq", "updated_at")
    return [{"messaging_id": str(r["id"]), "last_seq": r["last_seq"], "updated_at": r["updated_at"].isoformat()} for r in rows]


# ---------------------------------------------------------------- receipts

def ack(*, user, messaging_id, delivered_seq: int | None = None, read_seq: int | None = None) -> Receipt:
    membership = membership_or_raise(user, messaging_id)
    last = membership.messaging.last_seq
    receipt, _ = Receipt.objects.get_or_create(messaging_id=messaging_id, user=user)
    changed = False
    if delivered_seq is not None and receipt.delivered_seq < min(int(delivered_seq), last):
        receipt.delivered_seq = min(int(delivered_seq), last)
        changed = True
    if read_seq is not None and receipt.read_seq < min(int(read_seq), last):
        receipt.read_seq = min(int(read_seq), last)
        receipt.delivered_seq = max(receipt.delivered_seq, receipt.read_seq)
        changed = True
    if changed:
        receipt.updated_at = timezone.now()
        receipt.save()
        _notify_after_commit(
            membership.messaging, _member_ids(membership.messaging), event="receipt",
            user_id=user.id, delivered_seq=receipt.delivered_seq, read_seq=receipt.read_seq,
        )
    return receipt


# ---------------------------------------------------------------- maintenance

def purge_media(retention_days: int | None = None) -> int:
    from .models import Media

    days = retention_days or settings.NGOMA["MEDIA_RETENTION_DAYS"]
    old = Media.objects.filter(created_at__lt=timezone.now() - timedelta(days=days))
    n = 0
    for m in old.iterator():
        m.blob.delete(save=False)
        m.delete()
        n += 1
    return n


def purge_expired(batch: int = 5000) -> int:
    now = timezone.now()
    total = 0
    while True:
        ids = list(Message.objects.filter(expires_at__lt=now).values_list("id", flat=True)[:batch])
        if not ids:
            return total
        Message.objects.filter(id__in=ids).delete()
        total += len(ids)


# ---------------------------------------------------------------- signaux

def _member_ids(messaging: Messaging) -> list[int]:
    return list(Membership.objects.filter(messaging=messaging).values_list("user_id", flat=True))


def _notify_after_commit(messaging: Messaging, user_ids: list[int], *, event: str, **payload) -> None:
    from realtime.events import send_to_users

    data = {"event": event, "messaging_id": str(messaging.pk), **payload}
    transaction.on_commit(lambda: send_to_users(user_ids, data))
