#pragma once

#include <QHash>
#include <QJsonObject>
#include <QJsonValue>
#include <QLocalSocket>
#include <QObject>
#include <QTimer>
#include <functional>

namespace ngoma {

/// Client du démon ngoma-store (T-Modeler) : JSON-lignes sur socket Unix.
/// Les requêtes émises pendant une reconnexion sont mises en file et rejouées.
class StoreClient : public QObject {
    Q_OBJECT
public:
    using Callback = std::function<void(bool ok, const QJsonValue& result, const QString& error)>;

    explicit StoreClient(QString socketPath, QObject* parent = nullptr);
    ~StoreClient() override;
    void connectToDaemon();
    bool isReady() const { return m_sock.state() == QLocalSocket::ConnectedState; }

    void call(const QString& op, const QJsonObject& args, Callback cb = {});

signals:
    void readyChanged(bool ready);
    void changed(const QString& scope, const QString& messagingId);

private:
    void onReadyRead();
    void flushQueue();

    QString m_path;
    QLocalSocket m_sock;
    QTimer m_retry;
    QByteArray m_buffer;
    qint64 m_nextId = 1;
    QHash<qint64, Callback> m_pending;
    QList<QByteArray> m_queue;
};

}  // namespace ngoma
