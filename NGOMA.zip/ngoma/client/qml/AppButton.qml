import QtQuick
import QtQuick.Controls

// Bouton NGOMA. variant : "primary" (accent), "secondary", "danger", "ghost" (texte accent, sans fond).
Button {
    id: control
    property string variant: "secondary"
    property string iconName: ""

    implicitHeight: Theme.touch
    implicitWidth: Math.max(120, contentItem.implicitWidth + 40)
    font.pixelSize: Theme.fontBody
    font.weight: Font.DemiBold
    hoverEnabled: true

    readonly property color fg: !enabled ? Theme.textDisabled
                               : variant === "primary" ? Theme.accentText
                               : variant === "ghost" ? Theme.accent
                               : Theme.text

    contentItem: Item {
      implicitWidth: btnRow.implicitWidth
      implicitHeight: btnRow.implicitHeight
      Row {
        id: btnRow
        spacing: 10
        anchors.centerIn: parent
        Image {
            visible: control.iconName.length > 0
            source: visible ? Theme.icon(control.iconName, control.variant === "primary" ? "dark" : (control.variant === "ghost" ? "accent" : "light")) : ""
            sourceSize: Qt.size(20, 20)
            anchors.verticalCenter: parent.verticalCenter
            opacity: control.enabled ? 1 : 0.4
        }
        Text {
            text: control.text
            font: control.font
            color: control.fg
            anchors.verticalCenter: parent.verticalCenter
            elide: Text.ElideRight
        }
      }
    }

    background: Rectangle {
        radius: Theme.radiusSmall
        color: {
            if (control.variant === "ghost") return control.down ? Theme.surfacePressed : (control.hovered ? Theme.surfaceHigh : "transparent")
            if (!control.enabled) return Theme.surfaceHigh
            if (control.variant === "primary") return control.down ? Theme.accentPressed : (control.hovered ? Theme.accentHover : Theme.accent)
            if (control.variant === "danger") return control.down ? Theme.dangerPressed : Theme.danger
            return control.down ? Theme.surfacePressed : (control.hovered ? Theme.surfaceHover : Theme.surfaceHigh)
        }
        border.width: control.variant === "secondary" ? 1 : 0
        border.color: Theme.outline
        Behavior on color { ColorAnimation { duration: 90 } }
    }
}
