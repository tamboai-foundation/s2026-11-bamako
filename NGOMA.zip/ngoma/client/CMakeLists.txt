cmake_minimum_required(VERSION 3.21)
project(Ngoma VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

option(NGOMA_WITH_ICEORYX2 "Bus IPC zéro copie iceoryx2 (médias, événements locaux)" ON)
option(NGOMA_BUILD_TESTS "Tests unitaires Qt Test" ON)
# Production : Qt 6.8 LTS. 6.4 accepté pour les bancs de compilation de développement.
set(NGOMA_QT_MIN 6.8 CACHE STRING "Version minimale de Qt")

# Qt est lié DYNAMIQUEMENT (édition open source, LGPLv3) : aucune liaison statique de Qt,
# bibliothèques Qt remplaçables par l'utilisateur final (voir docs/LICENSING.md).
set(BUILD_SHARED_LIBS ON)

find_package(Qt6 ${NGOMA_QT_MIN} REQUIRED COMPONENTS Core Gui Network WebSockets Qml Quick QuickControls2 Svg)
find_package(PkgConfig REQUIRED)
pkg_check_modules(SODIUM REQUIRED IMPORTED_TARGET libsodium)

if(NGOMA_WITH_ICEORYX2)
    find_package(iceoryx2-cxx REQUIRED)
endif()

qt_standard_project_setup()

if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    add_compile_options(-Wall -Wextra -Wpedantic -Werror=return-type -fstack-protector-strong -D_FORTIFY_SOURCE=2)
    add_link_options(-Wl,-z,relro,-z,now)
endif()

# ------------------------------------------------------------------ cœur (bibliothèque testable)
add_library(ngoma_core STATIC
    src/core/Config.cpp
    src/core/Crypto.cpp
    src/core/Ratchet.cpp
    src/core/SecretStore.cpp
    src/core/ApiClient.cpp
    src/core/RealtimeClient.cpp
    src/core/StoreClient.cpp
    src/core/SyncEngine.cpp
    src/ipc/IpcBus.cpp
    src/ui/ConversationListModel.cpp
    src/ui/MessageListModel.cpp
)
set_target_properties(ngoma_core PROPERTIES AUTOMOC ON POSITION_INDEPENDENT_CODE ON)
target_include_directories(ngoma_core PUBLIC src)
target_link_libraries(ngoma_core PUBLIC Qt6::Core Qt6::Gui Qt6::Network Qt6::WebSockets PkgConfig::SODIUM)
if(NGOMA_WITH_ICEORYX2)
    target_compile_definitions(ngoma_core PUBLIC NGOMA_WITH_ICEORYX2)
    target_link_libraries(ngoma_core PUBLIC iceoryx2-cxx::static-lib-cxx)
endif()

# ------------------------------------------------------------------ application QML
qt_add_executable(ngoma-terminal src/main.cpp src/ui/AppController.cpp src/ui/VideoItem.cpp)
target_compile_definitions(ngoma-terminal PRIVATE NGOMA_VERSION="${PROJECT_VERSION}")
target_link_libraries(ngoma-terminal PRIVATE ngoma_core Qt6::Qml Qt6::Quick Qt6::QuickControls2 Qt6::Svg)
target_include_directories(ngoma-terminal PRIVATE src/ui)

# Les fichiers QML sont rangés dans qml/ mais servis à la racine du module (à côté du qmldir) :
# sans cela l'import implicite du dossier masque le singleton Theme.
file(GLOB NGOMA_QML RELATIVE ${CMAKE_CURRENT_SOURCE_DIR} CONFIGURE_DEPENDS qml/*.qml)
foreach(f ${NGOMA_QML})
    get_filename_component(n ${f} NAME)
    set_source_files_properties(${f} PROPERTIES QT_RESOURCE_ALIAS ${n})
endforeach()
set_source_files_properties(qml/Theme.qml PROPERTIES QT_QML_SINGLETON_TYPE TRUE)
# Icônes SVG (tools/gen_icons.py), servies sous qrc:/qt/qml/Ngoma/icons/
file(GLOB NGOMA_ICONS RELATIVE ${CMAKE_CURRENT_SOURCE_DIR} CONFIGURE_DEPENDS qml/icons/*.svg)
foreach(f ${NGOMA_ICONS})
    get_filename_component(n ${f} NAME)
    set_source_files_properties(${f} PROPERTIES QT_RESOURCE_ALIAS icons/${n})
endforeach()

qt_add_qml_module(ngoma-terminal
    URI Ngoma
    VERSION 1.0
    RESOURCE_PREFIX /qt/qml
    QML_FILES
        qml/Main.qml
        qml/Theme.qml
        qml/EnrollPage.qml
        qml/ConversationsPage.qml
        qml/ChatPage.qml
        qml/NewConversationPage.qml
        qml/CallOverlay.qml
        qml/SettingsPage.qml
        qml/MessageBubble.qml
        qml/StatusBar.qml
        qml/AppButton.qml
        qml/IconButton.qml
        qml/AppTextField.qml
        qml/Avatar.qml
        qml/PageHeader.qml
    RESOURCES
        ${NGOMA_ICONS}
    SOURCES
        src/ui/VideoItem.h
)

# ------------------------------------------------------------------ processus média
if(NGOMA_WITH_ICEORYX2)
    pkg_check_modules(MEDIA REQUIRED IMPORTED_TARGET opus alsa libavcodec libavutil libswscale)
    add_executable(ngoma-media src/media/main.cpp src/media/Transport.cpp src/media/Codecs.cpp)
    target_include_directories(ngoma-media PRIVATE src)
    target_link_libraries(ngoma-media PRIVATE iceoryx2-cxx::static-lib-cxx PkgConfig::MEDIA PkgConfig::SODIUM)
endif()

# ------------------------------------------------------------------ relais média (côté serveur)
add_executable(ngoma-relay ../relay/src/main.cpp)
target_include_directories(ngoma-relay PRIVATE src)
target_link_libraries(ngoma-relay PRIVATE PkgConfig::SODIUM)

# ------------------------------------------------------------------ tests
if(NGOMA_BUILD_TESTS)
    enable_testing()
    find_package(Qt6 REQUIRED COMPONENTS Test)
    foreach(t test_crypto test_models test_ratchet)
        add_executable(${t} tests/${t}.cpp)
        set_target_properties(${t} PROPERTIES AUTOMOC ON)
        target_link_libraries(${t} PRIVATE ngoma_core Qt6::Test)
        target_compile_definitions(${t} PRIVATE NGOMA_SOURCE_DIR="${CMAKE_CURRENT_SOURCE_DIR}")
        add_test(NAME ${t} COMMAND ${t})
    endforeach()
    # Test d'intégration (nécessite un serveur et deux ngoma-store) : lancé par tools/run_integration.sh
    add_executable(integration_sync tests/integration_sync.cpp)
    set_target_properties(integration_sync PROPERTIES AUTOMOC ON)
    target_link_libraries(integration_sync PRIVATE ngoma_core Qt6::Test)
    if(NGOMA_WITH_ICEORYX2)
        add_executable(integration_ipc tests/integration_ipc.cpp)
        set_target_properties(integration_ipc PROPERTIES AUTOMOC ON)
        target_link_libraries(integration_ipc PRIVATE ngoma_core Qt6::Test)
        add_executable(integration_call tests/integration_call.cpp)
        set_target_properties(integration_call PROPERTIES AUTOMOC ON)
        target_link_libraries(integration_call PRIVATE ngoma_core Qt6::Test)
    endif()
endif()

include(GNUInstallDirs)
install(TARGETS ngoma-terminal RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR})
if(NGOMA_WITH_ICEORYX2)
    install(TARGETS ngoma-media RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR})
endif()
install(TARGETS ngoma-relay RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR} COMPONENT server)
