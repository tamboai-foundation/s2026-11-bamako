"""NGOMA Ratchet v2 — X3DH + Double Ratchet (implémentation Python de référence).

Spécification : docs/CRYPTO.md. Implémentation jumelle en C++ : client/src/core/Ratchet.cpp.
Les deux DOIVENT produire des octets identiques ; les tests d'intégration (bot ↔ terminal) le vérifient.

Primitives (libsodium via PyNaCl) : Ed25519 (identité, signature de la prékey signée), X25519 (DH),
HMAC-SHA256 / HKDF-SHA256, XChaCha20-Poly1305 (AEAD).
"""
from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import secrets
import struct
import time

from nacl import bindings as nb
from nacl.signing import SigningKey, VerifyKey

MAX_SKIP = 1000
MAX_SKIPPED_STORED = 2000
SPK_SIG_PREFIX = b"NGM-SPK1"


class CryptoError(Exception):
    pass


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode()


def b64d(s: str) -> bytes:
    return base64.b64decode(s, validate=True)


def hkdf(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    out, t, i = b"", b"", 1
    while len(out) < length:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        out += t
        i += 1
    return out[:length]


def dh(sk: bytes, pk: bytes) -> bytes:
    return nb.crypto_scalarmult(sk, pk)


def x25519_keypair() -> tuple[bytes, bytes]:
    pk, sk = nb.crypto_box_keypair()
    return sk, pk


def ed_to_x_pk(ed_pk: bytes) -> bytes:
    return nb.crypto_sign_ed25519_pk_to_curve25519(ed_pk)


def ed_to_x_sk(ed_sk64: bytes) -> bytes:
    return nb.crypto_sign_ed25519_sk_to_curve25519(ed_sk64)


def kdf_rk(rk: bytes, dh_out: bytes) -> tuple[bytes, bytes]:
    o = hkdf(rk, dh_out, b"NgomaRatchet", 64)
    return o[:32], o[32:]


def kdf_ck(ck: bytes) -> tuple[bytes, bytes]:
    return hmac.new(ck, b"\x02", hashlib.sha256).digest(), hmac.new(ck, b"\x01", hashlib.sha256).digest()


def msg_key_nonce(mk: bytes) -> tuple[bytes, bytes]:
    o = hkdf(b"\x00" * 32, mk, b"NgomaMsg", 56)
    return o[:32], o[32:]


def header_bytes(dh_pub: bytes, pn: int, n: int) -> bytes:
    return dh_pub + struct.pack(">II", pn, n)


def parse_header(h: bytes) -> tuple[bytes, int, int]:
    if len(h) != 40:
        raise CryptoError("en-tête invalide")
    pn, n = struct.unpack(">II", h[32:])
    return h[:32], pn, n


# ---------------------------------------------------------------- clés d'appareil

class DeviceKeys:
    """Clés privées d'un appareil : identité Ed25519, prékey signée (courante + précédente), prékeys à usage unique."""

    def __init__(self, data: dict):
        self.d = data

    @classmethod
    def generate(cls) -> "DeviceKeys":
        sk = SigningKey.generate()
        k = cls({"ik_sk": b64e(bytes(sk) + bytes(sk.verify_key)), "ik_pk": b64e(bytes(sk.verify_key)),
                 "spk": None, "spk_prev": None, "opks": {}, "next_opk_id": 1, "next_spk_id": 1})
        k.rotate_spk()
        return k

    @property
    def identity_pk(self) -> bytes:
        return b64d(self.d["ik_pk"])

    @property
    def identity_sk64(self) -> bytes:
        return b64d(self.d["ik_sk"])

    def rotate_spk(self) -> dict:
        sk, pk = x25519_keypair()
        sid = self.d["next_spk_id"]
        self.d["next_spk_id"] = sid + 1
        sig = nb.crypto_sign(SPK_SIG_PREFIX + pk, self.identity_sk64)[:64]
        self.d["spk_prev"] = self.d["spk"]
        self.d["spk"] = {"id": sid, "sk": b64e(sk), "pk": b64e(pk), "sig": b64e(sig), "created": int(time.time())}
        return self.d["spk"]

    def new_opks(self, count: int) -> list[dict]:
        out = []
        for _ in range(count):
            sk, pk = x25519_keypair()
            oid = self.d["next_opk_id"]
            self.d["next_opk_id"] = oid + 1
            self.d["opks"][str(oid)] = b64e(sk)
            out.append({"id": oid, "key": b64e(pk)})
        return out

    def public_upload(self, opks: list[dict]) -> dict:
        s = self.d["spk"]
        return {"spk_id": s["id"], "spk": s["pk"], "spk_sig": s["sig"], "opks": opks}

    def spk_sk(self, spk_id: int) -> bytes:
        for s in (self.d["spk"], self.d["spk_prev"]):
            if s and s["id"] == spk_id:
                return b64d(s["sk"])
        raise CryptoError("prékey signée inconnue")

    def take_opk(self, opk_id: int) -> bytes:
        sk = self.d["opks"].pop(str(opk_id), None)
        if sk is None:
            raise CryptoError("prékey à usage unique inconnue ou déjà utilisée")
        return b64d(sk)


def verify_bundle(bundle: dict) -> None:
    ik = b64d(bundle["identity_key"])
    spk = b64d(bundle["spk"])
    sig = b64d(bundle["spk_sig"])
    try:
        VerifyKey(ik).verify(SPK_SIG_PREFIX + spk, sig)
    except Exception as exc:  # noqa: BLE001
        raise CryptoError("signature de prékey invalide") from exc


# ---------------------------------------------------------------- session

def _x3dh_sk(parts: list[bytes]) -> bytes:
    return hkdf(b"\x00" * 32, b"\xff" * 32 + b"".join(parts), b"NgomaX3DH", 32)


def initiate(me: DeviceKeys, bundle: dict) -> dict:
    """Ouvre une session vers un appareil à partir de son paquet de prékeys (rôle initiateur)."""
    verify_bundle(bundle)
    their_ik = b64d(bundle["identity_key"])
    their_spk = b64d(bundle["spk"])
    ek_sk, ek_pk = x25519_keypair()
    parts = [dh(ed_to_x_sk(me.identity_sk64), their_spk), dh(ek_sk, ed_to_x_pk(their_ik)), dh(ek_sk, their_spk)]
    opk_id = bundle.get("opk_id")
    if opk_id is not None:
        parts.append(dh(ek_sk, b64d(bundle["opk"])))
    sk = _x3dh_sk(parts)
    dhs_sk, dhs_pk = x25519_keypair()
    rk, cks = kdf_rk(sk, dh(dhs_sk, their_spk))
    return {
        "rk": b64e(rk), "dhs_sk": b64e(dhs_sk), "dhs_pk": b64e(dhs_pk), "dhr": b64e(their_spk),
        "cks": b64e(cks), "ckr": None, "ns": 0, "nr": 0, "pn": 0, "skipped": {},
        "ad": b64e(me.identity_pk + their_ik), "peer_ik": b64e(their_ik),
        "pending": {"ik": b64e(me.identity_pk), "ek": b64e(ek_pk), "spk": bundle["spk_id"], "opk": opk_id},
        "init_ek": None,
    }


def encrypt(session: dict, plaintext: bytes) -> dict:
    """Chiffre et fait avancer la chaîne d'envoi (modifie `session`)."""
    if not session.get("cks"):
        raise CryptoError("aucune chaîne d'envoi")
    ck, mk = kdf_ck(b64d(session["cks"]))
    session["cks"] = b64e(ck)
    h = header_bytes(b64d(session["dhs_pk"]), session["pn"], session["ns"])
    session["ns"] += 1
    key, nonce = msg_key_nonce(mk)
    ct = nb.crypto_aead_xchacha20poly1305_ietf_encrypt(plaintext, b64d(session["ad"]) + h, nonce, key)
    env = {"v": 2, "type": "prekey" if session.get("pending") else "msg", "h": b64e(h), "c": b64e(ct)}
    if session.get("pending"):
        env["x"] = session["pending"]
    return env


def _skip(s: dict, until: int) -> None:
    if s["ckr"] is None:
        return
    if until - s["nr"] > MAX_SKIP:
        raise CryptoError("trop de messages sautés")
    ck = b64d(s["ckr"])
    while s["nr"] < until:
        ck, mk = kdf_ck(ck)
        s["skipped"][f'{s["dhr"]}:{s["nr"]}'] = b64e(mk)
        s["nr"] += 1
    s["ckr"] = b64e(ck)
    while len(s["skipped"]) > MAX_SKIPPED_STORED:
        s["skipped"].pop(next(iter(s["skipped"])))


def _ratchet_decrypt(session: dict, env: dict) -> tuple[bytes, dict]:
    s = copy.deepcopy(session)  # l'état n'est validé qu'après authentification réussie
    h = b64d(env["h"])
    dh_pub, pn, n = parse_header(h)
    dh_b64 = b64e(dh_pub)
    key_id = f"{dh_b64}:{n}"
    if key_id in s["skipped"]:
        mk = b64d(s["skipped"].pop(key_id))
    else:
        if dh_b64 != s["dhr"]:
            _skip(s, pn)
            s["pn"] = s["ns"]
            s["ns"] = 0
            s["nr"] = 0
            s["dhr"] = dh_b64
            rk, ckr = kdf_rk(b64d(s["rk"]), dh(b64d(s["dhs_sk"]), dh_pub))
            dhs_sk, dhs_pk = x25519_keypair()
            rk, cks = kdf_rk(rk, dh(dhs_sk, dh_pub))
            s.update(rk=b64e(rk), ckr=b64e(ckr), cks=b64e(cks), dhs_sk=b64e(dhs_sk), dhs_pk=b64e(dhs_pk))
        _skip(s, n)
        ck, mk = kdf_ck(b64d(s["ckr"]))
        s["ckr"] = b64e(ck)
        s["nr"] += 1
    key, nonce = msg_key_nonce(mk)
    try:
        pt = nb.crypto_aead_xchacha20poly1305_ietf_decrypt(b64d(env["c"]), b64d(s["ad"]) + h, nonce, key)
    except Exception as exc:  # noqa: BLE001
        raise CryptoError("authentification du message impossible") from exc
    s["pending"] = None if env.get("type") == "msg" or s.get("init_ek") else s.get("pending")
    return pt, s


def decrypt(me: DeviceKeys, session: dict | None, env: dict) -> tuple[bytes, dict]:
    """Déchiffre une enveloppe v2. Renvoie (clair, nouvelle session). `me` peut être modifié (prékey consommée)."""
    if env.get("v") != 2:
        raise CryptoError("version d'enveloppe non prise en charge")
    if env.get("type") == "prekey":
        x = env["x"]
        if session is not None and session.get("init_ek") == x["ek"]:
            return _ratchet_decrypt(session, env)  # répétition du message initial : session déjà établie
        their_ik = b64d(x["ik"])
        ek = b64d(x["ek"])
        spk_sk = me.spk_sk(int(x["spk"]))
        ik_sk = ed_to_x_sk(me.identity_sk64)
        parts = [dh(spk_sk, ed_to_x_pk(their_ik)), dh(ik_sk, ek), dh(spk_sk, ek)]
        opk_sk = None
        if x.get("opk") is not None:
            opk_sk = me.d["opks"].get(str(int(x["opk"])))
            if opk_sk is None:
                raise CryptoError("prékey à usage unique inconnue ou déjà utilisée")
            parts.append(dh(b64d(opk_sk), ek))
        sk = _x3dh_sk(parts)
        fresh = {
            "rk": b64e(sk), "dhs_sk": b64e(spk_sk), "dhs_pk": b64e(nb.crypto_scalarmult_base(spk_sk)),
            "dhr": None, "cks": None, "ckr": None, "ns": 0, "nr": 0, "pn": 0, "skipped": {},
            "ad": b64e(their_ik + me.identity_pk), "peer_ik": b64e(their_ik), "pending": None, "init_ek": x["ek"],
        }
        pt, s = _ratchet_decrypt(fresh, env)
        if x.get("opk") is not None:
            me.take_opk(int(x["opk"]))  # consommée seulement après succès
        return pt, s
    if session is None:
        raise CryptoError("aucune session pour cet appareil")
    return _ratchet_decrypt(session, env)


def random_bytes(n: int) -> bytes:
    return secrets.token_bytes(n)
