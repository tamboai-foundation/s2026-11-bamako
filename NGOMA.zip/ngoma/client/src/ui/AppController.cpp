#include "AppController.h"

#include <QBuffer>
#include <QDateTime>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QImage>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMimeDatabase>
#include <QRegularExpression>
#include <QSysInfo>
#include <QUrlQuery>
#include <cstring>

#include "ConversationListModel.h"
#include "MessageListModel.h"
#include "VideoItem.h"
#include "core/ApiClient.h"
#include "core/Crypto.h"
#include "core/RealtimeClient.h"
#include "core/StoreClient.h"
#include "core/SyncEngine.h"
#include "core/Uuid7.h"
#include "ipc/IpcBus.h"

namespace ngoma {

namespace {
constexpr int kPage = 50;
constexpr qint64 kMaxAttachment = 25LL * 1024 * 1024;
QString str(const QJsonObject& o, const char* k) { return o.value(QLatin1String(k)).toString(); }
QString b64(const QByteArray& b) { return QString::fromLatin1(b.toBase64()); }
QByteArray unb64(const QJsonValue& v) { return QByteArray::fromBase64(v.toString().toLatin1()); }

template <size_t N>
void copyStr(char (&dst)[N], const QString& src) {
    const QByteArray b = src.toUtf8().left(int(N) - 1);
    std::memcpy(dst, b.constData(), size_t(b.size()));
    dst[b.size()] = '\0';
}

QString safeFileName(const QString& name) {
    QString n = QFileInfo(name).fileName();
    n.replace(QRegularExpression(QStringLiteral("[^\\w.\\- ]")), QStringLiteral("_"));
    return n.isEmpty() ? QStringLiteral("fichier") : n.left(120);
}
}  // namespace

AppController::AppController(Config cfg, QObject* parent) : QObject(parent), m_cfg(std::move(cfg)) {
    m_secrets = std::make_unique<SecretStore>(m_cfg.dataDir);
    m_api = std::make_unique<ApiClient>(m_cfg);
    m_rt = std::make_unique<RealtimeClient>(m_cfg, m_api->sslConfiguration());
    m_store = std::make_unique<StoreClient>(m_cfg.storeSocket);
    m_sync = std::make_unique<SyncEngine>(*m_api, *m_rt, *m_store, *m_secrets);
    m_ipc = std::make_unique<IpcBus>();
    m_convModel = std::make_unique<ConversationListModel>();
    m_msgModel = std::make_unique<MessageListModel>();

    m_reloadConv.setSingleShot(true);
    m_reloadConv.setInterval(60);
    m_reloadMsg.setSingleShot(true);
    m_reloadMsg.setInterval(30);
    connect(&m_reloadConv, &QTimer::timeout, this, &AppController::reloadConversations);
    connect(&m_reloadMsg, &QTimer::timeout, this, &AppController::reloadMessages);
    m_typingClear.setSingleShot(true);
    m_typingClear.setInterval(4000);
    connect(&m_typingClear, &QTimer::timeout, this, [this] {
        m_typing.clear();
        emit typingTextChanged();
    });

    connect(m_store.get(), &StoreClient::readyChanged, this, [this](bool ready) {
        emit storeReadyChanged();
        if (ready && m_state == QLatin1String("ready")) m_reloadConv.start();
    });
    connect(m_store.get(), &StoreClient::changed, this, [this](const QString& scope, const QString& mid) {
        m_reloadConv.start();
        if (!m_current.isEmpty() && (mid.isEmpty() || mid == m_current) && scope == QLatin1String("msg")) m_reloadMsg.start();
    });
    connect(m_sync.get(), &SyncEngine::onlineChanged, this, [this](bool on) {
        m_online = on;
        emit onlineChanged();
        if (on) refreshAssistant();
    });
    connect(m_sync.get(), &SyncEngine::syncingChanged, this, [this](bool s) {
        m_syncing = s;
        emit syncingChanged();
    });
    connect(m_sync.get(), &SyncEngine::errorOccurred, this, &AppController::errorOccurred);
    connect(m_sync.get(), &SyncEngine::keyChanged, this, [this](const QString&, qint64) {
        emit errorOccurred(tr("L'identité d'un appareil de contact a changé. Vérifiez son numéro de sécurité."));
    });
    connect(m_sync.get(), &SyncEngine::incoming, this, [this](const QString& mid, int) {
        if (mid == m_current) m_reloadMsg.start();
        m_ipc->publishMessageEvent(mid, m_convModel->unreadTotal() + 1);
    });
    connect(m_sync.get(), &SyncEngine::typing, this, [this](const QString& mid, qint64 uid) {
        if (mid != m_current) return;
        QString name;
        for (const auto& m : m_convModel->byId(mid).value(QStringLiteral("members")).toArray())
            if (m.toObject().value(QStringLiteral("id")).toInteger() == uid) {
                name = str(m.toObject(), "display_name");
                if (name.isEmpty()) name = str(m.toObject(), "username");
            }
        m_typing = tr("%1 écrit…").arg(name);
        emit typingTextChanged();
        m_typingClear.start();
    });
    connect(m_sync.get(), &SyncEngine::callSignal, this, &AppController::onCallSignal);
    connect(m_api.get(), &ApiClient::unauthorized, this, [this] {
        emit errorOccurred(tr("Cet appareil a été révoqué. Réenrôlez-le."));
        logout(false);
    });
    connect(m_rt.get(), &RealtimeClient::revoked, this, [this] {
        emit errorOccurred(tr("Session refusée par le serveur."));
        logout(false);
    });

    connect(m_ipc.get(), &IpcBus::localFrame, this, [](const QImage& f) { VideoItem::dispatch(VideoItem::Local, f); });
    connect(m_ipc.get(), &IpcBus::remoteFrame, this, [](const QImage& f) { VideoItem::dispatch(VideoItem::Remote, f); });
    connect(m_ipc.get(), &IpcBus::audioLevel, this, [this](float mic, float) {
        m_micLevel = mic;
        emit micLevelChanged();
    });
    connect(m_ipc.get(), &IpcBus::mediaState, this, [this](int st, quint64 seq, quint32) {
        if (seq == m_callSeq && st == 3) emit errorOccurred(tr("Erreur du moteur média (relais, caméra ou micro)."));
    });
}

AppController::~AppController() = default;

bool AppController::storeReady() const { return m_store->isReady(); }
QObject* AppController::conversations() const { return m_convModel.get(); }
QObject* AppController::messages() const { return m_msgModel.get(); }
bool AppController::mediaAvailable() const { return m_ipc->available(); }
QString AppController::mySafetyNumber() const {
    const QByteArray pk = m_id.publicKey();
    return pk.isEmpty() ? QString() : Crypto::fingerprint(pk);
}
QString AppController::currentTitle() const { return m_convModel->titleOf(m_current); }

void AppController::setState(const QString& s) {
    if (s == m_state) return;
    m_state = s;
    emit stateChanged();
}

void AppController::setBusy(bool b) {
    if (b == m_busy) return;
    m_busy = b;
    emit busyChanged();
}

void AppController::boot() {
    if (!Crypto::init()) {
        emit errorOccurred(tr("Initialisation cryptographique impossible."));
        return;
    }
    m_store->connectToDaemon();
    if (m_secrets->load(m_id))
        startSession();
    else
        setState(QStringLiteral("enroll"));
}

void AppController::startSession() {
    m_api->setToken(m_id.token);
    m_convModel->setMyUserId(m_id.userId);
    m_sync->start(m_id);
    emit identityChanged();
    setState(QStringLiteral("ready"));
    reloadConversations();
}

// ------------------------------------------------------------------ enrôlement

void AppController::finishEnrollment(const QJsonObject& body, const ratchet::DeviceKeys& keys) {
    const auto user = body.value(QStringLiteral("user")).toObject();
    Identity id;
    id.userId = user.value(QStringLiteral("id")).toInteger();
    id.username = str(user, "username");
    id.displayName = str(user, "display_name");
    id.deviceId = str(body, "device_id");
    id.token = str(body, "token");
    id.keys = keys;
    if (!m_secrets->save(id)) {
        emit errorOccurred(tr("Impossible d'enregistrer l'identité de l'appareil sur le disque."));
        return;
    }
    m_id = id;
    startSession();  // publie immédiatement les prékeys (SyncEngine::ensurePrekeys)
}

void AppController::enroll(const QString& username, const QString& password) {
    const auto keys = ratchet::DeviceKeys::generate();
    setBusy(true);
    const QJsonObject req{{QStringLiteral("username"), username.trimmed()}, {QStringLiteral("password"), password},
                          {QStringLiteral("device_name"), m_cfg.deviceName + QStringLiteral(" · ") + QSysInfo::machineHostName()},
                          {QStringLiteral("public_key"), b64(keys.identityPublic())}};
    m_api->post(QStringLiteral("auth/enroll"), QJsonDocument(req), [this, keys](const ApiReply& r) {
        setBusy(false);
        if (r.ok())
            finishEnrollment(r.body.object(), keys);
        else
            emit errorOccurred(r.networkError() ? tr("Serveur injoignable : %1").arg(r.error) : tr("Identifiants refusés."));
    });
}

void AppController::signup(const QString& username, const QString& password, const QString& displayName,
                           const QString& provisioningCode) {
    const auto keys = ratchet::DeviceKeys::generate();
    setBusy(true);
    const QJsonObject req{{QStringLiteral("username"), username.trimmed()},
                          {QStringLiteral("password"), password},
                          {QStringLiteral("display_name"), displayName.trimmed()},
                          {QStringLiteral("provisioning_code"), provisioningCode.trimmed()},
                          {QStringLiteral("device_name"), m_cfg.deviceName},
                          {QStringLiteral("public_key"), b64(keys.identityPublic())}};
    m_api->post(QStringLiteral("auth/signup"), QJsonDocument(req), [this, keys](const ApiReply& r) {
        setBusy(false);
        if (r.ok()) {
            finishEnrollment(r.body.object(), keys);
            return;
        }
        QString detail = str(r.body.object(), "detail");
        if (detail.isEmpty() && r.body.isObject()) {
            const auto o = r.body.object();
            for (auto it = o.begin(); it != o.end(); ++it)
                detail += it.key() + QStringLiteral(" : ") + it.value().toArray().first().toString() + QLatin1Char('\n');
        }
        emit errorOccurred(r.networkError() ? tr("Serveur injoignable : %1").arg(r.error) : detail.trimmed());
    });
}

void AppController::logout(bool wipeLocalData) {
    hangup();
    m_sync->stop();
    m_secrets->clear();
    if (wipeLocalData) {
        m_store->call(QStringLiteral("wipe"), {});
        QDir(QDir(m_cfg.dataDir).filePath(QStringLiteral("files"))).removeRecursively();
    }
    m_id = {};
    m_api->setToken({});
    m_current.clear();
    m_assistant.clear();
    m_msgModel->clear();
    m_convModel->replace({});
    emit assistantChanged();
    emit currentConversationChanged();
    emit identityChanged();
    setState(QStringLiteral("enroll"));
}

// ------------------------------------------------------------------ conversations & messages

void AppController::reloadConversations() {
    if (m_state != QLatin1String("ready")) return;
    m_store->call(QStringLiteral("conv.list"), {}, [this](bool ok, const QJsonValue& v, const QString&) {
        if (!ok) return;
        m_convModel->replace(v.toArray());
        if (!m_current.isEmpty())
            m_msgModel->setPeerReadSeq(m_convModel->byId(m_current).value(QStringLiteral("peer_read_seq")).toInteger());
        emit currentConversationChanged();
    });
}

void AppController::openConversation(const QString& id) {
    if (id == m_current) return;
    m_current = id;
    m_typing.clear();
    emit typingTextChanged();
    const auto conv = m_convModel->byId(id);
    QHash<qint64, QString> names;
    for (const auto& m : conv.value(QStringLiteral("members")).toArray()) {
        const auto o = m.toObject();
        const QString dn = str(o, "display_name");
        names.insert(o.value(QStringLiteral("id")).toInteger(), dn.isEmpty() ? str(o, "username") : dn);
    }
    m_msgModel->clear();
    m_msgModel->setContext(m_id.userId, names);
    m_msgModel->setPeerReadSeq(conv.value(QStringLiteral("peer_read_seq")).toInteger());
    emit currentConversationChanged();
    reloadMessages();
}

void AppController::closeConversation() {
    m_current.clear();
    m_msgModel->clear();
    emit currentConversationChanged();
}

void AppController::reloadMessages() {
    if (m_current.isEmpty()) return;
    const QString mid = m_current;
    m_store->call(QStringLiteral("msg.list"),
                  {{QStringLiteral("messaging_id"), mid}, {QStringLiteral("before_seq"), 0}, {QStringLiteral("limit"), kPage}},
                  [this, mid](bool ok, const QJsonValue& v, const QString&) {
                      if (!ok || mid != m_current) return;
                      m_msgModel->mergeLatest(v.toArray());
                      m_sync->markRead(mid, m_msgModel->newestSeq());
                  });
}

void AppController::loadOlder() {
    const qint64 before = m_msgModel->oldestSeq();
    if (m_current.isEmpty() || before <= 1) return;
    const QString mid = m_current;
    m_store->call(QStringLiteral("msg.list"),
                  {{QStringLiteral("messaging_id"), mid}, {QStringLiteral("before_seq"), before}, {QStringLiteral("limit"), kPage}},
                  [this, mid](bool ok, const QJsonValue& v, const QString&) {
                      if (ok && mid == m_current) m_msgModel->prependOlder(v.toArray());
                  });
}

void AppController::send(const QString& text, int ephemeralSeconds) {
    if (m_current.isEmpty()) return;
    m_sync->sendText(m_current, text, ephemeralSeconds);
    saveDraft(QString());
}

// ------------------------------------------------------------------ pièces jointes (V1.1)

void AppController::sendFile(const QUrl& fileUrl, const QString& caption) {
    if (m_current.isEmpty()) return;
    const QString path = fileUrl.isLocalFile() ? fileUrl.toLocalFile() : fileUrl.toString();
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly)) {
        emit errorOccurred(tr("Fichier illisible."));
        return;
    }
    if (f.size() > kMaxAttachment) {
        emit errorOccurred(tr("Fichier trop volumineux (25 Mo maximum)."));
        return;
    }
    const QByteArray plain = f.readAll();
    const QString mime = QMimeDatabase().mimeTypeForFileNameAndData(path, plain.left(4096)).name();
    QJsonObject meta{{QStringLiteral("name"), safeFileName(path)}, {QStringLiteral("mime"), mime},
                     {QStringLiteral("size"), plain.size()}, {QStringLiteral("sha256"), b64(Crypto::sha256(plain))}};
    if (mime.startsWith(QLatin1String("image/"))) {
        const QImage img = QImage::fromData(plain);
        if (!img.isNull()) {
            QByteArray jpg;
            QBuffer buf(&jpg);
            buf.open(QIODevice::WriteOnly);
            img.scaled(240, 240, Qt::KeepAspectRatio, Qt::SmoothTransformation).save(&buf, "JPEG", 60);
            if (jpg.size() <= 16 * 1024) meta.insert(QStringLiteral("thumb"), b64(jpg));  // aperçu chiffré dans l'enveloppe
            meta.insert(QStringLiteral("w"), img.width());
            meta.insert(QStringLiteral("h"), img.height());
        }
    }
    QByteArray key, nonce;
    const QByteArray blob = Crypto::sealBlob(plain, key, nonce);
    meta.insert(QStringLiteral("k"), b64(key));
    meta.insert(QStringLiteral("n"), b64(nonce));
    Crypto::wipe(key);
    const QString mid = m_current;
    setBusy(true);
    m_api->postFile(QStringLiteral("media"), {{QStringLiteral("messaging_id"), mid}}, blob,
                    [this, mid, meta, caption, path](const ApiReply& r) mutable {
                        setBusy(false);
                        if (!r.ok()) {
                            emit errorOccurred(r.status == 413 ? tr("Fichier refusé : trop volumineux.")
                                                               : tr("Envoi du fichier impossible (%1).").arg(r.status));
                            return;
                        }
                        meta.insert(QStringLiteral("id"), str(r.body.object(), "media_id"));
                        meta.insert(QStringLiteral("path"), path);  // chemin local : jamais envoyé (retiré par SyncEngine)
                        m_sync->sendMedia(mid, caption, meta);
                    });
}

void AppController::downloadAttachment(const QString& clientId) {
    const QJsonObject meta = m_msgModel->metaOf(clientId);
    const QString mediaId = str(meta, "id");
    if (mediaId.isEmpty()) return;
    setBusy(true);
    m_api->getBytes(QStringLiteral("media/") + mediaId, [this, meta, mediaId, clientId](int status, const QByteArray& blob) {
        setBusy(false);
        if (status != 200) {
            emit errorOccurred(tr("Téléchargement impossible (%1).").arg(status));
            return;
        }
        QByteArray key = unb64(meta.value(QStringLiteral("k")));
        const auto plain = Crypto::openBlob(blob, key, unb64(meta.value(QStringLiteral("n"))));
        Crypto::wipe(key);
        if (!plain || Crypto::sha256(*plain) != unb64(meta.value(QStringLiteral("sha256")))) {
            emit errorOccurred(tr("Pièce jointe altérée : intégrité non vérifiée."));
            return;
        }
        const QString dir = QDir(m_cfg.dataDir).filePath(QStringLiteral("files/") + mediaId);
        QDir().mkpath(dir);
        const QString out = QDir(dir).filePath(safeFileName(str(meta, "name")));
        QFile f(out);
        if (!f.open(QIODevice::WriteOnly) || f.write(*plain) != plain->size()) {
            emit errorOccurred(tr("Écriture du fichier impossible."));
            return;
        }
        f.setPermissions(QFileDevice::ReadOwner | QFileDevice::WriteOwner);
        QJsonObject updated = meta;
        updated.insert(QStringLiteral("path"), out);
        m_store->call(QStringLiteral("msg.setMeta"),
                      {{QStringLiteral("client_id"), clientId}, {QStringLiteral("messaging_id"), m_current},
                       {QStringLiteral("meta"), QString::fromUtf8(QJsonDocument(updated).toJson(QJsonDocument::Compact))}});
    });
}

void AppController::notifyTyping() {
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    if (m_current.isEmpty() || now - m_lastTypingSent < 2500) return;
    m_lastTypingSent = now;
    m_rt->send({{QStringLiteral("type"), QStringLiteral("typing")}, {QStringLiteral("messaging_id"), m_current}});
}

void AppController::saveDraft(const QString& text) {
    if (m_current.isEmpty()) return;
    m_store->call(QStringLiteral("conv.setDraft"), {{QStringLiteral("id"), m_current}, {QStringLiteral("text"), text}});
}

QString AppController::draftFor(const QString& id) const { return str(m_convModel->byId(id), "draft"); }

void AppController::retryFailed() { m_sync->retryFailed(); }

void AppController::searchUsers(const QString& query) {
    QUrlQuery q;
    q.addQueryItem(QStringLiteral("q"), query.trimmed());
    m_api->get(QStringLiteral("users/search?") + q.toString(QUrl::FullyEncoded), [this](const ApiReply& r) {
        QVariantList out;
        if (r.ok())
            for (const auto& u : r.body.array()) out.append(u.toObject().toVariantMap());
        emit usersFound(out);
    });
}

void AppController::upsertAndOpen(const QJsonObject& conversation) {
    const QString id = str(conversation, "id");
    m_store->call(QStringLiteral("conv.upsert"), {{QStringLiteral("items"), QJsonArray{conversation}}},
                  [this, id](bool, const QJsonValue&, const QString&) {
                      m_store->call(QStringLiteral("conv.list"), {}, [this, id](bool ok, const QJsonValue& v, const QString&) {
                          if (ok) m_convModel->replace(v.toArray());
                          emit conversationCreated(id);
                      });
                  });
}

void AppController::createDirect(qint64 userId) {
    setBusy(true);
    m_api->post(QStringLiteral("conversations"),
                QJsonDocument(QJsonObject{{QStringLiteral("kind"), QStringLiteral("direct")},
                                          {QStringLiteral("member_ids"), QJsonArray{userId}}}),
                [this](const ApiReply& r) {
                    setBusy(false);
                    if (r.ok())
                        upsertAndOpen(r.body.object());
                    else
                        emit errorOccurred(tr("Création de la conversation impossible."));
                });
}

void AppController::createGroup(const QString& title, const QVariantList& userIds) {
    QJsonArray ids;
    for (const auto& v : userIds) ids.append(v.toLongLong());
    setBusy(true);
    m_api->post(QStringLiteral("conversations"),
                QJsonDocument(QJsonObject{{QStringLiteral("kind"), QStringLiteral("group")},
                                          {QStringLiteral("title"), title.trimmed()},
                                          {QStringLiteral("member_ids"), ids}}),
                [this](const ApiReply& r) {
                    setBusy(false);
                    if (r.ok())
                        upsertAndOpen(r.body.object());
                    else
                        emit errorOccurred(tr("Création du groupe impossible."));
                });
}

// ------------------------------------------------------------------ assistant IA (bot côté serveur)

void AppController::refreshAssistant() {
    m_api->get(QStringLiteral("bots/me"), [this](const ApiReply& r) {
        if (!r.ok()) return;
        m_assistant = r.body.object().toVariantMap();
        emit assistantChanged();
    });
}

void AppController::configureAssistant(const QString& provider, const QString& model, const QString& apiKey,
                                       const QString& baseUrl, const QString& systemPrompt) {
    QJsonObject req{{QStringLiteral("provider"), provider}, {QStringLiteral("model"), model.trimmed()},
                    {QStringLiteral("base_url"), baseUrl.trimmed()}, {QStringLiteral("system_prompt"), systemPrompt}};
    if (!apiKey.trimmed().isEmpty()) req.insert(QStringLiteral("api_key"), apiKey.trimmed());
    setBusy(true);
    m_api->post(QStringLiteral("bots/me"), QJsonDocument(req), [this](const ApiReply& r) {
        setBusy(false);
        if (!r.ok()) {
            const QString d = str(r.body.object(), "detail");
            emit errorOccurred(d.isEmpty() ? tr("Activation de l'assistant impossible (%1).").arg(r.status) : d);
            return;
        }
        m_assistant = r.body.object().toVariantMap();
        emit assistantChanged();
        emit notice(tr("Assistant IA activé."));
        m_sync->refreshConversations();
    });
}

void AppController::disableAssistant() {
    setBusy(true);
    m_api->del(QStringLiteral("bots/me"), [this](const ApiReply& r) {
        setBusy(false);
        if (!r.ok()) {
            emit errorOccurred(tr("Désactivation impossible (%1).").arg(r.status));
            return;
        }
        m_assistant = r.body.object().toVariantMap();
        emit assistantChanged();
        emit notice(tr("Assistant IA désactivé : ses clés et son historique ont été effacés du serveur."));
    });
}

// ------------------------------------------------------------------ appels (V1.1)
// Signalisation : call.signal relayé par le serveur. Clé média : aléatoire par appel, transmise chiffrée
// (NGOMA Ratchet v2) à chaque appareil du correspondant. Média : ngoma-media ↔ relais UDP.

void AppController::setCall(const QString& state, const QString& peerName) {
    m_callState = state;
    if (!peerName.isNull()) m_callPeerName = peerName;
    if (state == QLatin1String("idle")) {
        m_callId.clear();
        m_callMessagingId.clear();
        m_callPeerId = 0;
        m_callPeerName.clear();
        Crypto::wipe(m_callKey);
        m_muted = false;
        emit mutedChanged();
    }
    m_ipc->setVideoReceiving(state == QLatin1String("active") || state == QLatin1String("outgoing"));
    emit callStateChanged();
}

void AppController::sendCallSignal(const QString& kind, const QJsonObject& extra) {
    if (m_callPeerId == 0) return;
    QJsonObject payload{{QStringLiteral("kind"), kind}, {QStringLiteral("call_id"), m_callId}};
    for (auto it = extra.begin(); it != extra.end(); ++it) payload.insert(it.key(), it.value());
    m_rt->send({{QStringLiteral("type"), QStringLiteral("call.signal")},
                {QStringLiteral("messaging_id"), m_callMessagingId},
                {QStringLiteral("to_user_id"), m_callPeerId},
                {QStringLiteral("payload"), payload}});
}

void AppController::mediaCommand(int command) {
    ipc::CallControl c;
    c.command = static_cast<ipc::CallCommand>(command);
    c.call_seq = m_callSeq;
    copyStr(c.call_id, m_callId);
    m_ipc->sendCallControl(c);
}

void AppController::startMedia() {
    const quint64 seq = m_callSeq;
    const QString callId = m_callId;
    m_api->post(QStringLiteral("calls/token"),
                QJsonDocument(QJsonObject{{QStringLiteral("messaging_id"), m_callMessagingId}, {QStringLiteral("call_id"), m_callId}}),
                [this, seq, callId](const ApiReply& r) {
                    if (seq != m_callSeq || callId != m_callId) return;  // appel terminé entre-temps
                    if (!r.ok() || m_callKey.size() != 32) {
                        emit errorOccurred(tr("Accès au relais média refusé."));
                        return;
                    }
                    const auto t = r.body.object();
                    ipc::CallControl c;
                    c.command = ipc::CallCommand::Start;
                    c.call_seq = m_callSeq;
                    copyStr(c.call_id, m_callId);
                    copyStr(c.relay_host, str(t, "relay_host"));
                    c.relay_port = std::uint32_t(t.value(QStringLiteral("relay_port")).toInt());
                    copyStr(c.token, str(t, "token"));
                    c.user_id = std::uint64_t(t.value(QStringLiteral("user_id")).toInteger());
                    c.exp = std::uint64_t(t.value(QStringLiteral("exp")).toInteger());
                    copyStr(c.device_id, str(t, "device_id"));
                    std::memcpy(c.call_key, m_callKey.constData(), 32);
                    m_ipc->sendCallControl(c);
                    std::memset(c.call_key, 0, sizeof c.call_key);
                });
}

void AppController::startCall() {
    if (m_callState != QLatin1String("idle") || m_current.isEmpty() || !m_online) return;
    const auto conv = m_convModel->byId(m_current);
    if (str(conv, "kind") != QLatin1String("direct")) {
        emit notice(tr("Les appels de groupe arrivent dans une prochaine version."));
        return;
    }
    for (const auto& m : conv.value(QStringLiteral("members")).toArray()) {
        const qint64 uid = m.toObject().value(QStringLiteral("id")).toInteger();
        if (uid != m_id.userId) m_callPeerId = uid;
    }
    m_callId = uuid7();
    m_callMessagingId = m_current;
    m_callKey = Crypto::random(32);
    ++m_callSeq;
    setCall(QStringLiteral("outgoing"), m_convModel->titleOf(m_current));
    const QByteArray secret = QJsonDocument(QJsonObject{{QStringLiteral("t"), QStringLiteral("callkey")},
                                                        {QStringLiteral("call_id"), m_callId},
                                                        {QStringLiteral("k"), b64(m_callKey)}})
                                  .toJson(QJsonDocument::Compact);
    const QString callId = m_callId;
    m_sync->encryptForUser(m_callMessagingId, m_callPeerId, secret, [this, callId](bool ok, const QJsonObject& keys) {
        if (callId != m_callId) return;
        if (!ok || keys.isEmpty()) {
            emit errorOccurred(tr("Le correspondant n'est pas joignable pour un appel chiffré."));
            setCall(QStringLiteral("idle"));
            return;
        }
        sendCallSignal(QStringLiteral("invite"), {{QStringLiteral("keys"), keys}});
        startMedia();  // aperçu local + inscription au relais en attendant la réponse
    });
}

void AppController::acceptCall() {
    if (m_callState != QLatin1String("incoming") || m_callKey.size() != 32) return;
    ++m_callSeq;
    sendCallSignal(QStringLiteral("accept"));
    setCall(QStringLiteral("active"));
    startMedia();
}

void AppController::hangup() {
    if (m_callState == QLatin1String("idle")) return;
    sendCallSignal(m_callState == QLatin1String("incoming") ? QStringLiteral("reject") : QStringLiteral("hangup"));
    mediaCommand(int(ipc::CallCommand::Stop));
    setCall(QStringLiteral("idle"));
}

void AppController::toggleMute() {
    if (m_callState == QLatin1String("idle")) return;
    m_muted = !m_muted;
    mediaCommand(int(m_muted ? ipc::CallCommand::Mute : ipc::CallCommand::Unmute));
    emit mutedChanged();
}

void AppController::onCallSignal(const QJsonObject& evt) {
    const auto p = evt.value(QStringLiteral("payload")).toObject();
    const QString kind = str(p, "kind");
    const QString callId = str(p, "call_id");
    const qint64 from = evt.value(QStringLiteral("from_user_id")).toInteger();
    const QString fromDevice = str(evt, "from_device_id");
    const QString mid = str(evt, "messaging_id");
    if (kind == QLatin1String("invite")) {
        if (m_callState != QLatin1String("idle")) {
            m_rt->send({{QStringLiteral("type"), QStringLiteral("call.signal")}, {QStringLiteral("messaging_id"), mid},
                        {QStringLiteral("to_user_id"), from},
                        {QStringLiteral("payload"), QJsonObject{{QStringLiteral("kind"), QStringLiteral("busy")},
                                                                {QStringLiteral("call_id"), callId}}}});
            return;
        }
        const auto env = p.value(QStringLiteral("keys")).toObject().value(m_id.deviceId).toObject();
        const auto plain = env.isEmpty() ? std::nullopt : m_sync->decryptFromDevice(fromDevice, env);
        const auto o = plain ? QJsonDocument::fromJson(*plain).object() : QJsonObject{};
        if (str(o, "t") != QLatin1String("callkey") || str(o, "call_id") != callId) {
            qWarning() << "invitation d'appel sans clé valide pour cet appareil";
            return;
        }
        m_callKey = unb64(o.value(QStringLiteral("k")));
        m_callId = callId;
        m_callMessagingId = mid;
        m_callPeerId = from;
        setCall(QStringLiteral("incoming"), m_convModel->titleOf(mid));
        return;
    }
    if (callId != m_callId) return;
    if (kind == QLatin1String("accept") && m_callState == QLatin1String("outgoing")) {
        setCall(QStringLiteral("active"));
    } else if (kind == QLatin1String("hangup") || kind == QLatin1String("reject") || kind == QLatin1String("busy")) {
        if (kind == QLatin1String("busy")) emit notice(tr("Correspondant déjà en ligne."));
        mediaCommand(int(ipc::CallCommand::Stop));
        setCall(QStringLiteral("idle"));
    }
}

}  // namespace ngoma
