#!/usr/bin/env bash
# Démonstration NGOMA sur une machine : serveur, Redis, worker des assistants, faux LLM, stockage local, données
# de démonstration chiffrées. Tous les secrets sont générés à chaque lancement et ne quittent pas le dossier de travail.
# Usage : tools/run_demo.sh <dossier_de_travail>   → puis lancer ngoma-terminal avec les variables affichées.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
W="${1:?dossier de travail}"; mkdir -p "$W/alice"
PORT="${PORT:-8767}" LLM_PORT="${LLM_PORT:-8768}" REDIS_PORT="${REDIS_PORT:-6391}"
rnd() { python3 -c "import secrets;print(secrets.token_urlsafe($1))"; }

export NGOMA_SECRET_KEY="$(rnd 48)" NGOMA_DEBUG=0 NGOMA_ALLOWED_HOSTS=127.0.0.1,localhost
export NGOMA_PROVISIONING_CODE="$(rnd 12)" NGOMA_RELAY_SECRET="$(rnd 32)" NGOMA_FAKE_LLM_KEY="$(rnd 24)"
export NGOMA_BOT_KEY="$(python3 -c 'from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())')"
export NGOMA_THROTTLE_ANON=1000/min NGOMA_MEDIA_ROOT="$W/media" NGOMA_BOT_ALLOW_PRIVATE_BASE_URL=1 NGOMA_BOT_POLL_SECONDS=0.3
export DATABASE_URL="sqlite:///$W/db.sqlite3" REDIS_URL="redis://127.0.0.1:$REDIS_PORT/0"

redis-server --port "$REDIS_PORT" --save "" >"$W/redis.log" 2>&1 &
python3 "$ROOT/tools/fake_llm.py" "$LLM_PORT" >"$W/llm.log" 2>&1 &
python3 "$ROOT/tools/fake_store.py" "$W/store.sock" >"$W/store.log" 2>&1 &
( cd "$ROOT/server" && python3 manage.py migrate -v0 && exec daphne -b 127.0.0.1 -p "$PORT" ngoma_server.asgi:application ) >"$W/server.log" 2>&1 &
for _ in $(seq 50); do curl -fs "http://127.0.0.1:$PORT/healthz" >/dev/null && break; sleep 0.2; done
( cd "$ROOT/server" && exec python3 manage.py run_bots ) >"$W/bots.log" 2>&1 &
python3 "$ROOT/tools/demo_seed.py" "http://127.0.0.1:$PORT" "$NGOMA_PROVISIONING_CODE" "$W/alice" "http://127.0.0.1:$LLM_PORT"
cat <<EOF
Démo prête. Terminal d'Alice :
  NGOMA_CONFIG=/dev/null NGOMA_SERVER_URL=http://127.0.0.1:$PORT NGOMA_DATA_DIR=$W/alice \\
  NGOMA_STORE_SOCK=$W/store.sock ngoma-terminal
EOF
wait
