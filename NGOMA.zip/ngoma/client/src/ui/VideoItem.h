#pragma once

#include <QImage>
#include <QQuickPaintedItem>

namespace ngoma {

/// Affiche les trames reçues par iceoryx2 (capture locale ou flux distant décodé).
/// Utilisation QML : `VideoItem { source: VideoItem.Local }` ; le contrôleur pousse les trames.
class VideoItem : public QQuickPaintedItem {
    Q_OBJECT
    QML_ELEMENT
    Q_PROPERTY(Source source READ source WRITE setSource NOTIFY sourceChanged)
    Q_PROPERTY(bool hasFrame READ hasFrame NOTIFY hasFrameChanged)
public:
    enum Source { Local, Remote };
    Q_ENUM(Source)

    explicit VideoItem(QQuickItem* parent = nullptr);
    ~VideoItem() override;
    void paint(QPainter* painter) override;

    Source source() const { return m_source; }
    void setSource(Source s);
    bool hasFrame() const { return !m_frame.isNull(); }

    void pushFrame(const QImage& frame);

    static void registerItem(VideoItem* item);
    static void unregisterItem(VideoItem* item);
    static void dispatch(Source source, const QImage& frame);

signals:
    void sourceChanged();
    void hasFrameChanged();

private:
    QImage m_frame;
    Source m_source = Remote;
};

}  // namespace ngoma
