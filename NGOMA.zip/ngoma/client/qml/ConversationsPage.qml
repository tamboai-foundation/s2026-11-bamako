import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Ngoma.Core

Page {
    id: page
    background: Rectangle { color: Theme.background }

    header: PageHeader {
        title: qsTr("Conversations")
        subtitle: App.conversations.unreadTotal > 0 ? qsTr("%n non lu(s)", "", App.conversations.unreadTotal) : ""
        IconButton { iconName: "plus"; variant: "filled"; tip: qsTr("Nouvelle conversation"); onClicked: page.StackView.view.push(newConv) }
        IconButton { iconName: "settings"; variant: "filled"; tip: qsTr("Réglages"); onClicked: page.StackView.view.push(settings) }
    }

    Component { id: newConv; NewConversationPage {} }
    Component { id: settings; SettingsPage {} }
    Component { id: chat; ChatPage {} }

    function open(id) {
        App.openConversation(id)
        page.StackView.view.push(chat)
    }
    Connections {
        target: App
        function onConversationCreated(id) {
            page.StackView.view.pop(page)
            page.open(id)
        }
    }

    ListView {
        id: list
        anchors.fill: parent
        model: App.conversations
        clip: true
        reuseItems: true
        cacheBuffer: 800
        boundsBehavior: Flickable.StopAtBounds
        ScrollIndicator.vertical: ScrollIndicator {}

        delegate: ItemDelegate {
            id: row
            width: ListView.view.width
            height: 80
            hoverEnabled: true
            onClicked: page.open(conversationId)
            background: Rectangle {
                color: row.down ? Theme.surfacePressed : (row.hovered ? Theme.surface : "transparent")
                Rectangle { anchors.bottom: parent.bottom; anchors.left: parent.left; anchors.leftMargin: 84; anchors.right: parent.right; height: 1; color: Theme.outline }
            }
            contentItem: RowLayout {
                spacing: 16
                Avatar { name: title; kind: isAssistant ? "assistant" : model.kind; size: 50 }
                ColumnLayout {
                    Layout.fillWidth: true; spacing: 4
                    RowLayout {
                        spacing: 8
                        Text { text: title; color: Theme.text; font.pixelSize: Theme.fontBody; font.weight: unread > 0 ? Font.Bold : Font.Medium; elide: Text.ElideRight; Layout.fillWidth: true }
                        Text { text: lastAt; color: unread > 0 ? Theme.accent : Theme.textMuted; font.pixelSize: Theme.fontSmall }
                    }
                    RowLayout {
                        spacing: 8
                        Text {
                            Layout.fillWidth: true; elide: Text.ElideRight; font.pixelSize: Theme.fontSmall + 1
                            text: draft.length ? qsTr("Brouillon : %1").arg(draft)
                                 : (lastBody.length ? lastBody : (model.kind === "group" ? qsTr("Groupe · %1 membres").arg(memberCount) : qsTr("Nouvelle conversation")))
                            color: draft.length ? Theme.warning : (unread > 0 ? Theme.text : Theme.textMuted)
                        }
                        Rectangle {
                            visible: unread > 0; radius: 11; color: Theme.accent
                            Layout.preferredHeight: 22; Layout.preferredWidth: Math.max(22, badge.implicitWidth + 12)
                            Text { id: badge; anchors.centerIn: parent; text: unread > 99 ? "99+" : unread; color: Theme.accentText; font.pixelSize: 12; font.weight: Font.Bold }
                        }
                    }
                }
            }
        }

        ColumnLayout {
            anchors.centerIn: parent; visible: list.count === 0; spacing: 16
            Image { Layout.alignment: Qt.AlignHCenter; source: Theme.icon("lock", "muted"); sourceSize: Qt.size(48, 48) }
            Text { Layout.alignment: Qt.AlignHCenter; text: qsTr("Aucune conversation"); color: Theme.text; font.pixelSize: Theme.fontLarge }
            Text { Layout.alignment: Qt.AlignHCenter; text: qsTr("Vos échanges sont chiffrés de bout en bout."); color: Theme.textMuted; font.pixelSize: Theme.fontSmall }
            AppButton { Layout.alignment: Qt.AlignHCenter; variant: "primary"; iconName: "plus"; text: qsTr("Nouvelle conversation"); onClicked: page.StackView.view.push(newConv) }
        }
    }
}
