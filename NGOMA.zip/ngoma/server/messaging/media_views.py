import hashlib
import hmac
import time
import uuid

from django.conf import settings
from django.http import FileResponse
from django.shortcuts import get_object_or_404
from rest_framework.parsers import MultiPartParser
from rest_framework.renderers import BaseRenderer, JSONRenderer
from rest_framework.response import Response
from rest_framework.views import APIView

from . import services
from .models import Media


class MediaUploadView(APIView):
    """Téléversement d'un fichier déjà chiffré par le client (multipart : messaging_id, file)."""

    parser_classes = [MultiPartParser]

    def post(self, request):
        f = request.FILES.get("file")
        try:
            mid = uuid.UUID(request.data.get("messaging_id", ""))
            services.membership_or_raise(request.user, mid)
        except ValueError:
            return Response({"detail": "messaging_id invalide"}, status=400)
        except services.SyncError as exc:
            return Response({"detail": exc.detail}, status=exc.status)
        if f is None or f.size == 0:
            return Response({"detail": "Fichier manquant"}, status=400)
        if f.size > settings.NGOMA["MAX_MEDIA_BYTES"]:
            return Response({"detail": "Fichier trop volumineux"}, status=413)
        m = Media(messaging_id=mid, uploader=request.user, size=f.size)
        m.blob.save(f"{m.id}.bin", f, save=False)
        m.save()
        return Response({"media_id": str(m.id), "size": m.size}, status=201)


class OctetStreamRenderer(BaseRenderer):
    media_type = "application/octet-stream"
    format = "bin"

    def render(self, data, accepted_media_type=None, renderer_context=None):
        return data if isinstance(data, bytes) else b""


class MediaDownloadView(APIView):
    renderer_classes = [OctetStreamRenderer, JSONRenderer]

    def get(self, request, media_id):
        m = get_object_or_404(Media, pk=media_id)
        try:
            services.membership_or_raise(request.user, m.messaging_id)
        except services.SyncError:
            return Response(status=404)
        return FileResponse(m.blob.open("rb"), content_type="application/octet-stream")


def relay_token(call_id: uuid.UUID, user_id: int, device_id: uuid.UUID, exp: int) -> str:
    """Jeton du relais média : HMAC-SHA256(secret, call_id(16) | user_id(8, BE) | device_id(16) | exp(8, BE))."""
    msg = call_id.bytes + user_id.to_bytes(8, "big") + device_id.bytes + exp.to_bytes(8, "big")
    return hmac.new(settings.NGOMA["RELAY_SECRET"].encode(), msg, hashlib.sha256).hexdigest()


class CallTokenView(APIView):
    """Autorisation d'accès au relais média pour un appel dans une conversation."""

    def post(self, request):
        try:
            mid = uuid.UUID(str(request.data.get("messaging_id")))
            call_id = uuid.UUID(str(request.data.get("call_id")))
            services.membership_or_raise(request.user, mid)
        except ValueError:
            return Response({"detail": "Paramètres invalides"}, status=400)
        except services.SyncError as exc:
            return Response({"detail": exc.detail}, status=exc.status)
        cfg = settings.NGOMA
        exp = int(time.time()) + 4 * 3600
        return Response({
            "relay_host": cfg["RELAY_HOST"], "relay_port": cfg["RELAY_PORT"], "call_id": str(call_id),
            "user_id": request.user.id, "device_id": str(request.auth.pk), "exp": exp,
            "token": relay_token(call_id, request.user.id, request.auth.pk, exp),
        })
