#!/usr/bin/env python3
"""Peuple un serveur NGOMA de démonstration (captures d'écran, salons, formations).

Crée Alice (identité écrite pour le terminal Qt dans <data_dir>/identity.json), Bob et Carole (terminaux
simulés en Python, même protocole Ratchet v2), une conversation directe, un groupe et l'assistant IA d'Alice.
Usage : demo_seed.py <server_url> <provisioning_code> <alice_data_dir> <llm_url>
"""
import json
import os
import secrets
import sys
import time
import uuid

import httpx

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
from fcrypto import ratchet as r  # noqa: E402

URL, CODE, ALICE_DIR, LLM = sys.argv[1:5]
API = URL.rstrip("/") + "/api/v1/"


class Peer:
    def __init__(self, username, display):
        self.keys = r.DeviceKeys.generate()
        res = httpx.post(API + "auth/signup", json={
            "username": username, "password": secrets.token_urlsafe(18), "display_name": display,
            "provisioning_code": CODE, "device_name": "démo", "public_key": r.b64e(self.keys.identity_pk)})
        res.raise_for_status()
        body = res.json()
        self.user_id, self.device_id, self.token = body["user"]["id"], body["device_id"], body["token"]
        self.display, self.username = display, username
        self.h = {"Authorization": f"Device {self.token}"}
        self.sessions = {}
        httpx.post(API + "keys/prekeys", headers=self.h,
                   json=self.keys.public_upload(self.keys.new_opks(50))).raise_for_status()

    def post(self, path, data):
        res = httpx.post(API + path, headers=self.h, json=data)
        res.raise_for_status()
        return res.json()

    def send(self, conv, text):
        devices = [d for d in httpx.get(API + f"conversations/{conv}/devices", headers=self.h).json()
                   if d["device_id"] != self.device_id]
        missing = [d["device_id"] for d in devices if d["device_id"] not in self.sessions]
        bundles = self.post("keys/claim", {"device_ids": missing}) if missing else {}
        pt = json.dumps({"v": 1, "t": "text", "b": text}).encode()
        envs = []
        for d in devices:
            s = self.sessions.get(d["device_id"]) or r.initiate(self.keys, bundles[d["device_id"]])
            envs.append({"device_id": d["device_id"], "payload": r.encrypt(s, pt)})
            self.sessions[d["device_id"]] = s
        self.post("sync/push", {"messaging_id": conv, "client_id": str(uuid.uuid4()), "envelopes": envs})
        time.sleep(0.15)


alice = Peer("alice", "Alice Martin")
bob = Peer("bob", "Bob Diallo")
carole = Peer("carole", "Carole Nguyen")
dave = Peer("david", "David Keita")

# Identité d'Alice au format du terminal C++ (SecretStore v2) : le terminal Qt démarre directement connecté.
os.makedirs(ALICE_DIR, exist_ok=True)
path = os.path.join(ALICE_DIR, "identity.json")
with open(path, "w") as f:
    json.dump({"v": 2, "user_id": alice.user_id, "username": alice.username, "display_name": alice.display,
               "device_id": alice.device_id, "token": alice.token, "keys": alice.keys.d}, f)
os.chmod(path, 0o600)

direct = bob.post("conversations", {"kind": "direct", "member_ids": [alice.user_id]})["id"]
bob.send(direct, "Salut Alice ! La ligne 3 est de nouveau opérationnelle.")
bob.send(direct, "Tu peux confirmer la livraison des pièces pour demain matin ?")

group = carole.post("conversations", {"kind": "group", "title": "Équipe atelier",
                                      "member_ids": [alice.user_id, bob.user_id, dave.user_id]})["id"]
carole.send(group, "Bonjour à tous, réunion de sécurité à 14 h en salle B.")
dave.send(group, "Je serai là. J'apporte le rapport d'inspection du convoyeur.")
bob.send(group, "OK pour moi 👍")

direct2 = dave.post("conversations", {"kind": "direct", "member_ids": [alice.user_id]})["id"]
dave.send(direct2, "Merci pour le coup de main ce matin !")

res = httpx.post(API + "bots/me", headers=alice.h, json={
    "provider": "openai", "model": "modele-demo", "api_key": os.environ["NGOMA_FAKE_LLM_KEY"], "base_url": LLM,
    "system_prompt": "Réponds en français, brièvement."})
res.raise_for_status()
print(json.dumps({"alice": alice.user_id, "direct": direct, "group": group, "bot": res.json()["conversation_id"]}))
