#include <QJsonDocument>
#include <QProcess>
#include <QtTest>
#include <sodium.h>

#include "core/Ratchet.h"

using namespace ngoma;
namespace rt = ngoma::ratchet;

namespace {
QJsonObject bundleOf(rt::DeviceKeys& k) {
    const auto opks = k.newOneTimePrekeys(1);
    const auto up = k.publicUpload(opks);
    return {{"identity_key", QString::fromLatin1(k.identityPublic().toBase64())}, {"spk_id", up["spk_id"]},
            {"spk", up["spk"]}, {"spk_sig", up["spk_sig"]}, {"opk_id", opks[0].toObject()["id"]},
            {"opk", opks[0].toObject()["key"]}};
}
}  // namespace

class TestRatchet : public QObject {
    Q_OBJECT
    QProcess py;

    QJsonObject ask(const QJsonObject& req) {
        py.write(QJsonDocument(req).toJson(QJsonDocument::Compact) + '\n');
        if (!py.waitForReadyRead(5000)) return {{"error", "pas de réponse du pair Python"}};
        while (!py.canReadLine()) py.waitForReadyRead(1000);
        return QJsonDocument::fromJson(py.readLine()).object();
    }

private slots:
    void initTestCase() { QVERIFY(sodium_init() >= 0); }

    void cppToCpp() {
        auto alice = rt::DeviceKeys::generate();
        auto bob = rt::DeviceKeys::generate();
        auto sa = rt::initiate(alice, bundleOf(bob));
        QVERIFY(sa);
        QJsonObject sb;
        for (int i = 0; i < 3; ++i) {
            auto env = rt::encrypt(*sa, QByteArray("bonjour ") + QByteArray::number(i));
            QVERIFY(env);
            QCOMPARE((*env)["type"].toString(), QString("prekey"));
            auto d = rt::decrypt(bob, sb, *env);
            QVERIFY(d);
            QCOMPARE(d->plaintext, QByteArray("bonjour ") + QByteArray::number(i));
            sb = d->session;
            if (d->consumedOneTimePrekey) bob.dropOneTimePrekey(d->oneTimePrekeyId);
        }
        auto reply = rt::encrypt(sb, "salut");
        auto d = rt::decrypt(alice, *sa, *reply);
        QVERIFY(d);
        QCOMPARE(d->plaintext, QByteArray("salut"));
        QVERIFY(d->session["pending"].isNull());
        // altération : refus et état inchangé
        QJsonObject sa2 = d->session;
        auto env = rt::encrypt(sa2, "x");
        QJsonObject bad = *env;
        QByteArray c = QByteArray::fromBase64(bad["c"].toString().toLatin1());
        c[0] = char(c[0] ^ 1);
        bad["c"] = QString::fromLatin1(c.toBase64());
        QVERIFY(!rt::decrypt(bob, sb, bad));
        QVERIFY(rt::decrypt(bob, sb, *env));
    }

    void interopWithPython() {
        const QString script = QStringLiteral(NGOMA_SOURCE_DIR "/../tools/ratchet_peer.py");
        py.start(QStringLiteral("python3"), {script});
        if (!py.waitForStarted(5000)) QSKIP("python3 indisponible");

        // 1) C++ initie vers un paquet Python.
        auto cpp = rt::DeviceKeys::generate();
        const auto pyBundle = ask({{"cmd", "bundle"}});
        QVERIFY2(!pyBundle.contains("error"), qPrintable(pyBundle["error"].toString()));
        auto s = rt::initiate(cpp, pyBundle);
        QVERIFY(s);
        for (const char* m : {"C++ → Python 1", "C++ → Python 2"}) {
            auto env = rt::encrypt(*s, QByteArray(m));
            const auto r = ask({{"cmd", "decrypt"}, {"env", *env}});
            QVERIFY2(!r.contains("error"), qPrintable(r["error"].toString()));
            QCOMPARE(QByteArray::fromBase64(r["pt"].toString().toLatin1()), QByteArray(m));
        }
        for (int i = 0; i < 3; ++i) {  // Python répond (pas de DH ratchet côté Python), C++ déchiffre
            const QByteArray m = "Python → C++ " + QByteArray::number(i);
            const auto env = ask({{"cmd", "encrypt"}, {"pt", QString::fromLatin1(m.toBase64())}});
            QCOMPARE(env["type"].toString(), QString("msg"));
            auto d = rt::decrypt(cpp, *s, env);
            QVERIFY(d);
            QCOMPARE(d->plaintext, m);
            *s = d->session;
        }
        auto env = rt::encrypt(*s, "C++ → Python 3");
        QCOMPARE((*env)["type"].toString(), QString("msg"));
        QCOMPARE(QByteArray::fromBase64(ask({{"cmd", "decrypt"}, {"env", *env}})["pt"].toString().toLatin1()),
                 QByteArray("C++ → Python 3"));
        py.closeWriteChannel();
        py.waitForFinished(3000);

        // 2) Python initie vers un paquet C++.
        py.start(QStringLiteral("python3"), {script});
        QVERIFY(py.waitForStarted(5000));
        auto me = rt::DeviceKeys::generate();
        QVERIFY(ask({{"cmd", "initiate"}, {"bundle", bundleOf(me)}})["ok"].toBool());
        const auto first = ask({{"cmd", "encrypt"}, {"pt", QString::fromLatin1(QByteArray("Python initie").toBase64())}});
        QCOMPARE(first["type"].toString(), QString("prekey"));
        auto d = rt::decrypt(me, {}, first);
        QVERIFY(d);
        QCOMPARE(d->plaintext, QByteArray("Python initie"));
        QVERIFY(d->consumedOneTimePrekey);
        QJsonObject sess = d->session;
        auto back = rt::encrypt(sess, "réponse C++");
        QCOMPARE(QByteArray::fromBase64(ask({{"cmd", "decrypt"}, {"env", *back}})["pt"].toString().toLatin1()),
                 QByteArray("réponse C++"));
        py.closeWriteChannel();
        py.waitForFinished(3000);
    }
};

QTEST_GUILESS_MAIN(TestRatchet)
#include "test_ratchet.moc"
