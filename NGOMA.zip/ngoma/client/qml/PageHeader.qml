import QtQuick
import QtQuick.Layouts

// En-tête de page : bouton retour optionnel, titre, sous-titre, zone d'actions à droite.
Rectangle {
    id: root
    property string title
    property string subtitle: ""
    property bool showBack: false
    default property alias actions: actionRow.data
    signal back()

    implicitHeight: Theme.headerHeight
    color: Theme.surface

    Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.outline }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: root.showBack ? 4 : 20
        anchors.rightMargin: 8
        spacing: 8
        IconButton { visible: root.showBack; iconName: "back"; tip: qsTr("Retour"); onClicked: root.back() }
        ColumnLayout {
            Layout.fillWidth: true
            spacing: 0
            Text { text: root.title; color: Theme.text; font.pixelSize: Theme.fontLarge + 2; font.weight: Font.DemiBold; elide: Text.ElideRight; Layout.fillWidth: true }
            Text { text: root.subtitle; visible: text.length > 0; color: Theme.accent; font.pixelSize: Theme.fontSmall; elide: Text.ElideRight; Layout.fillWidth: true }
        }
        Row { id: actionRow; spacing: 4 }
    }
}
