"""Ngoma — configuration serveur.

Toute la configuration de production passe par des variables d'environnement
(voir deploy/server.env.example). Aucune valeur secrète n'est codée ici.
"""
import os
import secrets
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def env_bool(name: str, default: bool = False) -> bool:
    return os.environ.get(name, str(default)).lower() in {"1", "true", "yes", "on"}


DEBUG = env_bool("NGOMA_DEBUG", False)
SECRET_KEY = os.environ.get("NGOMA_SECRET_KEY", "")
if not SECRET_KEY:
    if DEBUG or os.environ.get("NGOMA_TESTING") or "pytest" in sys.modules:
        SECRET_KEY = secrets.token_urlsafe(50)  # éphémère : régénérée à chaque démarrage hors production
    else:
        raise RuntimeError("NGOMA_SECRET_KEY doit être défini en production")

ALLOWED_HOSTS = [h for h in os.environ.get("NGOMA_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if h]

INSTALLED_APPS = [
    "daphne",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "channels",
    "accounts",
    "messaging",
    "realtime",
    "bots",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "ngoma_server.urls"
ASGI_APPLICATION = "ngoma_server.asgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ]
        },
    }
]

# --- Base de données : PostgreSQL en production (DATABASE_URL), SQLite en dev/test.
DATABASE_URL = os.environ.get("DATABASE_URL")
if DATABASE_URL:
    import dj_database_url

    DATABASES = {"default": dj_database_url.parse(DATABASE_URL, conn_max_age=60)}
else:
    DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": BASE_DIR / "db.sqlite3"}}
if DATABASES["default"]["ENGINE"].endswith("sqlite3"):
    # Développement / tests uniquement (production : PostgreSQL). Écrivains concurrents (API + worker des bots) :
    # attente du verrou et transactions IMMEDIATE pour éviter « database is locked ».
    DATABASES["default"].setdefault("OPTIONS", {}).update({"timeout": 20, "transaction_mode": "IMMEDIATE"})

# --- Couche de canaux : Redis en production (obligatoire dès qu'il y a plus d'un processus).
REDIS_URL = os.environ.get("REDIS_URL")
if REDIS_URL:
    CHANNEL_LAYERS = {
        "default": {
            "BACKEND": "channels_redis.core.RedisChannelLayer",
            "CONFIG": {"hosts": [REDIS_URL], "capacity": 2000, "expiry": 30},
        }
    }
    CACHES = {"default": {"BACKEND": "django.core.cache.backends.redis.RedisCache", "LOCATION": REDIS_URL}}
else:
    CHANNEL_LAYERS = {"default": {"BACKEND": "channels.layers.InMemoryChannelLayer"}}
    CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
]

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": ["accounts.auth.DeviceTokenAuthentication"],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    "DEFAULT_RENDERER_CLASSES": ["rest_framework.renderers.JSONRenderer"],
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": os.environ.get("NGOMA_THROTTLE_ANON", "30/min"),
        "user": os.environ.get("NGOMA_THROTTLE_USER", "1200/min"),
    },
}

# --- Paramètres métier
NGOMA = {
    # L'inscription libre est désactivée par défaut : les terminaux sont provisionnés.
    "OPEN_SIGNUP": env_bool("NGOMA_OPEN_SIGNUP", False),
    "PROVISIONING_CODE": os.environ.get("NGOMA_PROVISIONING_CODE", ""),
    "MAX_CIPHERTEXT_BYTES": int(os.environ.get("NGOMA_MAX_CIPHERTEXT_BYTES", 65536)),
    "MAX_GROUP_MEMBERS": int(os.environ.get("NGOMA_MAX_GROUP_MEMBERS", 256)),
    "PULL_PAGE_MAX": 200,
    "PRESENCE_TTL_SECONDS": 75,
    "MAX_MEDIA_BYTES": int(os.environ.get("NGOMA_MAX_MEDIA_BYTES", 25 * 1024 * 1024)),
    "MEDIA_RETENTION_DAYS": int(os.environ.get("NGOMA_MEDIA_RETENTION_DAYS", 30)),
    # Relais média des appels (relay/) : secret HMAC partagé avec ngoma-relay.
    "RELAY_SECRET": os.environ.get("NGOMA_RELAY_SECRET", secrets.token_urlsafe(32) if DEBUG or "pytest" in sys.modules else ""),
    "RELAY_HOST": os.environ.get("NGOMA_RELAY_HOST", "127.0.0.1"),
    "RELAY_PORT": int(os.environ.get("NGOMA_RELAY_PORT", 3479)),
    # Bots : chiffrement au repos des clés API et des secrets du bot (Fernet). Obligatoire en production.
    "BOT_KEY": os.environ.get("NGOMA_BOT_KEY", ""),
    "BOT_POLL_SECONDS": float(os.environ.get("NGOMA_BOT_POLL_SECONDS", 1.0)),
    "BOT_HISTORY_TURNS": int(os.environ.get("NGOMA_BOT_HISTORY_TURNS", 20)),
    "BOT_ALLOW_PRIVATE_BASE_URL": env_bool("NGOMA_BOT_ALLOW_PRIVATE_BASE_URL", False),
}
if not NGOMA["RELAY_SECRET"] and not os.environ.get("NGOMA_TESTING"):
    raise RuntimeError("NGOMA_RELAY_SECRET doit être défini en production")

MEDIA_ROOT = Path(os.environ.get("NGOMA_MEDIA_ROOT", BASE_DIR / "var"))
DATA_UPLOAD_MAX_MEMORY_SIZE = 2 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 2 * 1024 * 1024

SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG

LANGUAGE_CODE = "fr-fr"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True
STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "static"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {"plain": {"format": "%(asctime)s %(levelname)s %(name)s %(message)s"}},
    "handlers": {"console": {"class": "logging.StreamHandler", "formatter": "plain"}},
    "root": {"handlers": ["console"], "level": os.environ.get("NGOMA_LOG_LEVEL", "INFO")},
}
