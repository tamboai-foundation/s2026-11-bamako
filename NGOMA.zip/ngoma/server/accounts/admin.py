from django.contrib import admin

from .models import Device


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ("name", "user", "created_at", "last_seen_at", "revoked_at")
    list_filter = ("revoked_at",)
    search_fields = ("name", "user__username")
    readonly_fields = ("token_hash", "public_key")
