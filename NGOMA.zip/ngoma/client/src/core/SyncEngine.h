#pragma once

#include <QDateTime>
#include <QHash>
#include <QJsonArray>
#include <QJsonObject>
#include <QObject>
#include <QSet>
#include <QTimer>
#include <functional>
#include <optional>

#include "SecretStore.h"

namespace ngoma {

class ApiClient;
class RealtimeClient;
class StoreClient;

/// Moteur de synchronisation interne de Ngoma (côté terminal) — protocole v2.
///
///  * Curseur par conversation (`pulled_seq`) persistant dans ngoma-store ; reprise exacte après coupure.
///  * Outbox persistante, idempotence UUIDv7.
///  * NGOMA Ratchet v2 (X3DH + Double Ratchet) par appareil pair : confidentialité persistante et
///    rétablissement après compromission. Les sessions sont validées sur disque APRÈS l'écriture du message
///    déchiffré dans le stockage local : un plantage entre les deux rejoue proprement.
///  * Prékeys publiées et réapprovisionnées automatiquement ; rotation de la prékey signée tous les 7 jours.
///  * Épinglage TOFU de l'identité de chaque appareil pair ; une identité qui change est refusée et signalée.
class SyncEngine : public QObject {
    Q_OBJECT
public:
    SyncEngine(ApiClient& api, RealtimeClient& rt, StoreClient& store, SecretStore& secrets, QObject* parent = nullptr);

    void start(const Identity& identity);
    void stop();
    bool isOnline() const { return m_online; }
    const Identity& identity() const { return m_id; }

    void sendText(const QString& messagingId, const QString& text, int expiresInSec = 0);
    void sendMedia(const QString& messagingId, const QString& caption, const QJsonObject& meta);
    void markRead(const QString& messagingId, qint64 seq);
    void refreshConversations(std::function<void()> done = {});
    void retryFailed();

    /// Chiffre `plaintext` pour tous les appareils joignables de `userId` dans la conversation (signaux d'appel).
    void encryptForUser(const QString& messagingId, qint64 userId, const QByteArray& plaintext,
                        std::function<void(bool ok, const QJsonObject& envelopesByDevice)> cb);
    /// Déchiffre une enveloppe reçue hors du flux de messages (signal d'appel) et valide la session.
    std::optional<QByteArray> decryptFromDevice(const QString& deviceId, const QJsonObject& envelope);

signals:
    void onlineChanged(bool online);
    void syncingChanged(bool syncing);
    void incoming(const QString& messagingId, int count);
    void typing(const QString& messagingId, qint64 userId);
    void callSignal(const QJsonObject& evt);
    void keyChanged(const QString& deviceId, qint64 userId);
    void errorOccurred(const QString& message);

private:
    struct DeviceKey {
        QString id;
        qint64 userId = 0;
        QByteArray identity;
    };
    struct DeviceCache {
        QDateTime fetched;
        QList<DeviceKey> devices;
    };
    struct PendingCommit {
        QHash<QString, QJsonObject> sessions;
        QList<int> consumedPrekeys;
    };

    void onEvent(const QJsonObject& evt);
    void fullSync();
    void loadCursors(std::function<void()> done);
    void pull(const QString& messagingId);
    QJsonObject decryptItem(const QJsonObject& item, bool& fromOther, PendingCommit& commit);
    void applyCommit(const PendingCommit& commit);
    bool checkPin(const QString& deviceId, const QByteArray& identity, qint64 userId);
    void savePins();
    void ensurePrekeys();
    void saveIdentity();

    void queueOutgoing(const QJsonObject& rec);
    void flushOutbox();
    void sendNext();
    void sendOne(const QJsonObject& msg, int attempt);
    void devicesFor(const QString& messagingId, bool force, std::function<void(bool ok, const QList<DeviceKey>&)> cb);
    void encryptToDevices(const QList<DeviceKey>& devices, const QByteArray& plaintext,
                          std::function<void(bool ok, const QJsonArray& envelopes)> cb);
    void scheduleOutboxRetry();

    ApiClient& m_api;
    RealtimeClient& m_rt;
    StoreClient& m_store;
    SecretStore& m_secrets;
    Identity m_id;
    bool m_running = false;
    bool m_online = false;

    QHash<QString, qint64> m_pulled;
    QSet<QString> m_pulling;
    QSet<QString> m_pullAgain;
    QHash<QString, DeviceCache> m_devices;
    QHash<QString, QString> m_pins;  // device_id -> identité Ed25519 base64

    bool m_flushing = false;
    QList<QJsonObject> m_sendQueue;
    QTimer m_outboxRetry;
    int m_outboxAttempt = 0;
    QTimer m_purge;
    QTimer m_prekeyCheck;
    QTimer m_safetySync;
    int m_prekeyAttempt = 0;
};

}  // namespace ngoma
