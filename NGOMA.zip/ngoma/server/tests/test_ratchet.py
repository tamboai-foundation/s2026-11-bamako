import copy
import random

import pytest

from fcrypto import ratchet as r


def bundle_of(keys: r.DeviceKeys, with_opk=True):
    up = keys.public_upload(keys.new_opks(3))
    b = {"identity_key": r.b64e(keys.identity_pk), "spk_id": up["spk_id"], "spk": up["spk"], "spk_sig": up["spk_sig"],
         "opk_id": None, "opk": None}
    if with_opk:
        b["opk_id"], b["opk"] = up["opks"][0]["id"], up["opks"][0]["key"]
    return b


@pytest.mark.parametrize("with_opk", [True, False])
def test_conversation_both_directions(with_opk):
    alice, bob = r.DeviceKeys.generate(), r.DeviceKeys.generate()
    sa = r.initiate(alice, bundle_of(bob, with_opk))
    sb = None
    for i in range(3):
        env = r.encrypt(sa, f"a{i}".encode())
        assert env["type"] == "prekey"
        pt, sb = r.decrypt(bob, sb, env)
        assert pt == f"a{i}".encode()
    reply = r.encrypt(sb, b"b0")
    assert reply["type"] == "msg"
    pt, sa = r.decrypt(alice, sa, reply)
    assert pt == b"b0" and sa["pending"] is None
    assert r.encrypt(sa, b"a3")["type"] == "msg"


def test_out_of_order_and_replay_rejected():
    alice, bob = r.DeviceKeys.generate(), r.DeviceKeys.generate()
    sa = r.initiate(alice, bundle_of(bob))
    envs = [r.encrypt(sa, f"m{i}".encode()) for i in range(6)]
    sb = None
    order = list(range(6))
    random.Random(3).shuffle(order)
    first = order.index(0)
    # le premier message traité doit pouvoir établir la session : tous les messages sont de type prekey
    seen = {}
    for idx in order:
        pt, sb = r.decrypt(bob, sb, envs[idx])
        seen[idx] = pt
    assert seen == {i: f"m{i}".encode() for i in range(6)} and first >= 0
    with pytest.raises(r.CryptoError):
        r.decrypt(bob, sb, envs[2])  # rejeu : clé déjà consommée


def test_tamper_does_not_corrupt_state():
    alice, bob = r.DeviceKeys.generate(), r.DeviceKeys.generate()
    sa = r.initiate(alice, bundle_of(bob))
    _, sb = r.decrypt(bob, None, r.encrypt(sa, b"x"))
    env = r.encrypt(sa, b"y")
    bad = copy.deepcopy(env)
    c = bytearray(r.b64d(bad["c"]))
    c[0] ^= 1
    bad["c"] = r.b64e(bytes(c))
    with pytest.raises(r.CryptoError):
        r.decrypt(bob, sb, bad)
    pt, _ = r.decrypt(bob, sb, env)
    assert pt == b"y"


def test_forward_secrecy_keys_change():
    alice, bob = r.DeviceKeys.generate(), r.DeviceKeys.generate()
    sa = r.initiate(alice, bundle_of(bob))
    _, sb = r.decrypt(bob, None, r.encrypt(sa, b"1"))
    rk1 = sa["rk"]
    _, sa = r.decrypt(alice, sa, r.encrypt(sb, b"2"))
    assert sa["rk"] != rk1  # pas de DH : la racine change à chaque aller-retour


def test_bad_spk_signature():
    bob = r.DeviceKeys.generate()
    b = bundle_of(bob)
    b["spk"] = r.b64e(r.random_bytes(32))
    with pytest.raises(r.CryptoError):
        r.initiate(r.DeviceKeys.generate(), b)


def test_opk_consumed_once():
    alice, bob = r.DeviceKeys.generate(), r.DeviceKeys.generate()
    b = bundle_of(bob)
    env = r.encrypt(r.initiate(alice, b), b"x")
    r.decrypt(bob, None, env)
    with pytest.raises(r.CryptoError):
        r.decrypt(bob, None, r.encrypt(r.initiate(r.DeviceKeys.generate(), b), b"y"))
